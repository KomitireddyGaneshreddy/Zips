import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { CircularProgress, Box } from '@mui/material';

const UserRoute = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  // If authentication is still loading, show a loading spinner
  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <CircularProgress />
      </Box>
    );
  }

  // If not authenticated, redirect to login with return URL
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If user is an admin, redirect to admin dashboard
  if (user.role === 'admin') {
    return <Navigate to="/adminDashboard" replace />;
  }

  // If authenticated and not admin, render the user component
  return children;
};

export default UserRoute; 