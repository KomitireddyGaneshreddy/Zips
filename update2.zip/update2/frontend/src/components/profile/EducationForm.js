import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Grid,
  IconButton,
  Card,
  CardContent,
  CardActions,
  CircularProgress,
  Alert,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import profileService from '../../services/profile.service';

const EducationForm = ({ initialData, onSubmit }) => {
  const theme = useTheme();
  const [educationList, setEducationList] = useState(initialData.length > 0 ? initialData : [{
    institution: '',
    degree: '',
    start_date: '',
    end_date: '',
    grade: '',
  }]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (index, field, value) => {
    const updatedList = [...educationList];
    updatedList[index] = {
      ...updatedList[index],
      [field]: value,
    };
    setEducationList(updatedList);
  };

  const validateEducation = (education) => {
    if (!education.institution) return 'Institution is required';
    if (!education.degree) return 'Degree is required';
    if (!education.start_date) return 'Start date is required';
    return null;
  };

  const handleAddEducation = () => {
    setEducationList([
      ...educationList,
      {
        institution: '',
        degree: '',
        start_date: '',
        end_date: '',
        grade: '',
      },
    ]);
  };

  const handleRemoveEducation = (index) => {
    const updatedList = educationList.filter((_, i) => i !== index);
    setEducationList(updatedList);
  };

  const formatYear = (startDate, endDate) => {
    if (!startDate) return '';
    const startYear = new Date(startDate).getFullYear();
    if (!endDate) return `${startYear} - Present`;
    const endYear = new Date(endDate).getFullYear();
    return `${startYear} - ${endYear}`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Validate all education entries
    for (const education of educationList) {
      const validationError = validateEducation(education);
      if (validationError) {
        setError(validationError);
        setLoading(false);
        return;
      }
    }

    try {
      // Format the education data before sending
      const formattedEducationList = educationList.map(edu => ({
        ...edu,
        year: formatYear(edu.start_date, edu.end_date)
      }));

      await profileService.insertEducation(formattedEducationList);
      onSubmit(formattedEducationList);
    } catch (err) {
      setError(err.message || 'Failed to save education');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} noValidate>
      <Typography variant="h6" gutterBottom color="primary">
        Education Details
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Add your educational background.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {educationList.map((education, index) => (
        <Card key={index} sx={{ mb: 3, position: 'relative' }}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Institution"
                  value={education.institution}
                  onChange={(e) => handleChange(index, 'institution', e.target.value)}
                  placeholder="University or College name"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Degree"
                  value={education.degree}
                  onChange={(e) => handleChange(index, 'degree', e.target.value)}
                  placeholder="e.g., Bachelor of Engineering"
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  type="date"
                  label="Start Date"
                  value={education.start_date}
                  onChange={(e) => handleChange(index, 'start_date', e.target.value)}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  type="date"
                  label="End Date"
                  value={education.end_date}
                  onChange={(e) => handleChange(index, 'end_date', e.target.value)}
                  InputLabelProps={{ shrink: true }}
                  helperText="Leave empty if currently studying"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Grade"
                  value={education.grade}
                  onChange={(e) => handleChange(index, 'grade', e.target.value)}
                  placeholder="e.g., 8.5 CGPA"
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions sx={{ justifyContent: 'flex-end', p: 2 }}>
            {educationList.length > 1 && (
              <IconButton
                onClick={() => handleRemoveEducation(index)}
                color="error"
                sx={{ position: 'absolute', top: 8, right: 8 }}
              >
                <DeleteIcon />
              </IconButton>
            )}
          </CardActions>
        </Card>
      ))}

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
        <Button
          startIcon={<AddIcon />}
          onClick={handleAddEducation}
          sx={{ color: theme.palette.primary.main }}
        >
          Add Another Education
        </Button>
        <Button
          type="submit"
          variant="contained"
          disabled={loading}
          sx={{
            minWidth: 120,
            backgroundColor: theme.palette.primary.main,
            '&:hover': {
              backgroundColor: theme.palette.primary.dark,
            },
          }}
        >
          {loading ? <CircularProgress size={24} /> : 'Save'}
        </Button>
      </Box>
    </Box>
  );
};

export default EducationForm; 