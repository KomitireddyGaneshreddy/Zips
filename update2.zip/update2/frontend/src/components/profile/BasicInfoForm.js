import React from 'react';
import {
  Box,
  Typography,
  Button,
  Grid,
  Paper,
  useTheme,
  Fade,
  Slide,
  Grow,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import SchoolIcon from '@mui/icons-material/School';
import WorkIcon from '@mui/icons-material/Work';
import CodeIcon from '@mui/icons-material/Code';
import LinkIcon from '@mui/icons-material/Link';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { motion } from 'framer-motion';

const BasicInfoForm = ({ onSubmit }) => {
  const theme = useTheme();
  const navigate = useNavigate();

  const handleStart = () => {
    onSubmit({});
  };

  const features = [
    {
      icon: <SchoolIcon sx={{ fontSize: 40, color: theme.palette.primary.main }} />,
      title: 'Education Details',
      description: 'Share your academic journey and achievements',
    },
    {
      icon: <WorkIcon sx={{ fontSize: 40, color: theme.palette.primary.main }} />,
      title: 'Work Experience',
      description: 'Highlight your professional growth and expertise',
    },
    {
      icon: <CodeIcon sx={{ fontSize: 40, color: theme.palette.primary.main }} />,
      title: 'Skills & Expertise',
      description: 'Showcase your technical and soft skills',
    },
    {
      icon: <LinkIcon sx={{ fontSize: 40, color: theme.palette.primary.main }} />,
      title: 'Social Presence',
      description: 'Connect your professional profiles',
    },
  ];

  return (
    <Box sx={{ p: 3 }}>
      <Fade in timeout={1000}>
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography
            variant="h3"
            component="h1"
            gutterBottom
            sx={{
              fontWeight: 'bold',
              background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              mb: 2,
            }}
          >
            Welcome to Your Professional Profile!
          </Typography>
          <Typography variant="h6" color="text.secondary" sx={{ mb: 3 }}>
            Let's create a profile that showcases your unique journey and expertise
          </Typography>
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Paper
              elevation={3}
              sx={{
                p: 3,
                mb: 4,
                borderRadius: 2,
                backgroundColor: theme.palette.background.paper,
                maxWidth: 600,
                mx: 'auto',
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <CheckCircleOutlineIcon
                  sx={{ color: theme.palette.success.main, mr: 1 }}
                />
                <Typography variant="body1">
                  This will only take 2 minutes of your time
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <CheckCircleOutlineIcon
                  sx={{ color: theme.palette.success.main, mr: 1 }}
                />
                <Typography variant="body1">
                  Help us connect you with relevant opportunities
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <CheckCircleOutlineIcon
                  sx={{ color: theme.palette.success.main, mr: 1 }}
                />
                <Typography variant="body1">
                  Build your professional network
                </Typography>
              </Box>
            </Paper>
          </motion.div>
        </Box>
      </Fade>

      <Slide direction="up" in timeout={1500}>
        <Grid container spacing={4} sx={{ mb: 6 }}>
          {features.map((feature, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.2 }}
              >
                <Paper
                  elevation={2}
                  sx={{
                    p: 3,
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    textAlign: 'center',
                    borderRadius: 2,
                    transition: 'transform 0.3s',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                    },
                  }}
                >
                  <Box sx={{ mb: 2 }}>{feature.icon}</Box>
                  <Typography variant="h6" gutterBottom>
                    {feature.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {feature.description}
                  </Typography>
                </Paper>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Slide>

      <Box sx={{ textAlign: 'center' }}>
        <Grow in timeout={2000}>
          <Button
            variant="contained"
            size="large"
            onClick={handleStart}
            sx={{
              px: 6,
              py: 1.5,
              fontSize: '1.1rem',
              borderRadius: 2,
              background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
              '&:hover': {
                background: `linear-gradient(45deg, ${theme.palette.primary.dark}, ${theme.palette.secondary.dark})`,
              },
            }}
          >
            Let's Get Started
          </Button>
        </Grow>
      </Box>
    </Box>
  );
};

export default BasicInfoForm; 