import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Grid,
  InputAdornment,
  IconButton,
  CircularProgress,
  Alert,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import TwitterIcon from '@mui/icons-material/Twitter';
import LanguageIcon from '@mui/icons-material/Language';
import profileService from '../../services/profile.service';

const SocialLinksForm = ({ initialData, onSubmit }) => {
  const theme = useTheme();
  const [formData, setFormData] = useState({
    linkedin_url: initialData.linkedin_url || '',
    github_url: initialData.github_url || '',
    twitter_url: initialData.twitter_url || '',
    portfolio_url: initialData.portfolio_url || '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateUrls = () => {
    const urlPattern = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/;
    
    if (formData.linkedin_url && !urlPattern.test(formData.linkedin_url)) {
      return 'Please enter a valid LinkedIn URL';
    }
    if (formData.github_url && !urlPattern.test(formData.github_url)) {
      return 'Please enter a valid GitHub URL';
    }
    if (formData.twitter_url && !urlPattern.test(formData.twitter_url)) {
      return 'Please enter a valid Twitter URL';
    }
    if (formData.portfolio_url && !urlPattern.test(formData.portfolio_url)) {
      return 'Please enter a valid portfolio URL';
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const validationError = validateUrls();
    if (validationError) {
      setError(validationError);
      setLoading(false);
      return;
    }

    try {
      await profileService.updateSocialLinks(formData);
      onSubmit(formData);
    } catch (err) {
      setError(err.message || 'Failed to save social links');
    } finally {
      setLoading(false);
    }
  };

  const socialFields = [
    {
      name: 'linkedin_url',
      label: 'LinkedIn Profile',
      icon: <LinkedInIcon />,
      placeholder: 'https://linkedin.com/in/your-profile',
    },
    {
      name: 'github_url',
      label: 'GitHub Profile',
      icon: <GitHubIcon />,
      placeholder: 'https://github.com/your-username',
    },
    {
      name: 'twitter_url',
      label: 'Twitter Profile',
      icon: <TwitterIcon />,
      placeholder: 'https://twitter.com/your-handle',
    },
    {
      name: 'portfolio_url',
      label: 'Portfolio Website',
      icon: <LanguageIcon />,
      placeholder: 'https://your-portfolio.com',
    },
  ];

  return (
    <Box component="form" onSubmit={handleSubmit} noValidate>
      <Typography variant="h6" gutterBottom color="primary">
        Social Links
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Add your social media profiles and portfolio.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        {socialFields.map((field) => (
          <Grid item xs={12} key={field.name}>
            <TextField
              fullWidth
              label={field.label}
              name={field.name}
              value={formData[field.name]}
              onChange={handleChange}
              placeholder={field.placeholder}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <IconButton
                      edge="start"
                      sx={{
                        color: theme.palette.primary.main,
                        '&:hover': {
                          color: theme.palette.primary.dark,
                        },
                      }}
                    >
                      {field.icon}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
        ))}

        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
            <Button
              type="submit"
              variant="contained"
              size="large"
              disabled={loading}
              sx={{
                minWidth: 120,
                backgroundColor: theme.palette.primary.main,
                '&:hover': {
                  backgroundColor: theme.palette.primary.dark,
                },
              }}
            >
              {loading ? <CircularProgress size={24} /> : 'Save'}
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SocialLinksForm; 