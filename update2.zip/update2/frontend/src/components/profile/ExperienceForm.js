import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Grid,
  IconButton,
  Card,
  CardContent,
  CardActions,
  FormControlLabel,
  Checkbox,
  CircularProgress,
  Alert,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import profileService from '../../services/profile.service';
import { useAuth } from '../../context/AuthContext';

const ExperienceForm = ({ initialData, onSubmit }) => {
  const theme = useTheme();
  const { user } = useAuth();
  const [experienceList, setExperienceList] = useState(initialData.length > 0 ? initialData : [{
    title: '',
    company: '',
    location: '',
    start_date: '',
    end_date: '',
    current: false,
    description: '',
  }]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (index, field, value) => {
    const updatedList = [...experienceList];
    updatedList[index] = {
      ...updatedList[index],
      [field]: value,
    };
    setExperienceList(updatedList);
  };

  const validateExperience = (experience) => {
    if (!experience.title) return 'Job title is required';
    if (!experience.company) return 'Company name is required';
    if (!experience.start_date) return 'Start date is required';
    if (!experience.current && !experience.end_date) return 'End date is required for past experiences';
    return null;
  };

  const handleAddExperience = () => {
    setExperienceList([
      ...experienceList,
      {
        title: '',
        company: '',
        location: '',
        start_date: '',
        end_date: '',
        current: false,
        description: '',
      },
    ]);
  };

  const handleRemoveExperience = (index) => {
    const updatedList = experienceList.filter((_, i) => i !== index);
    setExperienceList(updatedList);
  };

  const formatDuration = (startDate, endDate, isCurrent) => {
    if (!startDate) return null;
    const startYear = new Date(startDate).getFullYear();
    if (isCurrent) return `${startYear} - Present`;
    if (!endDate) return `${startYear}`;
    const endYear = new Date(endDate).getFullYear();
    return `${startYear} - ${endYear}`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Validate all experience entries
    for (const experience of experienceList) {
      const validationError = validateExperience(experience);
      if (validationError) {
        setError(validationError);
        setLoading(false);
        return;
      }
    }

    try {
      // Get the most recent/current experience
      const currentExperience = experienceList.find(exp => exp.current) || experienceList[0];
      
      // Format the experience data before sending
      const formattedExperienceList = experienceList.map(exp => ({
        user_id: user.id,
        role: exp.title.trim() || null,
        company: exp.company.trim() || null,
        duration: formatDuration(exp.start_date, exp.end_date, exp.current),
        description: exp.description?.trim() || null,
        start_date: exp.start_date || null,
        end_date: exp.current ? null : (exp.end_date || null)
      }));

      // Log the formatted experience data
      console.log('Formatted Experience List:', JSON.stringify(formattedExperienceList, null, 2));

      // First update user profile with current position and company
      const profileUpdateData = {
        user_id: user.id,
        designation: currentExperience.title.trim() || null,
        current_company: currentExperience.company.trim() || null,
        bio: currentExperience.description?.trim() || null,
        current_location: currentExperience.location?.trim() || null
      };

      // Log the profile update data
      console.log('Profile Update Data:', JSON.stringify(profileUpdateData, null, 2));

      // Update profile
      await profileService.updateProfile(profileUpdateData);

      // Then insert experience records
      await profileService.insertExperience(formattedExperienceList);
      onSubmit(formattedExperienceList);
    } catch (err) {
      console.error('Error saving experience:', err);
      setError(err.response?.data?.message || err.message || 'Failed to save experience');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} noValidate>
      <Typography variant="h6" gutterBottom color="primary">
        Work Experience
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Add your work experience details.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {experienceList.map((experience, index) => (
        <Card key={index} sx={{ mb: 3, position: 'relative' }}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Job Title"
                  value={experience.title}
                  onChange={(e) => handleChange(index, 'title', e.target.value)}
                  placeholder="e.g., Software Engineer"
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Company"
                  value={experience.company}
                  onChange={(e) => handleChange(index, 'company', e.target.value)}
                  placeholder="Company name"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Location"
                  value={experience.location}
                  onChange={(e) => handleChange(index, 'location', e.target.value)}
                  placeholder="e.g., Bangalore, India"
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  type="date"
                  label="Start Date"
                  value={experience.start_date}
                  onChange={(e) => handleChange(index, 'start_date', e.target.value)}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  type="date"
                  label="End Date"
                  value={experience.end_date}
                  onChange={(e) => handleChange(index, 'end_date', e.target.value)}
                  InputLabelProps={{ shrink: true }}
                  disabled={experience.current}
                />
              </Grid>

              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={experience.current}
                      onChange={(e) => handleChange(index, 'current', e.target.checked)}
                      color="primary"
                    />
                  }
                  label="I currently work here"
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Description"
                  value={experience.description}
                  onChange={(e) => handleChange(index, 'description', e.target.value)}
                  placeholder="Describe your responsibilities and achievements..."
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions sx={{ justifyContent: 'flex-end', p: 2 }}>
            {experienceList.length > 1 && (
              <IconButton
                onClick={() => handleRemoveExperience(index)}
                color="error"
                sx={{ position: 'absolute', top: 8, right: 8 }}
              >
                <DeleteIcon />
              </IconButton>
            )}
          </CardActions>
        </Card>
      ))}

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
        <Button
          startIcon={<AddIcon />}
          onClick={handleAddExperience}
          sx={{ color: theme.palette.primary.main }}
        >
          Add Another Experience
        </Button>
        <Button
          type="submit"
          variant="contained"
          size="large"
          disabled={loading}
          sx={{
            minWidth: 120,
            backgroundColor: theme.palette.primary.main,
            '&:hover': {
              backgroundColor: theme.palette.primary.dark,
            },
          }}
        >
          {loading ? <CircularProgress size={24} /> : 'Save'}
        </Button>
      </Box>
    </Box>
  );
};

export default ExperienceForm; 