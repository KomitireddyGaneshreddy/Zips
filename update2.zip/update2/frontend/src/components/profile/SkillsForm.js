import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Chip,
  Paper,
  IconButton,
  Grid,
  CircularProgress,
  Alert,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import profileService from '../../services/profile.service';

const commonSkills = [
  'JavaScript',
  'Python',
  'Java',
  'C++',
  'React',
  'Node.js',
  'SQL',
  'AWS',
  'Docker',
  'Git',
  'Machine Learning',
  'Data Analysis',
  'Project Management',
  'Communication',
  'Leadership',
  'Problem Solving',
  'Team Work',
  'Time Management',
];

const SkillsForm = ({ initialData, onSubmit }) => {
  const theme = useTheme();
  const [skills, setSkills] = useState(initialData.length > 0 ? initialData : []);
  const [newSkill, setNewSkill] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleAddSkill = (skill) => {
    if (skill && !skills.includes(skill)) {
      setSkills([...skills, skill]);
    }
    setNewSkill('');
  };

  const handleRemoveSkill = (skillToRemove) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove));
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddSkill(newSkill);
    }
  };

  const validateSkills = () => {
    if (skills.length === 0) return 'Please add at least one skill';
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const validationError = validateSkills();
    if (validationError) {
      setError(validationError);
      setLoading(false);
      return;
    }

    try {
      await profileService.updateSkills(skills);
      onSubmit(skills);
    } catch (err) {
      setError(err.message || 'Failed to save skills');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} noValidate>
      <Typography variant="h6" gutterBottom color="primary">
        Skills
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Add your skills to showcase your expertise.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
            <TextField
              fullWidth
              label="Add a skill"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a skill and press Enter"
            />
            <IconButton
              onClick={() => handleAddSkill(newSkill)}
              color="primary"
              sx={{ p: '10px' }}
            >
              <AddIcon />
            </IconButton>
          </Box>
        </Grid>

        <Grid item xs={12}>
          <Typography variant="subtitle2" gutterBottom color="text.secondary">
            Suggested Skills
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
            {commonSkills.map((skill) => (
              <Chip
                key={skill}
                label={skill}
                onClick={() => handleAddSkill(skill)}
                sx={{
                  '&:hover': {
                    backgroundColor: theme.palette.primary.light,
                    color: 'white',
                  },
                }}
              />
            ))}
          </Box>
        </Grid>

        <Grid item xs={12}>
          <Typography variant="subtitle2" gutterBottom color="text.secondary">
            Your Skills
          </Typography>
          <Paper
            variant="outlined"
            sx={{
              p: 2,
              minHeight: 100,
              display: 'flex',
              flexWrap: 'wrap',
              gap: 1,
            }}
          >
            {skills.length > 0 ? (
              skills.map((skill) => (
                <Chip
                  key={skill}
                  label={skill}
                  onDelete={() => handleRemoveSkill(skill)}
                  color="primary"
                  sx={{
                    '& .MuiChip-deleteIcon': {
                      color: 'white',
                      '&:hover': {
                        color: theme.palette.error.light,
                      },
                    },
                  }}
                />
              ))
            ) : (
              <Typography variant="body2" color="text.secondary">
                No skills added yet. Add some skills to showcase your expertise.
              </Typography>
            )}
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
            <Button
              type="submit"
              variant="contained"
              size="large"
              disabled={loading}
              sx={{
                minWidth: 120,
                backgroundColor: theme.palette.primary.main,
                '&:hover': {
                  backgroundColor: theme.palette.primary.dark,
                },
              }}
            >
              {loading ? <CircularProgress size={24} /> : 'Save'}
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SkillsForm; 