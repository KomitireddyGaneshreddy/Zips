import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Container,
  Typography,
  Button,
  Grid,
  Avatar,
  Paper,
  Chip,
  Divider,
  CircularProgress,
} from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import GroupIcon from '@mui/icons-material/Group';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { formatDistanceToNow } from 'date-fns';
import { mentorshipService } from '../services/api';

const MentorshipDetails = () => {
  const { id } = useParams();
  const [mentorship, setMentorship] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMentorshipDetails = async () => {
      try {
        setLoading(true);
        const data = await mentorshipService.getMentorshipById(id);
        // Transform backend data to match UI structure
        const transformedMentorship = {
          id: data.id,
          title: data.title,
          description: data.description,
          expertise: data.expertise,
          experience: data.experience,
          availability: data.availability,
          department: data.department,
          type: data.type,
          expectations: data.expectations,
          contactEmail: data.contact_email,
          postedBy: {
            name: `${data.first_name} ${data.last_name}`,
            avatar: '#1a237e',
            designation: data.role || 'Alumni',
            degree: data.degree || 'Not specified',
            batch: data.batch || 'Not specified',
          },
          postedAt: new Date(data.created_at),
        };
        setMentorship(transformedMentorship);
      } catch (error) {
        console.error('Error fetching mentorship details:', error);
        setError('Failed to load mentorship details. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchMentorshipDetails();
  }, [id]);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  if (!mentorship) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography>Mentorship not found</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        <Paper elevation={0} sx={{ p: 4, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}>
          {/* Header Section */}
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Avatar 
                  sx={{ 
                    width: 64,
                    height: 64,
                    bgcolor: mentorship.postedBy.avatar,
                    fontSize: '2rem'
                  }}
                >
                  {mentorship.postedBy.name[0]}
                </Avatar>
                <Box>
                  <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 1 }}>
                    {mentorship.title}
                  </Typography>
                  <Typography variant="subtitle1" color="text.secondary">
                    Posted by {mentorship.postedBy.name} • {mentorship.postedBy.designation}
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary">
                    {mentorship.postedBy.degree} • {mentorship.postedBy.batch} batch
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} md={4}>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, height: '100%', justifyContent: 'center' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: 'text.secondary' }}>
                  <AccessTimeIcon sx={{ fontSize: 20 }} />
                  <Typography variant="body2">
                    Posted {formatDistanceToNow(mentorship.postedAt, { addSuffix: true })}
                  </Typography>
                </Box>
                <Button
                  variant="contained"
                  fullWidth
                  href={`mailto:${mentorship.contactEmail}`}
                  sx={{
                    bgcolor: '#1a237e',
                    '&:hover': { bgcolor: '#0d1b60' },
                    py: 1.5,
                  }}
                >
                  Contact Mentor
                </Button>
              </Box>
            </Grid>
          </Grid>

          <Divider sx={{ my: 3 }} />

          {/* Details Section */}
          <Grid container spacing={4}>
            <Grid item xs={12} md={8}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                About this Mentorship
              </Typography>
              <Typography variant="body1" sx={{ mb: 3, color: 'text.secondary', whiteSpace: 'pre-line' }}>
                {mentorship.description}
              </Typography>

              <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                Expectations from Mentee
              </Typography>
              <Typography variant="body1" sx={{ mb: 3, color: 'text.secondary', whiteSpace: 'pre-line' }}>
                {mentorship.expectations}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper elevation={0} sx={{ p: 3, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Mentorship Details
                </Typography>
                
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <Box>
                    <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary' }}>
                      Type
                    </Typography>
                    <Chip 
                      label={mentorship.type}
                      sx={{ 
                        bgcolor: '#e8f5e9',
                        color: '#2e7d32',
                      }}
                    />
                  </Box>

                  <Box>
                    <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary' }}>
                      Department
                    </Typography>
                    <Chip 
                      label={mentorship.department}
                      sx={{ 
                        bgcolor: '#f3e5f5',
                        color: '#7b1fa2',
                      }}
                    />
                  </Box>

                  <Box>
                    <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary' }}>
                      Experience
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <GroupIcon color="action" fontSize="small" />
                      <Typography>{mentorship.experience}</Typography>
                    </Box>
                  </Box>

                  <Box>
                    <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary' }}>
                      Availability
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LocationOnIcon color="action" fontSize="small" />
                      <Typography>{mentorship.availability}</Typography>
                    </Box>
                  </Box>

                  <Box>
                    <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary' }}>
                      Areas of Expertise
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                      {mentorship.expertise.split(',').map((skill, index) => (
                        <Chip 
                          key={index}
                          label={skill.trim()}
                          size="small"
                          sx={{ 
                            bgcolor: '#e3f2fd',
                            color: '#1976d2',
                          }}
                        />
                      ))}
                    </Box>
                  </Box>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Paper>
      </Container>
    </Box>
  );
};

export default MentorshipDetails; 