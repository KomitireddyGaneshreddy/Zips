import React, { useState, useEffect } from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  Button,
  Typography,
  Paper,
  Container,
  useTheme,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { authService } from '../services/api';
import EducationForm from '../components/profile/EducationForm';
import BasicInfoForm from '../components/profile/BasicInfoForm';
import SocialLinksForm from '../components/profile/SocialLinksForm';
import SkillsForm from '../components/profile/SkillsForm';
import ExperienceForm from '../components/profile/ExperienceForm';

const steps = [
  'Welcome',
  'Education',
  'Experience',
  'Skills',
  'Social Links',
];

const CompleteProfile = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    education: [],
    experience: [],
    skills: [],
    socialLinks: {
      linkedin: '',
      github: '',
      twitter: '',
      portfolio: '',
    },
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleFormSubmit = (stepData, step) => {
    setFormData((prev) => ({
      ...prev,
      [step]: stepData,
    }));
    handleNext();
  };

  const handleComplete = async () => {
    try {
      // Add education
      for (const education of formData.education) {
        await authService.addEducation(education);
      }

      // Add experience
      for (const experience of formData.experience) {
        await authService.addExperience(experience);
      }

      // Add skills
      await authService.updateSkills(formData.skills);

      // Add social links
      for (const [platform, url] of Object.entries(formData.socialLinks)) {
        if (url) {
          await authService.addSocialLink({ platform, url });
        }
      }

      navigate('/home');
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <BasicInfoForm
            onSubmit={() => handleNext()}
          />
        );
      case 1:
        return (
          <EducationForm
            initialData={formData.education}
            onSubmit={(data) => handleFormSubmit(data, 'education')}
          />
        );
      case 2:
        return (
          <ExperienceForm
            initialData={formData.experience}
            onSubmit={(data) => handleFormSubmit(data, 'experience')}
          />
        );
      case 3:
        return (
          <SkillsForm
            initialData={formData.skills}
            onSubmit={(data) => handleFormSubmit(data, 'skills')}
          />
        );
      case 4:
        return (
          <SocialLinksForm
            initialData={formData.socialLinks}
            onSubmit={(data) => handleFormSubmit(data, 'socialLinks')}
          />
        );
      default:
        return 'Unknown step';
    }
  };

  return (
    <Container maxWidth="md">
      <Paper
        elevation={3}
        sx={{
          p: 4,
          mt: 4,
          mb: 4,
          borderRadius: 2,
          backgroundColor: theme.palette.background.paper,
        }}
      >
        <Typography variant="h4" component="h1" gutterBottom align="center" color="primary">
          Complete Your Profile
        </Typography>
        <Typography variant="subtitle1" gutterBottom align="center" color="text.secondary" sx={{ mb: 4 }}>
          Let's get to know you better. This will help us personalize your experience.
        </Typography>

        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        <Box sx={{ mt: 4 }}>
          {activeStep === steps.length ? (
            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="h6" gutterBottom>
                All steps completed!
              </Typography>
              <Button variant="contained" onClick={handleComplete}>
                Go to Dashboard
              </Button>
            </Box>
          ) : (
            <>
              {getStepContent(activeStep)}
              {activeStep > 0 && (
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
                  <Button
                    disabled={activeStep === 0}
                    onClick={handleBack}
                    sx={{ mr: 1 }}
                  >
                    Back
                  </Button>
                  <Button
                    variant="contained"
                    onClick={handleNext}
                  >
                    {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
                  </Button>
                </Box>
              )}
            </>
          )}
        </Box>
      </Paper>
    </Container>
  );
};

export default CompleteProfile; 