import React, { useState, useContext } from 'react';
import {
  Box,
  Container,
  Typography,
  Card,
  CardContent,
  Grid,
  TextField,
  Button,
  Divider,
  Alert,
  Snackbar,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  MenuItem,
} from '@mui/material';
import SecurityIcon from '@mui/icons-material/Security';
import PersonIcon from '@mui/icons-material/Person';
import DeleteIcon from '@mui/icons-material/Delete';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { authService } from '../services/api';
import { useNavigate } from 'react-router-dom';

const Settings = () => {
  const { darkMode, setDarkMode } = useTheme();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [settings, setSettings] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showSnackbar, setShowSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');
  const [passwordLoading, setPasswordLoading] = useState(false);

  const handlePasswordChange = async () => {
    if (!settings.currentPassword || !settings.newPassword || !settings.confirmPassword) {
      setSnackbarSeverity('error');
      setSnackbarMessage('All password fields are required!');
      setShowSnackbar(true);
      return;
    }

    if (settings.newPassword !== settings.confirmPassword) {
      setSnackbarSeverity('error');
      setSnackbarMessage('New passwords do not match!');
      setShowSnackbar(true);
      return;
    }

    if (settings.newPassword.length < 8) {
      setSnackbarSeverity('error');
      setSnackbarMessage('Password must be at least 8 characters long!');
      setShowSnackbar(true);
      return;
    }

    setPasswordLoading(true);
    try {
      const response = await authService.changePassword({
        currentPassword: settings.currentPassword,
        newPassword: settings.newPassword
      });
      
      setSnackbarSeverity('success');
      setSnackbarMessage('Password updated successfully!');
      setShowSnackbar(true);
      setSettings({
        ...settings,
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
    } catch (error) {
      setSnackbarSeverity('error');
      setSnackbarMessage(error.response?.data?.message || 'Error updating password');
      setShowSnackbar(true);
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      console.log('Initiating account deletion...');
      const response = await authService.deleteAccount();
      console.log('Account deletion response:', response);
      
      if (response && response.message && response.message.includes('successfully')) {
        // Close the dialog first
        setShowDeleteDialog(false);
        
        // Then show success message
        setSnackbarSeverity('success');
        setSnackbarMessage('Account deleted successfully. You will be redirected to the login page.');
        setShowSnackbar(true);
        
        // Delay logout to show the success message
        setTimeout(() => {
          authService.logout();
          navigate('/login');
        }, 2000);
      } else {
        console.error('Unexpected response format:', response);
        throw new Error('Unexpected response from server');
      }
    } catch (error) {
      console.error('Delete account error:', error);
      console.error('Error details:', error.details || error.response?.data);
      
      setSnackbarSeverity('error');
      setSnackbarMessage(
        error.message || 
        error.response?.data?.message || 
        'Error deleting account. Please try again or contact support.'
      );
      setShowSnackbar(true);
      setShowDeleteDialog(false);
    }
  };

  const handleThemeChange = (newTheme) => {
    setDarkMode(newTheme === 'dark');
  };

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 3 }}>
          Settings
        </Typography>

        <Grid container spacing={3}>
          {/* Security Settings */}
          <Grid item xs={12} md={6}>
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                  <SecurityIcon color="primary" />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Security
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      type="password"
                      label="Current Password"
                      value={settings.currentPassword}
                      onChange={(e) => setSettings({ ...settings, currentPassword: e.target.value })}
                      disabled={passwordLoading}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      type="password"
                      label="New Password"
                      value={settings.newPassword}
                      onChange={(e) => setSettings({ ...settings, newPassword: e.target.value })}
                      disabled={passwordLoading}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      type="password"
                      label="Confirm New Password"
                      value={settings.confirmPassword}
                      onChange={(e) => setSettings({ ...settings, confirmPassword: e.target.value })}
                      disabled={passwordLoading}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Button
                      variant="contained"
                      onClick={handlePasswordChange}
                      disabled={!settings.currentPassword || !settings.newPassword || !settings.confirmPassword || passwordLoading}
                      sx={{
                        bgcolor: '#1a237e',
                        '&:hover': { bgcolor: '#0d1b60' },
                      }}
                    >
                      {passwordLoading ? 'Updating...' : 'Update Password'}
                    </Button>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          {/* Theme Settings */}
          <Grid item xs={12} md={6}>
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                bgcolor: 'background.paper',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                  <PersonIcon color="primary" />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Theme Settings
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      select
                      fullWidth
                      label="Theme"
                      value={darkMode ? 'dark' : 'light'}
                      onChange={(e) => handleThemeChange(e.target.value)}
                    >
                      <MenuItem value="light">Light</MenuItem>
                      <MenuItem value="dark">Dark</MenuItem>
                    </TextField>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          {/* Danger Zone */}
          <Grid item xs={12} md={6}>
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'error.light',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ color: 'error.main', fontWeight: 600, mb: 2 }}>
                  Danger Zone
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  Once you delete your account, there is no going back. Please be certain.
                </Typography>
                <Button
                  variant="outlined"
                  color="error"
                  startIcon={<DeleteIcon />}
                  onClick={() => setShowDeleteDialog(true)}
                >
                  Delete Account
                </Button>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Delete Account Confirmation Dialog */}
        <Dialog
          open={showDeleteDialog}
          onClose={() => setShowDeleteDialog(false)}
          aria-labelledby="delete-dialog-title"
          aria-describedby="delete-dialog-description"
          container={() => document.getElementById('dialog-root')}
          disablePortal={false}
          keepMounted={false}
          closeAfterTransition
          slotProps={{
            backdrop: {
              sx: { backgroundColor: 'rgba(0, 0, 0, 0.8)' }
            }
          }}
        >
          <DialogTitle id="delete-dialog-title" sx={{ color: 'error.main' }}>
            Delete Account
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="delete-dialog-description">
              Are you sure you want to delete your account? This action cannot be undone. All your data, including profile information, connections, and posts will be permanently deleted.
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button 
              onClick={() => setShowDeleteDialog(false)} 
              color="primary"
              tabIndex={0}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleDeleteAccount} 
              color="error" 
              variant="contained"
              tabIndex={0}
              autoFocus
            >
              Delete Account
            </Button>
          </DialogActions>
        </Dialog>

        {/* Snackbar for notifications */}
        <Snackbar
          open={showSnackbar}
          autoHideDuration={6000}
          onClose={() => setShowSnackbar(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          container={() => document.getElementById('dialog-root')}
        >
          <Alert
            onClose={() => setShowSnackbar(false)}
            severity={snackbarSeverity}
            sx={{ width: '100%' }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Container>
    </Box>
  );
};

export default Settings; 