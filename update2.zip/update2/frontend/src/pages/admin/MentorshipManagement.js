import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Chip,
  CircularProgress,
  Alert,
  FormControl,
  InputLabel,
  Select,
  Grid,
} from '@mui/material';
import {
  Delete as DeleteIcon,
  Visibility as ViewIcon,
  FilterList as FilterListIcon,
} from '@mui/icons-material';
import { mentorshipService } from '../../services/api';

const MentorshipManagement = () => {
  const [mentorships, setMentorships] = useState([]);
  const [filteredMentorships, setFilteredMentorships] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMentorship, setSelectedMentorship] = useState(null);
  const [openViewDialog, setOpenViewDialog] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [departmentFilter, setDepartmentFilter] = useState('All');
  
  // Predefined list of all departments
  const departments = [
    'All',
    'CSE',
    'ECE',
    'EEE',
    'MECH',
    'CIVIL'
  ];

  useEffect(() => {
    fetchMentorships();
  }, []);

  useEffect(() => {
    // Filter mentorships based on department
    if (departmentFilter === 'All') {
      setFilteredMentorships(mentorships);
    } else {
      setFilteredMentorships(mentorships.filter(m => m.department === departmentFilter));
    }
  }, [departmentFilter, mentorships]);

  const fetchMentorships = async () => {
    try {
      setLoading(true);
      const data = await mentorshipService.getAllMentorships();
      setMentorships(data);
      setFilteredMentorships(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch mentorship data');
      console.error('Error fetching mentorships:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleView = (mentorship) => {
    setSelectedMentorship(mentorship);
    setOpenViewDialog(true);
  };

  const handleDelete = (mentorship) => {
    setSelectedMentorship(mentorship);
    setOpenDeleteDialog(true);
  };

  const handleDeleteConfirm = async () => {
    try {
      await mentorshipService.adminDeleteMentorship(selectedMentorship.id);
      await fetchMentorships();
      setOpenDeleteDialog(false);
    } catch (err) {
      setError('Failed to delete mentorship');
      console.error('Error deleting mentorship:', err);
    }
  };

  const handleDepartmentFilterChange = (event) => {
    setDepartmentFilter(event.target.value);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: '#f8fafc', minHeight: '100vh', py: 3 }}>
      <Container maxWidth="xl">
        <Typography variant="h4" sx={{ mb: 4, fontWeight: 600 }}>
          Mentorship Management
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        {/* Department Filter */}
        <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel id="department-filter-label">Filter by Department</InputLabel>
                <Select
                  labelId="department-filter-label"
                  value={departmentFilter}
                  onChange={handleDepartmentFilterChange}
                  label="Filter by Department"
                  startAdornment={<FilterListIcon sx={{ mr: 1, color: 'text.secondary' }} />}
                >
                  {departments.map((dept) => (
                    <MenuItem key={dept} value={dept}>
                      {dept}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="body2" color="text.secondary">
                Showing {filteredMentorships.length} of {mentorships.length} mentorships
              </Typography>
            </Grid>
          </Grid>
        </Paper>

        <Paper sx={{ p: 3, borderRadius: 2 }}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Title</TableCell>
                  <TableCell>Mentor</TableCell>
                  <TableCell>Department</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredMentorships.map((mentorship) => (
                  <TableRow key={mentorship.id}>
                    <TableCell>{mentorship.title}</TableCell>
                    <TableCell>{`${mentorship.first_name} ${mentorship.last_name}`}</TableCell>
                    <TableCell>{mentorship.department}</TableCell>
                    <TableCell>{mentorship.type}</TableCell>
                    <TableCell>
                      <IconButton onClick={() => handleView(mentorship)} color="primary">
                        <ViewIcon />
                      </IconButton>
                      <IconButton onClick={() => handleDelete(mentorship)} color="error">
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>

        {/* View Dialog */}
        <Dialog open={openViewDialog} onClose={() => setOpenViewDialog(false)} maxWidth="md" fullWidth>
          <DialogTitle>Mentorship Details</DialogTitle>
          <DialogContent>
            {selectedMentorship && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="h6" gutterBottom>
                  {selectedMentorship.title}
                </Typography>
                <Typography variant="subtitle1" color="text.secondary" gutterBottom>
                  Mentor: {`${selectedMentorship.first_name} ${selectedMentorship.last_name}`}
                </Typography>
                <Typography paragraph>{selectedMentorship.description}</Typography>
                <Typography variant="subtitle2" gutterBottom>
                  Expertise: {selectedMentorship.expertise}
                </Typography>
                <Typography variant="subtitle2" gutterBottom>
                  Experience: {selectedMentorship.experience}
                </Typography>
                <Typography variant="subtitle2" gutterBottom>
                  Availability: {selectedMentorship.availability}
                </Typography>
                <Typography variant="subtitle2" gutterBottom>
                  Department: {selectedMentorship.department}
                </Typography>
                <Typography variant="subtitle2" gutterBottom>
                  Type: {selectedMentorship.type}
                </Typography>
                <Typography variant="subtitle2" gutterBottom>
                  Expectations: {selectedMentorship.expectations}
                </Typography>
                <Typography variant="subtitle2" gutterBottom>
                  Contact Email: {selectedMentorship.contact_email}
                </Typography>
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenViewDialog(false)}>Close</Button>
          </DialogActions>
        </Dialog>

        {/* Delete Dialog */}
        <Dialog open={openDeleteDialog} onClose={() => setOpenDeleteDialog(false)}>
          <DialogTitle>Delete Mentorship</DialogTitle>
          <DialogContent>
            <Typography>
              Are you sure you want to delete this mentorship opportunity? This action cannot be undone.
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDeleteDialog(false)}>Cancel</Button>
            <Button onClick={handleDeleteConfirm} variant="contained" color="error">
              Delete
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

export default MentorshipManagement; 