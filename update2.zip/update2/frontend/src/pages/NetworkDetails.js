import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Container,
  Typography,
  Paper,
  Avatar,
  Chip,
  Button,
  CircularProgress,
  Alert,
  Divider,
  Grid,
} from '@mui/material';
import { authService } from '../services/api';
import { format } from 'date-fns';

const NetworkDetails = () => {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  console.log('NetworkDetails mounted with id:', id);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        console.log('Fetching user data for id:', id);
        const data = await authService.getUserDetails(id);
        console.log('Raw user data received:', data);
        
        // Log specific fields to check their values
        console.log('User basic info:', {
          id: data.id,
          first_name: data.first_name,
          last_name: data.last_name,
          email: data.email,
          role: data.role,
          roll_number: data.roll_number,
          surname: data.surname,
          designation: data.designation,
          current_company: data.current_company,
          current_position: data.current_position,
          years_of_experience: data.years_of_experience,
          phone: data.phone,
          linkedin_url: data.linkedin_url,
          github_url: data.github_url,
          created_at: data.created_at,
          degree: data.degree,
          batch: data.batch,
          department: data.department,
          avatar: data.avatar
        });

        // Log related data
        console.log('User skills:', data.skills);
        console.log('User education:', data.education);
        console.log('User experience:', data.experience);
        
        setUser(data);
      } catch (err) {
        console.error('Error fetching user:', err);
        console.error('Error details:', {
          message: err.message,
          response: err.response,
          status: err.response?.status,
          data: err.response?.data
        });
        setError(err.message || 'Failed to load user details');
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [id]);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  if (!user) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="info">User not found</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Box sx={{ mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Avatar
              src={user.avatar || '/default-avatar.png'}
              alt={user.first_name || 'Unknown'}
              sx={{ width: 80, height: 80, mr: 3 }}
            />
            <Box>
              <Typography variant="h4" component="h1" gutterBottom>
                {user.first_name} {user.last_name}
              </Typography>
              <Typography variant="subtitle1" color="text.secondary">
                {user.designation || 'Alumni'}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {user.degree} • Batch {user.batch}
              </Typography>
            </Box>
          </Box>
        </Box>

        <Divider sx={{ my: 3 }} />

        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Box sx={{ mb: 4 }}>
              <Typography variant="h6" gutterBottom>
                Contact Information
              </Typography>
              <Typography variant="body1" paragraph>
                Email: {user.email}
              </Typography>
              {user.phone && (
                <Typography variant="body1" paragraph>
                  Phone: {user.phone}
                </Typography>
              )}
              {user.linkedin_url && (
                <Button
                  variant="outlined"
                  href={user.linkedin_url}
                  target="_blank"
                  sx={{ mr: 2 }}
                >
                  LinkedIn
                </Button>
              )}
              {user.github_url && (
                <Button
                  variant="outlined"
                  href={user.github_url}
                  target="_blank"
                  sx={{ mr: 2 }}
                >
                  GitHub
                </Button>
              )}
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Box sx={{ mb: 4 }}>
              <Typography variant="h6" gutterBottom>
                Professional Information
              </Typography>
              <Typography variant="body1" paragraph>
                Current Company: {user.current_company || 'Not specified'}
              </Typography>
              <Typography variant="body1" paragraph>
                Current Position: {user.current_position || 'Not specified'}
              </Typography>
              <Typography variant="body1" paragraph>
                Years of Experience: {user.years_of_experience || 'Not specified'}
              </Typography>
            </Box>
          </Grid>
        </Grid>

        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Skills
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {user.skills?.map((skill, index) => (
              <Chip
                key={index}
                label={skill}
                color="primary"
                variant="outlined"
              />
            ))}
          </Box>
        </Box>

        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Education
          </Typography>
          {user.education?.map((edu, index) => (
            <Box key={index} sx={{ mb: 2 }}>
              <Typography variant="subtitle1">
                {edu.degree} in {edu.field}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {edu.institution} • {edu.graduation_year}
              </Typography>
            </Box>
          ))}
        </Box>

        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Experience
          </Typography>
          {user.experience?.map((exp, index) => (
            <Box key={index} sx={{ mb: 2 }}>
              <Typography variant="subtitle1">
                {exp.role} at {exp.company}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {exp.start_date} - {exp.end_date || 'Present'}
              </Typography>
              {exp.description && (
                <Typography variant="body2" sx={{ mt: 1 }}>
                  {exp.description}
                </Typography>
              )}
            </Box>
          ))}
        </Box>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="body2" color="text.secondary">
            Member since: {user.created_at ? format(new Date(user.created_at), 'MMMM d, yyyy') : 'Unknown'}
          </Typography>
          <Button
            variant="contained"
            color="primary"
            href={`mailto:${user.email}`}
          >
            Contact
          </Button>
        </Box>
      </Paper>
    </Container>
  );
};

export default NetworkDetails; 