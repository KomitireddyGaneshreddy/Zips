import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Container,
  Typography,
  Card,
  CardContent,
  Grid,
  Avatar,
  Button,
  Chip,
  Divider,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  LocationOn as LocationIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  AccessTime as AccessTimeIcon,
  School as SchoolIcon,
} from '@mui/icons-material';
import { formatDistanceToNow } from 'date-fns';
import { jobService } from '../services/api';

const JobDetails = () => {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        setLoading(true);
        const data = await jobService.getJobById(id);
        console.log('Job data received:', data);
        setJob(data);
      } catch (err) {
        setError(err.message || 'Failed to fetch job details');
        console.error('Error fetching job details:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();
  }, [id]);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  if (!job) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Alert severity="info">Job not found</Alert>
      </Container>
    );
  }

  console.log('Job data before rendering:', job);

  const postedBy = {
    name: `${job.first_name || ''} ${job.last_name || ''}`.trim() || 'Unknown User',
    designation: job.role || 'Unknown',
    avatar: '#1a237e'
  };

  console.log('Processed postedBy:', postedBy);

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        <Card elevation={0} sx={{ borderRadius: 2, border: '1px solid', borderColor: 'divider' }}>
          <CardContent sx={{ p: 4 }}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={8}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                  <Avatar 
                    sx={{ 
                      width: 64,
                      height: 64,
                      bgcolor: postedBy.avatar,
                      fontSize: '1.5rem'
                    }}
                  >
                    {postedBy.name[0]}
                  </Avatar>
                  <Box>
                    <Typography variant="h4" sx={{ fontWeight: 600, mb: 1 }}>
                      {job.title}
                    </Typography>
                    <Typography variant="h6" color="text.secondary">
                      {job.company}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Posted by {postedBy.name} • {postedBy.designation}
                    </Typography>
                  </Box>
                </Box>

                <Box sx={{ mb: 4 }}>
                  <Typography variant="h6" sx={{ mb: 2 }}>Job Details</Typography>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        <LocationIcon color="action" />
                        <Typography variant="body1">{job.location || 'Location not specified'}</Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        <WorkIcon color="action" />
                        <Typography variant="body1">{job.type || 'Type not specified'}</Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        <BusinessIcon color="action" />
                        <Typography variant="body1">{job.department || 'Department not specified'}</Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        <SchoolIcon color="action" />
                        <Typography variant="body1">{job.experience || 'Experience not specified'}</Typography>
                      </Box>
                    </Grid>
                  </Grid>
                </Box>

                <Box sx={{ mb: 4 }}>
                  <Typography variant="h6" sx={{ mb: 2 }}>Job Description</Typography>
                  <Typography variant="body1" color="text.secondary" sx={{ whiteSpace: 'pre-line' }}>
                    {job.description || 'No description provided'}
                  </Typography>
                </Box>

                <Box sx={{ mb: 4 }}>
                  <Typography variant="h6" sx={{ mb: 2 }}>Requirements</Typography>
                  <Typography variant="body1" color="text.secondary" sx={{ whiteSpace: 'pre-line' }}>
                    {job.requirements || 'No requirements specified'}
                  </Typography>
                </Box>
              </Grid>

              <Grid item xs={12} md={4}>
                <Box sx={{ 
                  position: 'sticky',
                  top: 20,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 2
                }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, color: 'text.secondary' }}>
                    <AccessTimeIcon />
                    <Typography variant="body2">
                      Posted {job.postedAt ? formatDistanceToNow(job.postedAt, { addSuffix: true }) : 'recently'}
                    </Typography>
                  </Box>

                  {job.deadline && (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, color: 'error.main' }}>
                      <AccessTimeIcon />
                      <Typography variant="body2">
                        Deadline: {new Date(job.deadline).toLocaleDateString()}
                      </Typography>
                    </Box>
                  )}

                  <Button
                    variant="contained"
                    fullWidth
                    size="large"
                    href={job.application_link}
                    target="_blank"
                    disabled={!job.application_link}
                    sx={{
                      bgcolor: '#1a237e',
                      '&:hover': { bgcolor: '#0d1b60' },
                      py: 1.5,
                    }}
                  >
                    {job.application_link ? 'Apply Now' : 'Application Link Not Available'}
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Container>
    </Box>
  );
};

export default JobDetails; 