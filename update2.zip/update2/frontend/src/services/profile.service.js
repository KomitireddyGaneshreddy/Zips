import axios from 'axios';

const API_URL=process.env.REACT_APP_API_URL || 'http://localhost:5001/api';

// Create axios instance with default config
const axiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor to add auth token
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle token errors
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

const profileService = {
  // Update user profile
  updateProfile: async (data) => {
    try {
      const response = await axiosInstance.put('/users/profile', data);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Error updating profile' };
    }
  },

  // Insert social links
  insertSocialLinks: async (data) => {
    try {
      const response = await axiosInstance.post('/users/social-links', data);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Error inserting social links' };
    }
  },

  // Update social links
  updateSocialLinks: async (data) => {
    try {
      // Transform the data to match backend expectations
      const formattedData = {
        linkedin: data.linkedin_url,
        github: data.github_url,
        twitter: data.twitter_url,
        portfolio: data.portfolio_url
      };
      const response = await axiosInstance.put('/users/profile/social-links', formattedData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Error updating social links' };
    }
  },

  // Insert skills
  insertSkills: async (data) => {
    try {
      const response = await axiosInstance.post('/users/skills', { skills: data });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Error inserting skills' };
    }
  },

  // Update skills
  updateSkills: async (data) => {
    try {
      const response = await axiosInstance.put('/users/skills', { skills: data });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Error updating skills' };
    }
  },

  // Insert experience
  insertExperience: async (data) => {
    try {
      const response = await axiosInstance.post('/users/profile/experience', data);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Error inserting experience' };
    }
  },
  

  // Insert education
  insertEducation: async (data) => {
    try {
      const response = await axiosInstance.post('/users/profile/education', data);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Error inserting education' };
    }
  }
};

export default profileService; 