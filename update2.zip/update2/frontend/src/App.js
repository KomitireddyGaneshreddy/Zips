import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import ThemeWrapper from './components/ThemeWrapper';
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';
import UserRoute from './components/UserRoute';
import Layout from './components/layout/Layout';
import AdminLayout from './components/layout/AdminLayout';
import { useAuth } from './context/AuthContext';

// Pages
import Login from './pages/Login';
import NewUser from './pages/NewUser';
import Home from './pages/Home';
import Jobs from './pages/Jobs';
import Events from './pages/Events';
import Profile from './pages/Profile';
import Network from './pages/Network';
import Settings from './pages/Settings';
import Mentorship from './pages/Mentorship';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminEventManagement from './pages/admin/EventManagement';
import AdminJobManagement from './pages/admin/JobManagement';
import AlumniNetwork from './pages/admin/AlumniNetwork';
import UserManagement from './pages/admin/UserManagement';
import CredentialManagement from './pages/admin/CredentialManagement';
import MentorshipManagement from './pages/admin/MentorshipManagement';
import CompleteProfile from './pages/CompleteProfile';
import JobDetails from './pages/JobDetails';
import EventDetails from './pages/EventDetails';
import MentorshipDetails from './pages/MentorshipDetails';
import NetworkDetails from './pages/NetworkDetails';

// Wrapper component to choose layout based on user role
const LayoutWrapper = ({ children }) => {
  const { user } = useAuth();
  
  if (user?.role === 'admin') {
    return <AdminLayout>{children}</AdminLayout>;
  }
  
  return <Layout>{children}</Layout>;
};

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <ThemeWrapper>
          <Router>
            <Routes>
              {/* Public routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<NewUser />} />
              <Route path="/new-user" element={<NewUser />} />
              <Route path="/complete-profile" element={<CompleteProfile />} />
              
              {/* Admin routes - only accessible to admin users */}
              <Route
                path="/admin/users"
                element={
                  <AdminRoute>
                    <AdminLayout>
                      <UserManagement />
                    </AdminLayout>
                  </AdminRoute>
                }
              />
              <Route
                path="/admin/events"
                element={
                  <AdminRoute>
                    <AdminLayout>
                      <AdminEventManagement />
                    </AdminLayout>
                  </AdminRoute>
                }
              />
              <Route
                path="/admin/jobs"
                element={
                  <AdminRoute>
                    <AdminLayout>
                      <AdminJobManagement />
                    </AdminLayout>
                  </AdminRoute>
                }
              />
              <Route
                path="/admin/network"
                element={
                  <AdminRoute>
                    <AdminLayout>
                      <AlumniNetwork />
                    </AdminLayout>
                  </AdminRoute>
                }
              />
              <Route
                path="/admin/credentials"
                element={
                  <AdminRoute>
                    <AdminLayout>
                      <CredentialManagement />
                    </AdminLayout>
                  </AdminRoute>
                }
              />
              <Route
                path="/admin/mentorship"
                element={
                  <AdminRoute>
                    <AdminLayout>
                      <MentorshipManagement />
                    </AdminLayout>
                  </AdminRoute>
                }
              />
              
              {/* Admin Dashboard - only accessible to admin users */}
              <Route
                path="/adminDashboard"
                element={
                  <AdminRoute>
                    <AdminLayout>
                      <AdminDashboard />
                    </AdminLayout>
                  </AdminRoute>
                }
              />
              
              {/* User routes - only accessible to non-admin users */}
              <Route
                path="/home"
                element={
                  <UserRoute>
                    <Layout>
                      <Home />
                    </Layout>
                  </UserRoute>
                }
              />
              <Route
                path="/jobs"
                element={
                  <UserRoute>
                    <Layout>
                      <Jobs />
                    </Layout>
                  </UserRoute>
                }
              />
              <Route
                path="/events"
                element={
                  <UserRoute>
                    <Layout>
                      <Events />
                    </Layout>
                  </UserRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <UserRoute>
                    <Layout>
                      <Profile />
                    </Layout>
                  </UserRoute>
                }
              />
              <Route
                path="/network"
                element={
                  <UserRoute>
                    <Layout>
                      <Network />
                    </Layout>
                  </UserRoute>
                }
              />
              <Route
                path="/settings"
                element={
                  <UserRoute>
                    <Layout>
                      <Settings />
                    </Layout>
                  </UserRoute>
                }
              />
              <Route
                path="/mentorship"
                element={
                  <UserRoute>
                    <Layout>
                      <Mentorship />
                    </Layout>
                  </UserRoute>
                }
              />
              <Route
                path="/mentorship/:id"
                element={
                  <UserRoute>
                    <Layout>
                      <MentorshipDetails />
                    </Layout>
                  </UserRoute>
                }
              />
              
              {/* Redirect from root to login */}
              <Route path="/" element={<Navigate to="/login" />} />
              
              {/* Catch-all redirect to appropriate dashboard based on user role */}
              <Route
                path="*"
                element={
                  <ProtectedRoute>
                    <RoleBasedRedirect />
                  </ProtectedRoute>
                }
              />

              <Route path="/jobs/:id" element={<JobDetails />} />
              <Route path="/events/:id" element={<EventDetails />} />
              <Route
                path="/network/:id"
                element={
                  <UserRoute>
                    <Layout>
                      <NetworkDetails />
                    </Layout>
                  </UserRoute>
                }
              />
            </Routes>
          </Router>
        </ThemeWrapper>
      </ThemeProvider>
    </AuthProvider>
  );
}

// Component to redirect users based on their role
const RoleBasedRedirect = () => {
  const { user } = useAuth();
  
  if (user?.role === 'admin') {
    return <Navigate to="/adminDashboard" />;
  }
  
  return <Navigate to="/home" />;
};

export default App;
