const bcrypt = require('bcryptjs');
const db = require('../config/db.config');

async function updatePasswords() {
  try {
    console.log('Starting password update...');
    
    // Generate a new hash for "password123"
    const hashedPassword = await bcrypt.hash('password123', 10);
    console.log('Generated new password hash:', hashedPassword);
    
    // Update all users with the new password hash
    const [result] = await db.execute(
      'UPDATE users SET password = ?',
      [hashedPassword]
    );
    
    console.log(`Updated ${result.affectedRows} user passwords successfully`);
    
    // Verify the update by checking a few users
    const [users] = await db.execute(
      'SELECT id, email, password FROM users LIMIT 3'
    );
    
    console.log('Sample users after update:');
    users.forEach(user => {
      console.log(`User ID: ${user.id}, Email: ${user.email}`);
    });
    
    console.log('Password update completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Error updating passwords:', error);
    process.exit(1);
  }
}

updatePasswords(); 