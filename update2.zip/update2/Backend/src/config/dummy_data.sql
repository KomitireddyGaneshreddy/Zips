-- Dummy data for JNTUA Alumni Network

-- Insert skills
INSERT INTO skills (name) VALUES 
-- Technical Skills
('JavaScript'), ('React'), ('Node.js'), ('Python'), ('Java'), ('C++'), 
('SQL'), ('MongoDB'), ('AWS'), ('Docker'), ('Machine Learning'),
('Data Science'), ('DevOps'), ('UI/UX Design'),
-- Mechanical Skills
('CAD/CAM'), ('3D Modeling'), ('AutoCAD'), ('Thermal Engineering'), ('Fluid Mechanics'),
-- Electrical Skills
('Circuit Design'), ('Power Systems'), ('Microcontrollers'), ('VLSI Design'), ('Control Systems'),
-- Civil Skills
('Structural Design'), ('Construction Management'), ('Environmental Engineering'), ('Surveying'), ('Transportation Engineering'),
-- Chemical Skills
('Process Design'), ('Thermodynamics'), ('Chemical Reactions'), ('Plant Design'), ('Quality Control'),
-- Soft Skills
('Communication'), ('Leadership'), ('Problem Solving'), ('Teamwork'), ('Project Management');

-- Insert admin user
INSERT INTO users (
    roll_number, surname, first_name, last_name, date_of_birth, 
    email, current_phone, password, department, role
) VALUES (
    'ADMIN001', 'Admin', 'System', 'Administrator', '1990-01-01',
    'admin@jntua.ac.in', '9876543210', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CSE', 'admin'
);

-- Insert alumni users from different branches
INSERT INTO users (
    roll_number, surname, first_name, last_name, date_of_birth, 
    email, current_phone, password, department
) VALUES 
-- CSE Department
('19CS001', 'Kumar', 'Rajesh', 'Reddy', '2001-05-15', 'rajesh.kumar@example.com', '9876543211', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CSE'),
('19CS002', 'Srinivas', 'Lakshmi', 'Priya', '2001-08-22', 'lakshmi.srinivas@example.com', '9876543212', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CSE'),
('19CS003', 'Rao', 'Sai', 'Krishna', '2001-03-10', 'sai.krishna@example.com', '9876543213', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CSE'),
('19CS004', 'Reddy', 'Anjali', 'Kumari', '2001-11-05', 'anjali.reddy@example.com', '9876543214', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CSE'),

-- Mechanical Department
('19ME001', 'Sharma', 'Rahul', 'Kumar', '2001-06-15', 'rahul.sharma@example.com', '9876543215', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'MECH'),
('19ME002', 'Verma', 'Amit', 'Singh', '2001-07-22', 'amit.verma@example.com', '9876543216', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'MECH'),
('19ME003', 'Patel', 'Ravi', 'Kumar', '2001-04-10', 'ravi.patel@example.com', '9876543217', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'MECH'),
('19ME004', 'Singh', 'Neha', 'Kumari', '2001-12-05', 'neha.singh@example.com', '9876543218', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'MECH'),

-- Electrical Department
('19EE001', 'Gupta', 'Arun', 'Kumar', '2001-05-20', 'arun.gupta@example.com', '9876543219', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'EEE'),
('19EE002', 'Jain', 'Priya', 'Sharma', '2001-08-25', 'priya.jain@example.com', '9876543220', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'EEE'),
('19EE003', 'Kumar', 'Vikram', 'Singh', '2001-03-15', 'vikram.kumar@example.com', '9876543221', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'EEE'),
('19EE004', 'Mishra', 'Sneha', 'Kumari', '2001-11-10', 'sneha.mishra@example.com', '9876543222', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'EEE'),

-- Civil Department
('19CE001', 'Reddy', 'Karthik', 'Kumar', '2001-07-15', 'karthik.reddy@example.com', '9876543223', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CIVIL'),
('19CE002', 'Sharma', 'Anita', 'Kumari', '2001-09-22', 'anita.sharma@example.com', '9876543224', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CIVIL'),
('19CE003', 'Singh', 'Rajat', 'Kumar', '2001-04-20', 'rajat.singh@example.com', '9876543225', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CIVIL'),
('19CE004', 'Verma', 'Pooja', 'Kumari', '2001-12-15', 'pooja.verma@example.com', '9876543226', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CIVIL'),

-- Chemical Department
('19CH001', 'Patel', 'Suresh', 'Kumar', '2001-06-25', 'suresh.patel@example.com', '9876543227', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CHEM'),
('19CH002', 'Gupta', 'Meera', 'Kumari', '2001-08-30', 'meera.gupta@example.com', '9876543228', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CHEM'),
('19CH003', 'Kumar', 'Ajay', 'Singh', '2001-03-25', 'ajay.kumar@example.com', '9876543229', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CHEM'),
('19CH004', 'Jain', 'Ritu', 'Kumari', '2001-11-20', 'ritu.jain@example.com', '9876543230', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'CHEM');

-- Insert user profiles with diverse roles
INSERT INTO user_profiles (user_id, bio, current_location, current_company, designation) VALUES
-- CSE Profiles
(2, 'Software developer with expertise in web technologies.', 'Hyderabad, India', 'Tech Solutions Inc.', 'Senior Software Engineer'),
(3, 'Data scientist specializing in ML and AI.', 'Bangalore, India', 'Data Analytics Corp', 'Data Scientist'),
(4, 'Full-stack developer with modern tech stack knowledge.', 'Chennai, India', 'WebTech Solutions', 'Full Stack Developer'),
(5, 'UI/UX designer creating intuitive interfaces.', 'Mumbai, India', 'Design Studio', 'UI/UX Designer'),

-- Mechanical Profiles
(6, 'Mechanical design engineer specializing in CAD/CAM.', 'Pune, India', 'Auto Engineering Ltd', 'Design Engineer'),
(7, 'Thermal systems expert with industry experience.', 'Delhi, India', 'Thermal Solutions Inc', 'Thermal Engineer'),
(8, 'Manufacturing specialist in automotive sector.', 'Chennai, India', 'Auto Manufacturing Co', 'Production Engineer'),
(9, 'Product design engineer with 3D modeling expertise.', 'Bangalore, India', 'Product Design Ltd', 'Product Engineer'),

-- Electrical Profiles
(10, 'Power systems engineer with grid expertise.', 'Hyderabad, India', 'Power Grid Corp', 'Power Systems Engineer'),
(11, 'VLSI design specialist in semiconductor industry.', 'Bangalore, India', 'Chip Design Inc', 'VLSI Engineer'),
(12, 'Control systems expert in automation.', 'Mumbai, India', 'Automation Solutions', 'Control Engineer'),
(13, 'Microcontroller programmer for embedded systems.', 'Pune, India', 'Embedded Systems Ltd', 'Embedded Engineer'),

-- Civil Profiles
(14, 'Structural engineer designing sustainable buildings.', 'Delhi, India', 'Construction Corp', 'Structural Engineer'),
(15, 'Transportation infrastructure specialist.', 'Mumbai, India', 'Infrastructure Ltd', 'Transportation Engineer'),
(16, 'Environmental engineer focusing on sustainability.', 'Bangalore, India', 'Green Solutions Inc', 'Environmental Engineer'),
(17, 'Construction manager handling large projects.', 'Chennai, India', 'Builders Co', 'Construction Manager'),

-- Chemical Profiles
(18, 'Process engineer in petrochemical industry.', 'Mumbai, India', 'Petrochem Ltd', 'Process Engineer'),
(19, 'Quality control specialist in pharmaceutical.', 'Hyderabad, India', 'Pharma Corp', 'Quality Engineer'),
(20, 'Plant design engineer for chemical facilities.', 'Pune, India', 'Chemical Plants Inc', 'Plant Engineer'),
(21, 'Research scientist in polymer chemistry.', 'Bangalore, India', 'Polymer Research Lab', 'Research Scientist');

-- Insert user skills with branch-specific expertise
INSERT INTO user_skills (user_id, skill_id) VALUES
-- CSE Skills
(2, 1), (2, 2), (2, 3), (2, 7), -- Software Engineer (JavaScript, React, Node.js, SQL)
(3, 4), (3, 11), (3, 12), (3, 33), -- Data Scientist (Python, Machine Learning, Data Science, Communication)
(4, 1), (4, 2), (4, 3), (4, 34), -- Full Stack Developer (JavaScript, React, Node.js, Leadership)
(5, 14), (5, 33), (5, 34), (5, 35), -- UI/UX Designer (UI/UX Design, Communication, Leadership, Problem Solving)

-- Mechanical Skills
(6, 16), (6, 17), (6, 18), (6, 33), -- Design Engineer (CAD/CAM, 3D Modeling, AutoCAD, Communication)
(7, 19), (7, 20), (7, 34), (7, 35), -- Thermal Engineer (Thermal Engineering, Fluid Mechanics, Leadership, Problem Solving)
(8, 16), (8, 17), (8, 33), (8, 34), -- Production Engineer (CAD/CAM, 3D Modeling, Communication, Leadership)
(9, 17), (9, 18), (9, 33), (9, 35), -- Product Engineer (3D Modeling, AutoCAD, Communication, Problem Solving)

-- Electrical Skills
(10, 21), (10, 22), (10, 33), (10, 34), -- Power Systems Engineer (Circuit Design, Power Systems, Communication, Leadership)
(11, 23), (11, 24), (11, 33), (11, 35), -- VLSI Engineer (Microcontrollers, VLSI Design, Communication, Problem Solving)
(12, 24), (12, 25), (12, 33), (12, 34), -- Control Engineer (VLSI Design, Control Systems, Communication, Leadership)
(13, 23), (13, 24), (13, 33), (13, 35), -- Embedded Engineer (Microcontrollers, VLSI Design, Communication, Problem Solving)

-- Civil Skills
(14, 26), (14, 27), (14, 33), (14, 34), -- Structural Engineer (Structural Design, Construction Management, Communication, Leadership)
(15, 29), (15, 30), (15, 33), (15, 35), -- Transportation Engineer (Surveying, Transportation Engineering, Communication, Problem Solving)
(16, 28), (16, 29), (16, 33), (16, 34), -- Environmental Engineer (Environmental Engineering, Surveying, Communication, Leadership)
(17, 27), (17, 35), (17, 33), (17, 34), -- Construction Manager (Construction Management, Problem Solving, Communication, Leadership)

-- Chemical Skills
(18, 31), (18, 32), (18, 33), (18, 34), -- Process Engineer (Process Design, Thermodynamics, Communication, Leadership)
(19, 35), (19, 32), (19, 33), (19, 34), -- Quality Engineer (Quality Control, Thermodynamics, Communication, Leadership)
(20, 31), (20, 34), (20, 33), (20, 35), -- Plant Engineer (Process Design, Leadership, Communication, Problem Solving)
(21, 32), (21, 33), (21, 34), (21, 35); -- Research Scientist (Thermodynamics, Communication, Leadership, Problem Solving)

-- Insert education
INSERT INTO education (user_id, degree, institution, year, grade) VALUES
(2, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.5 CGPA'),
(3, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '9.0 CGPA'),
(4, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.8 CGPA'),
(5, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.7 CGPA'),
(6, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.9 CGPA'),
(7, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.6 CGPA'),
(8, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.4 CGPA'),
(9, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.3 CGPA'),
(10, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.2 CGPA'),
(11, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.1 CGPA'),
(12, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '8.0 CGPA'),
(13, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '7.9 CGPA'),
(14, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '7.8 CGPA'),
(15, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '7.7 CGPA'),
(16, 'B.Tech in Computer Science', 'JNTUA', '2019-2023', '7.6 CGPA');

-- Insert experience
INSERT INTO experience (user_id, role, company, duration, description) VALUES
(2, 'Software Engineer', 'Tech Solutions Inc.', '2023-Present', 'Working on web application development using React and Node.js'),
(3, 'Data Analyst', 'Data Analytics Corp', '2023-Present', 'Analyzing data and building machine learning models'),
(4, 'Junior Developer', 'WebTech Solutions', '2023-Present', 'Developing full-stack web applications'),
(5, 'UI Designer', 'Design Studio', '2023-Present', 'Creating user interfaces for web and mobile applications'),
(6, 'DevOps Engineer', 'Cloud Systems Ltd', '2023-Present', 'Managing cloud infrastructure and CI/CD pipelines'),
(7, 'Project Coordinator', 'Project Management Inc', '2023-Present', 'Coordinating software development projects'),
(8, 'Backend Developer', 'Backend Solutions', '2023-Present', 'Developing backend services using Node.js and databases'),
(9, 'Frontend Developer', 'Frontend Tech', '2023-Present', 'Creating user interfaces using React and modern JavaScript'),
(10, 'Mobile Developer', 'Mobile Apps Inc', '2023-Present', 'Developing mobile applications using React Native'),
(11, 'QA Engineer', 'Quality Assurance Corp', '2023-Present', 'Testing software applications and ensuring quality'),
(12, 'Product Manager', 'Product Management Inc', '2023-Present', 'Managing product development and user experience'),
(13, 'Security Engineer', 'Security Solutions', '2023-Present', 'Ensuring application security and compliance'),
(14, 'Database Administrator', 'Database Systems', '2023-Present', 'Managing databases and ensuring data integrity'),
(15, 'System Administrator', 'System Management Inc', '2023-Present', 'Managing system infrastructure and ensuring uptime'),
(16, 'Business Analyst', 'Business Analytics Corp', '2023-Present', 'Analyzing business data and providing insights');

-- Insert social links
INSERT INTO social_links (user_id, platform, url) VALUES
(2, 'LinkedIn', 'https://linkedin.com/in/rajeshkumar'),
(2, 'GitHub', 'https://github.com/rajeshkumar'),
(3, 'LinkedIn', 'https://linkedin.com/in/lakshmisrinivas'),
(3, 'Twitter', 'https://twitter.com/lakshmisrinivas'),
(4, 'LinkedIn', 'https://linkedin.com/in/saikrishna'),
(4, 'GitHub', 'https://github.com/saikrishna'),
(5, 'LinkedIn', 'https://linkedin.com/in/anjalireddy'),
(5, 'Behance', 'https://behance.net/anjalireddy'),
(6, 'LinkedIn', 'https://linkedin.com/in/vijaykrishna'),
(6, 'GitHub', 'https://github.com/vijaykrishna'),
(7, 'LinkedIn', 'https://linkedin.com/in/priyalakshmi'),
(7, 'Twitter', 'https://twitter.com/priyalakshmi'),
(8, 'LinkedIn', 'https://linkedin.com/in/srinivaslakshmi'),
(8, 'GitHub', 'https://github.com/srinivaslakshmi'),
(9, 'LinkedIn', 'https://linkedin.com/in/anjalikumari'),
(9, 'GitHub', 'https://github.com/anjalikumari'),
(10, 'LinkedIn', 'https://linkedin.com/in/vijayrao'),
(10, 'GitHub', 'https://github.com/vijayrao'),
(11, 'LinkedIn', 'https://linkedin.com/in/priyareddy'),
(11, 'GitHub', 'https://github.com/priyareddy'),
(12, 'LinkedIn', 'https://linkedin.com/in/lakshmikrishna'),
(12, 'Twitter', 'https://twitter.com/lakshmikrishna'),
(13, 'LinkedIn', 'https://linkedin.com/in/anjalisai'),
(13, 'GitHub', 'https://github.com/anjalisai'),
(14, 'LinkedIn', 'https://linkedin.com/in/vijaylakshmi'),
(14, 'GitHub', 'https://github.com/vijaylakshmi'),
(15, 'LinkedIn', 'https://linkedin.com/in/priyakumari'),
(15, 'GitHub', 'https://github.com/priyakumari'),
(16, 'LinkedIn', 'https://linkedin.com/in/srinivasrao'),
(16, 'GitHub', 'https://github.com/srinivasrao');

-- Insert jobs
INSERT INTO jobs (
    posted_by, title, company, location, type, remote, department, 
    experience, salary, description, requirements, application_link, deadline
) VALUES
(2, 'Senior Software Engineer', 'Tech Solutions Inc.', 'Hyderabad, India', 'Full-time', FALSE, 'CSE', '3-5 years', '₹15-20 LPA', 
'We are looking for a Senior Software Engineer to join our team. The ideal candidate will have experience in web development using React and Node.js.',
'1. 3-5 years of experience in web development\n2. Strong knowledge of React and Node.js\n3. Experience with databases like MySQL and MongoDB\n4. Good communication skills',
'https://techsolutions.com/careers', '2023-12-31'),
(3, 'Data Scientist', 'Data Analytics Corp', 'Bangalore, India', 'Full-time', FALSE, 'CSE', '2-4 years', '₹12-18 LPA',
'We are looking for a Data Scientist to join our team. The ideal candidate will have experience in machine learning and data analysis.',
'1. 2-4 years of experience in data science\n2. Strong knowledge of Python and machine learning libraries\n3. Experience with data visualization\n4. Good communication skills',
'https://dataanalytics.com/careers', '2023-12-31'),
(4, 'Full Stack Developer', 'WebTech Solutions', 'Chennai, India', 'Full-time', TRUE, 'CSE', '1-3 years', '₹8-12 LPA',
'We are looking for a Full Stack Developer to join our team. The ideal candidate will have experience in web development using React and Node.js.',
'1. 1-3 years of experience in web development\n2. Strong knowledge of React and Node.js\n3. Experience with databases\n4. Good communication skills',
'https://webtech.com/careers', '2023-12-31'),
(5, 'UI/UX Designer', 'Design Studio', 'Mumbai, India', 'Full-time', FALSE, 'CSE', '2-4 years', '₹10-15 LPA',
'We are looking for a UI/UX Designer to join our team. The ideal candidate will have experience in designing user interfaces for web and mobile applications.',
'1. 2-4 years of experience in UI/UX design\n2. Strong knowledge of design tools like Figma and Adobe XD\n3. Experience with user research and usability testing\n4. Good communication skills',
'https://designstudio.com/careers', '2023-12-31'),
(6, 'DevOps Engineer', 'Cloud Systems Ltd', 'Pune, India', 'Full-time', TRUE, 'CSE', '3-5 years', '₹15-20 LPA',
'We are looking for a DevOps Engineer to join our team. The ideal candidate will have experience in cloud infrastructure and CI/CD pipelines.',
'1. 3-5 years of experience in DevOps\n2. Strong knowledge of AWS and Docker\n3. Experience with CI/CD tools\n4. Good communication skills',
'https://cloudsystems.com/careers', '2023-12-31');

-- Insert events
INSERT INTO events (
    created_by, title, description, date, time, location, type, 
    registration_link, max_attendees, department
) VALUES
(2, 'Web Development Workshop', 'Learn the basics of web development using React and Node.js.', '2023-12-15', '10:00:00', 'JNTUA Campus, Anantapur', 'In-Person',
'https://jntua.ac.in/events/webdev', 50, 'CSE'),
(3, 'Data Science Seminar', 'Learn about the latest trends in data science and machine learning.', '2023-12-20', '14:00:00', 'JNTUA Campus, Anantapur', 'In-Person',
'https://jntua.ac.in/events/datascience', 100, 'CSE'),
(4, 'Alumni Meet 2023', 'Annual alumni meet to network and share experiences.', '2023-12-25', '11:00:00', 'JNTUA Campus, Anantapur', 'In-Person',
'https://jntua.ac.in/events/alumnimeet', 200, 'CSE'),
(5, 'UI/UX Design Workshop', 'Learn the basics of UI/UX design using Figma.', '2023-12-30', '10:00:00', 'JNTUA Campus, Anantapur', 'In-Person',
'https://jntua.ac.in/events/uiux', 50, 'CSE'),
(6, 'Cloud Computing Seminar', 'Learn about cloud computing and its applications.', '2024-01-05', '14:00:00', 'JNTUA Campus, Anantapur', 'In-Person',
'https://jntua.ac.in/events/cloud', 100, 'CSE');

-- Insert mentorship
INSERT INTO mentorship (
    mentor_id, title, description, expertise, experience, availability, 
    department, type, expectations, contact_email
) VALUES
(2, 'Web Development Mentoring', 'Get guidance on web development using React and Node.js.', 'React, Node.js, JavaScript', '3 years', 'Weekends, 2 hours per session',
'CSE', 'Technical Mentoring', 'Basic knowledge of HTML, CSS, and JavaScript', 'rajesh.kumar@example.com'),
(3, 'Data Science Mentoring', 'Get guidance on data science and machine learning.', 'Python, Machine Learning, Data Analysis', '2 years', 'Weekdays, 1 hour per session',
'CSE', 'Technical Mentoring', 'Basic knowledge of Python and statistics', 'lakshmi.srinivas@example.com'),
(4, 'Full Stack Development Mentoring', 'Get guidance on full stack development.', 'React, Node.js, Databases', '2 years', 'Weekends, 2 hours per session',
'CSE', 'Technical Mentoring', 'Basic knowledge of web development', 'sai.krishna@example.com'),
(5, 'UI/UX Design Mentoring', 'Get guidance on UI/UX design.', 'Figma, Adobe XD, User Research', '2 years', 'Weekdays, 1 hour per session',
'CSE', 'Technical Mentoring', 'Basic knowledge of design principles', 'anjali.reddy@example.com'),
(6, 'DevOps Mentoring', 'Get guidance on DevOps and cloud infrastructure.', 'AWS, Docker, CI/CD', '3 years', 'Weekends, 2 hours per session',
'CSE', 'Technical Mentoring', 'Basic knowledge of Linux and networking', 'vijay.krishna@example.com');

-- Insert connections
INSERT INTO connections (user_id, connected_user_id, status) VALUES
(2, 3, 'accepted'),
(2, 4, 'accepted'),
(2, 5, 'pending'),
(3, 4, 'accepted'),
(3, 5, 'accepted'),
(3, 6, 'pending'),
(4, 5, 'accepted'),
(4, 6, 'accepted'),
(4, 7, 'pending'),
(5, 6, 'accepted'),
(5, 7, 'accepted'),
(5, 8, 'pending'),
(6, 7, 'accepted'),
(6, 8, 'accepted'),
(6, 9, 'pending'),
(7, 8, 'accepted'),
(7, 9, 'accepted'),
(7, 10, 'pending'),
(8, 9, 'accepted'),
(8, 10, 'accepted'),
(8, 11, 'pending'),
(9, 10, 'accepted'),
(9, 11, 'accepted'),
(9, 12, 'pending'),
(10, 11, 'accepted'),
(10, 12, 'accepted'),
(10, 13, 'pending'),
(11, 12, 'accepted'),
(11, 13, 'accepted'),
(11, 14, 'pending'),
(12, 13, 'accepted'),
(12, 14, 'accepted'),
(12, 15, 'pending'),
(13, 14, 'accepted'),
(13, 15, 'accepted'),
(13, 16, 'pending'),
(14, 15, 'accepted'),
(14, 16, 'accepted'),
(15, 16, 'accepted');

-- Insert user credentials
INSERT INTO user_credentials (roll_number, unique_key, status, created_by) VALUES
('19CS016', 'KEY001', 'available', 1),
('19CS017', 'KEY002', 'available', 1),
('19CS018', 'KEY003', 'available', 1),
('19CS019', 'KEY004', 'available', 1),
('19CS020', 'KEY005', 'available', 1); 