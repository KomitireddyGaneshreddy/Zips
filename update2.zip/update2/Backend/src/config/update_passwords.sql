-- Update password hashes for all users to use the correct bcrypt hash for "password123"
UPDATE users 
SET password = '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy'
WHERE email IN (
    'admin@jntua.ac.in',
    'rajesh.kumar@example.com',
    'lakshmi.srinivas@example.com',
    'sai.krishna@example.com',
    'anjali.reddy@example.com',
    'rahul.sharma@example.com',
    'amit.verma@example.com',
    'ravi.patel@example.com',
    'neha.singh@example.com',
    'arun.gupta@example.com',
    'priya.jain@example.com',
    'vikram.kumar@example.com',
    'sneha.mishra@example.com',
    'karthik.reddy@example.com',
    'anita.sharma@example.com',
    'rajat.singh@example.com',
    'pooja.verma@example.com',
    'suresh.patel@example.com',
    'meera.gupta@example.com',
    'ajay.kumar@example.com',
    'ritu.jain@example.com'
);

-- Verify the update
SELECT id, email, password FROM users WHERE email IN (
    'admin@jntua.ac.in',
    'rajesh.kumar@example.com',
    'lakshmi.srinivas@example.com'
) LIMIT 3; 