const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { verifyToken } = require('../middleware/auth');

// Protected routes (require authentication)
router.use(verifyToken);

// Get user profile
router.get('/profile', userController.getProfile);

// Update user profile
router.put('/profile', userController.updateProfile);

// Change password
router.put('/change-password', userController.changePassword);

// Get network stats
router.get('/network-stats', userController.getNetworkStats);

// Get all users (admin only)
router.get('/', userController.getAllUsers);

// Get discover alumni
router.get('/discover', userController.getDiscoverAlumni);

// Get connected alumni
router.get('/connected', userController.getConnectedAlumni);

// Get pending connection requests
router.get('/pending-requests', userController.getPendingRequests);

// Get sent connection requests
router.get('/sent-requests', userController.getSentRequests);

// Handle connection request (accept/reject)
router.post('/handle-connection', userController.handleConnectionRequest);

// Send connection request
router.post('/connect', userController.connectWithAlumni);

// Revoke connection request
router.post('/revoke-connection', userController.revokeConnectionRequest);

// User credential routes
router.get('/credentials', verifyToken, userController.getAllCredentials);
router.get('/existing-credentials', verifyToken, userController.getExistingCredentials);
router.post('/credentials', verifyToken, userController.createUserCredential);
router.put('/credentials/:id', verifyToken, userController.updateUserCredential);
router.delete('/credentials/:id', verifyToken, userController.deleteCredential);
router.post('/credentials/verify', userController.verifyUserCredential);

// Get user details
router.get('/users/:id', userController.getUserDetails);

// Get user by ID
router.get('/:id', userController.getUserById);

// Delete user by ID
router.delete('/:id', userController.deleteUserById);

// Get user's education
router.get('/education', userController.getEducation);

// Add education
router.post('/education', userController.addEducation);

// Update education
router.put('/education/:id', userController.updateEducation);

// Delete education
router.delete('/education/:id', userController.deleteEducation);

// Get user's experience
router.get('/experience', userController.getExperience);

// Add experience
router.post('/experience', userController.addExperience);

// Get user's skills
router.get('/skills', userController.getSkills);
router.post('/skills', userController.addSkills);
router.put('/skills', userController.updateSkills);
router.delete('/skills/:skillId', userController.deleteSkill);

// Get user's social links
router.get('/social-links', userController.getSocialLinks);
router.post('/social-links', userController.addSocialLink);
router.put('/social-links', userController.updateSocialLink);
router.delete('/social-links/:id', userController.deleteSocialLink);

// Delete account
router.delete('/account', userController.deleteAccount);

// Profile data insertion routes
router.post('/profile/social-links', userController.insertSocialLinks);
router.put('/profile/social-links', userController.insertSocialLinks);
router.post('/profile/skills', userController.insertSkills);
router.post('/profile/experience', userController.insertExperience);
router.post('/profile/education', userController.insertEducation);

// Update skills
router.put('/users/profile/skills', userController.updateSkills);

module.exports = router; 