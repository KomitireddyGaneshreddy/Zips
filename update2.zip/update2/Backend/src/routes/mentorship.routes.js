const express = require('express');
const router = express.Router();
const mentorshipController = require('../controllers/mentorship.controller');
const authMiddleware = require('../middleware/auth.middleware');

// Public routes
router.get('/', mentorshipController.getAllMentorships);
router.get('/:id', mentorshipController.getMentorshipById);

// Protected routes (require authentication)
router.use(authMiddleware.verifyToken);

// User routes
router.post('/', mentorshipController.createMentorship);
router.put('/:id', mentorshipController.updateMentorship);
router.delete('/:id', mentorshipController.deleteMentorship);
router.post('/:id/apply', mentorshipController.applyForMentorship);
router.get('/:id/applications', mentorshipController.getMentorshipApplications);
router.put('/:id/applications/:applicationId', mentorshipController.updateApplicationStatus);

// Admin routes
router.delete('/admin/:id', authMiddleware.isAdmin, mentorshipController.adminDeleteMentorship);
router.put('/admin/:id', authMiddleware.isAdmin, mentorshipController.adminUpdateMentorship);

module.exports = router; 