const db = require('../config/db.config');
const bcrypt = require('bcryptjs');

exports.getProfile = async (req, res) => {
  try {
    const userId = req.user.id;

    // Get user basic info and current_location from user_profiles
    const [users] = await db.execute(
      `SELECT u.id, u.roll_number, u.first_name, u.last_name, u.surname, 
              u.date_of_birth, u.email, u.current_phone, u.previous_phone, u.role,u.department,
              up.current_location
       FROM users u
       LEFT JOIN user_profiles up ON u.id = up.user_id
       WHERE u.id = ?`,
      [userId]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    // Get education
    const [education] = await db.execute(
      'SELECT * FROM education WHERE user_id = ?',
      [userId]
    );

    // Get experience
    const [experience] = await db.execute(
      'SELECT * FROM experience WHERE user_id = ?',
      [userId]
    );

    // Get skills
    const [skills] = await db.execute(
      `SELECT s.* FROM skills s 
       JOIN user_skills us ON s.id = us.skill_id 
       WHERE us.user_id = ?`,
      [userId]
    );

    // Combine all data
    const userProfile = {
      ...users[0],
      education: education || null,
      experience: experience || null,
      skills: skills || []
    };

    res.json(userProfile);
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      message: 'Error retrieving user profile'
    });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const {
      first_name,
      last_name,
      surname,
      current_phone,
      previous_phone,
      email,
      department,
      batch,
      current_location,
      bio,
      current_company,
      designation
    } = req.body;

    // Update users table
    await db.execute(
      `UPDATE users SET 
        first_name = ?,
        last_name = ?,
        surname = ?,
        current_phone = ?,
        previous_phone = ?,
        department = ?,
        email = ?
      WHERE id = ?`,
      [first_name, last_name, surname, current_phone, previous_phone, department, email, userId]
    );

    // Check if user profile exists
    const [existingProfile] = await db.execute(
      'SELECT * FROM user_profiles WHERE user_id = ?',
      [userId]
    );

    if (existingProfile.length > 0) {
      // Update existing profile
      await db.execute(
        `UPDATE user_profiles SET 
          current_location = ?,
          bio = ?,
          current_company = ?,
          designation = ?
        WHERE user_id = ?`,
        [current_location, bio, current_company, designation, userId]
      );
    } 
    // else {
    //   // Insert new profile
    //   await db.execute(
    //     `INSERT INTO user_profiles (
    //       user_id, current_location, bio, current_company, designation
    //     ) VALUES (?, ?, ?, ?, ?)`,
    //     [userId, current_location, bio, current_company, designation]
    //   );
    // }

    // Handle education update
    if (department || batch) {
      // First, check if there's an existing B.Tech education record
      const [existingEducation] = await db.execute(
        'SELECT id FROM education WHERE user_id = ? AND degree = ?',
        [userId, 'B.Tech']
      );

      if (existingEducation.length > 0) {
        // Update the existing B.Tech record
        await db.execute(
          `UPDATE education SET 
            institution = ?,
            year = ?
          WHERE user_id = ? AND degree = ?`,
          [department || 'JNTUA', batch || '2020', userId, 'B.Tech']
        );
      } 
      // else {
      //   // Insert new education record
      //   await db.execute(
      //     `INSERT INTO education (
      //       user_id, institution, degree, year
      //     ) VALUES (?, ?, ?, ?)`,
      //     [userId, department || 'JNTUA', 'B.Tech', batch || '2020']
      //   );
      // }
    }

    res.json({
      message: 'Profile updated successfully'
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      message: 'Error updating user profile',
      error: error.message
    });
  }
};

exports.changePassword = async (req, res) => {
  try {
    const userId = req.user.id;
    const { currentPassword, newPassword } = req.body;

    // Get current user
    const [users] = await db.execute(
      'SELECT password FROM users WHERE id = ?',
      [userId]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    // Verify current password
    const isValidPassword = await bcrypt.compare(currentPassword, users[0].password);
    if (!isValidPassword) {
      return res.status(401).json({
        message: 'Current password is incorrect'
      });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password
    await db.execute(
      'UPDATE users SET password = ? WHERE id = ?',
      [hashedPassword, userId]
    );

    res.json({
      message: 'Password changed successfully'
    });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      message: 'Error changing password'
    });
  }
};

exports.getAllUsers = async (req, res) => {
  let connection;
  try {
    connection = await db.getConnection();
    const [users] = await connection.execute(`
      SELECT 
        u.id, 
        u.roll_number, 
        u.first_name, 
        u.last_name, 
        u.email, 
        u.role,
        u.department,
        u.created_at,
        uc.unique_key,
        SUBSTRING_INDEX(e.year, '-', -1) AS graduation_year
      FROM users u
      LEFT JOIN user_credentials uc 
        ON u.roll_number = uc.roll_number
      LEFT JOIN (
        SELECT e1.user_id, e1.year
        FROM education e1
        INNER JOIN (
          SELECT user_id, MAX(id) AS max_id
          FROM education
          WHERE degree LIKE 'B.Tech%'
          GROUP BY user_id
        ) e2 ON e1.user_id = e2.user_id AND e1.id = e2.max_id
      ) e ON u.id = e.user_id
      ORDER BY u.created_at DESC
    `);
    res.json(users);
  } catch (error) {
    console.error('Get all users error:', error);
    res.status(500).json({
      message: 'Error retrieving users',
      error: error.message
    });
  } finally {
    if (connection) {
      connection.release();
    }
  }
};

exports.getUserById = async (req, res) => {
  try {
    const userId = req.params.id;
    const [users] = await db.execute(
      'SELECT id, roll_number, first_name, last_name, surname, email, role FROM users WHERE id = ?',
      [userId]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    res.json(users[0]);
  } catch (error) {
    console.error('Get user by ID error:', error);
    res.status(500).json({
      message: 'Error retrieving user'
    });
  }
};

exports.getEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const [education] = await db.execute(
      'SELECT * FROM education WHERE user_id = ?',
      [userId]
    );
    res.json(education);
  } catch (error) {
    console.error('Get education error:', error);
    res.status(500).json({
      message: 'Error retrieving education details'
    });
  }
};

exports.addEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const { institution, degree, field_of_study, start_date, end_date } = req.body;

    const [result] = await db.execute(
      'INSERT INTO education (user_id, institution, degree, field_of_study, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, institution, degree, field_of_study, start_date, end_date]
    );

    res.status(201).json({
      id: result.insertId,
      message: 'Education added successfully'
    });
  } catch (error) {
    console.error('Add education error:', error);
    res.status(500).json({
      message: 'Error adding education details'
    });
  }
};

exports.updateEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const educationId = req.params.id;
    const { institution, degree, field_of_study, start_date, end_date } = req.body;

    await db.execute(
      'UPDATE education SET institution = ?, degree = ?, field_of_study = ?, start_date = ?, end_date = ? WHERE id = ? AND user_id = ?',
      [institution, degree, field_of_study, start_date, end_date, educationId, userId]
    );

    res.json({
      message: 'Education updated successfully'
    });
  } catch (error) {
    console.error('Update education error:', error);
    res.status(500).json({
      message: 'Error updating education details'
    });
  }
};

exports.deleteEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const educationId = req.params.id;

    await db.execute(
      'DELETE FROM education WHERE id = ? AND user_id = ?',
      [educationId, userId]
    );

    res.json({
      message: 'Education deleted successfully'
    });
  } catch (error) {
    console.error('Delete education error:', error);
    res.status(500).json({
      message: 'Error deleting education details'
    });
  }
};

exports.getExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const [experience] = await db.execute(
      'SELECT * FROM experience WHERE user_id = ?',
      [userId]
    );
    res.json(experience);
  } catch (error) {
    console.error('Get experience error:', error);
    res.status(500).json({
      message: 'Error retrieving experience details'
    });
  }
};

exports.addExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const { company, position, start_date, end_date, description } = req.body;

    const [result] = await db.execute(
      'INSERT INTO experience (user_id, company, position, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, company, position, start_date, end_date, description]
    );

    res.status(201).json({
      id: result.insertId,
      message: 'Experience added successfully'
    });
  } catch (error) {
    console.error('Add experience error:', error);
    res.status(500).json({
      message: 'Error adding experience details'
    });
  }
};

exports.updateExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const experienceId = req.params.id;
    const { company, position, start_date, end_date, description } = req.body;

    await db.execute(
      'UPDATE experience SET company = ?, position = ?, start_date = ?, end_date = ?, description = ? WHERE id = ? AND user_id = ?',
      [company, position, start_date, end_date, description, experienceId, userId]
    );

    res.json({
      message: 'Experience updated successfully'
    });
  } catch (error) {
    console.error('Update experience error:', error);
    res.status(500).json({
      message: 'Error updating experience details'
    });
  }
};

exports.deleteExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const experienceId = req.params.id;

    await db.execute(
      'DELETE FROM experience WHERE id = ? AND user_id = ?',
      [experienceId, userId]
    );

    res.json({
      message: 'Experience deleted successfully'
    });
  } catch (error) {
    console.error('Delete experience error:', error);
    res.status(500).json({
      message: 'Error deleting experience details'
    });
  }
};

exports.getSkills = async (req, res) => {
  try {
    const userId = req.user.id;
    const [skills] = await db.execute(
      'SELECT * FROM skills WHERE user_id = ?',
      [userId]
    );
    res.json(skills);
  } catch (error) {
    console.error('Get skills error:', error);
    res.status(500).json({
      message: 'Error retrieving skills'
    });
  }
};

exports.addSkills = async (req, res) => {
  try {
    const userId = req.user.id;
    const { skills } = req.body;

    // Delete existing skills
    await db.execute('DELETE FROM skills WHERE user_id = ?', [userId]);

    // Insert new skills
    for (const skill of skills) {
      await db.execute(
        'INSERT INTO skills (user_id, skill_name) VALUES (?, ?)',
        [userId, skill]
      );
    }

    res.status(201).json({
      message: 'Skills updated successfully'
    });
  } catch (error) {
    console.error('Add skills error:', error);
    res.status(500).json({
      message: 'Error updating skills'
    });
  }
};

exports.deleteSkill = async (req, res) => {
  try {
    const userId = req.user.id;
    const skillId = req.params.skillId;

    await db.execute(
      'DELETE FROM skills WHERE id = ? AND user_id = ?',
      [skillId, userId]
    );

    res.json({
      message: 'Skill deleted successfully'
    });
  } catch (error) {
    console.error('Delete skill error:', error);
    res.status(500).json({
      message: 'Error deleting skill'
    });
  }
};

exports.getSocialLinks = async (req, res) => {
  try {
    const userId = req.user.id;
    const [socialLinks] = await db.execute(
      'SELECT * FROM social_links WHERE user_id = ?',
      [userId]
    );
    res.json(socialLinks);
  } catch (error) {
    console.error('Get social links error:', error);
    res.status(500).json({
      message: 'Error retrieving social links'
    });
  }
};

exports.addSocialLink = async (req, res) => {
  try {
    const userId = req.user.id;
    const { platform, url } = req.body;

    const [result] = await db.execute(
      'INSERT INTO social_links (user_id, platform, url) VALUES (?, ?, ?)',
      [userId, platform, url]
    );

    res.status(201).json({
      id: result.insertId,
      message: 'Social link added successfully'
    });
  } catch (error) {
    console.error('Add social link error:', error);
    res.status(500).json({
      message: 'Error adding social link'
    });
  }
};

exports.updateSocialLink = async (req, res) => {
  try {
    const userId = req.user.id;
    const linkId = req.params.id;
    const { platform, url } = req.body;

    await db.execute(
      'UPDATE social_links SET platform = ?, url = ? WHERE id = ? AND user_id = ?',
      [platform, url, linkId, userId]
    );

    res.json({
      message: 'Social link updated successfully'
    });
  } catch (error) {
    console.error('Update social link error:', error);
    res.status(500).json({
      message: 'Error updating social link'
    });
  }
};

exports.deleteSocialLink = async (req, res) => {
  try {
    const userId = req.user.id;
    const linkId = req.params.id;

    await db.execute(
      'DELETE FROM social_links WHERE id = ? AND user_id = ?',
      [linkId, userId]
    );

    res.json({
      message: 'Social link deleted successfully'
    });
  } catch (error) {
    console.error('Delete social link error:', error);
    res.status(500).json({
      message: 'Error deleting social link'
    });
  }
};

exports.getNetworkStats = async (req, res) => {
  try {
    console.log('Fetching network stats...');
    console.log('User from request:', req.user ? `ID: ${req.user.id}, Name: ${req.user.first_name} ${req.user.last_name}` : 'Not logged in');
    
    // Get total users count
    const [userCount] = await db.execute('SELECT COUNT(*) as total FROM users');
    
    // Get total events count for upcoming events
    const [eventCount] = await db.execute(`
      SELECT COUNT(*) as total 
      FROM events 
      WHERE date >= CURDATE()`
    );
    
    // Get total active jobs count (where deadline is in the future)
    const [jobCount] = await db.execute(`
      SELECT COUNT(*) as total 
      FROM jobs 
      WHERE deadline >= CURDATE()`
    );
    
    // Get total mentorship count
    const [mentorshipCount] = await db.execute('SELECT COUNT(*) as total FROM mentorship');

    // Get user's connections count if user is logged in
    let connectionsCount = 0;
    let pendingConnectionsCount = 0;

    if (req.user) {
      console.log(`Fetching connections for user ID: ${req.user.id}`);
      
      // Get accepted connections
      const [connections] = await db.execute(`
SELECT COUNT(*) AS connection_count
FROM (
  SELECT 
    u.id,
    u.first_name,
    u.last_name,
    u.roll_number,
    up.current_company,
    up.designation AS role,
    up.current_location,
    e.degree,
    e.year AS batch,
    e.institution AS department,
    GROUP_CONCAT(DISTINCT s.name) AS skills,
    c.status AS connection_status
  FROM connections c
  JOIN users u ON c.connected_user_id = u.id
  LEFT JOIN user_profiles up ON u.id = up.user_id
  LEFT JOIN education e ON u.id = e.user_id
  LEFT JOIN user_skills us ON u.id = us.user_id
  LEFT JOIN skills s ON us.skill_id = s.id
  WHERE c.user_id = ? AND c.status = 'accepted'
  GROUP BY u.id
) AS connected_alumni;
`,
        [req.user.id]
      );
      
      // Get pending connection requests
      const [pendingConnections] = await db.execute(`
        SELECT COUNT(*) as total 
        FROM connections 
        WHERE connected_user_id = ? 
        AND status = 'pending'`,
        [req.user.id]
      );

      connectionsCount = connections[0].connection_count;
      pendingConnectionsCount = pendingConnections[0].total;
      
      console.log(`Found ${connectionsCount} connections and ${pendingConnectionsCount} pending requests for user ID: ${req.user.id}`);
    } else {
      console.log('No user found in request, skipping connection counts');
    }

    const stats = {
      totalUsers: userCount[0].total,
      upcomingEvents: eventCount[0].total,
      activeJobs: jobCount[0].total,
      activeMentorships: mentorshipCount[0].total,
      connections: connectionsCount,
      pendingConnections: pendingConnectionsCount
    };

    console.log('Network stats:', stats);
    console.log(`User ID: ${req.user ? req.user.id : 'Not logged in'}, Connections: ${connectionsCount}, Pending: ${pendingConnectionsCount}`);
    res.json(stats);
  } catch (error) {
    console.error('Get network stats error:', error);
    res.status(500).json({
      message: 'Error retrieving network stats',
      error: error.message
    });
  }
};

// This Related to Network.js

exports.getDiscoverAlumni = async (req, res) => {
  try {
    const { department, batch, search } = req.query;
    const userId = req.user.id;

    let query = `
      SELECT DISTINCT
        u.id,
        u.first_name,
        u.last_name,
        u.roll_number,
        up.current_company,
        up.designation as role,
        up.current_location,
        e.degree,
        e.year as batch,
        e.institution as department,
        GROUP_CONCAT(DISTINCT s.name) as skills
      FROM users u
      LEFT JOIN user_profiles up ON u.id = up.user_id
      LEFT JOIN education e ON u.id = e.user_id
      LEFT JOIN user_skills us ON u.id = us.user_id
      LEFT JOIN skills s ON us.skill_id = s.id
      LEFT JOIN connections c ON (u.id = c.connected_user_id AND c.user_id = ?)
        OR (u.id = c.user_id AND c.connected_user_id = ?)
      WHERE u.id != ? 
        AND u.role = 'alumni'
        AND (c.id IS NULL OR (c.status = 'rejected'))
    `;

    const params = [userId, userId, userId];

    if (department && department !== 'All Departments') {
      query += ' AND e.institution = ?';
      params.push(department);
    }

    if (batch && batch !== 'All Batches') {
      query += ' AND e.year = ?';
      params.push(batch);
    }

    if (search) {
      query += ` AND (
        u.first_name LIKE ? OR 
        u.last_name LIKE ? OR 
        up.current_company LIKE ? OR 
        up.designation LIKE ?
      )`;
      const searchParam = `%${search}%`;
      params.push(searchParam, searchParam, searchParam, searchParam);
    }

    query += ' GROUP BY u.id';

    const [alumni] = await db.execute(query, params);

    // Format the response
    const formattedAlumni = alumni.map(a => ({
      id: a.id,
      name: `${a.first_name} ${a.last_name}`,
      role: a.role || 'Alumni Member',
      company: a.current_company || 'Not specified',
      department: a.department || 'Not specified',
      batch: a.batch || 'Not specified',
      location: a.current_location || 'Not specified',
      skills: a.skills ? a.skills.split(',') : [],
      connectionStatus: null
    }));

    res.json(formattedAlumni);
  } catch (error) {
    console.error('Get discover alumni error:', error);
    res.status(500).json({
      message: 'Error retrieving alumni data',
      error: error.message
    });
  }
};

exports.getConnectedAlumni = async (req, res) => {
  try {
    const userId = req.user.id;

    const query = `
      SELECT 
        u.id,
        u.first_name,
        u.last_name,
        u.roll_number,
        up.current_company,
        up.designation as role,
        up.current_location,
        e.degree,
        e.year as batch,
        e.institution as department,
        GROUP_CONCAT(DISTINCT s.name) as skills,
        c.status as connection_status
      FROM connections c
      JOIN users u ON c.connected_user_id = u.id
      LEFT JOIN user_profiles up ON u.id = up.user_id
      LEFT JOIN education e ON u.id = e.user_id
      LEFT JOIN user_skills us ON u.id = us.user_id
      LEFT JOIN skills s ON us.skill_id = s.id
      WHERE c.user_id = ? AND c.status = 'accepted'
      GROUP BY u.id
    `;

    const [connections] = await db.execute(query, [userId]);

    const formattedConnections = connections.map(c => ({
      id: c.id,
      name: `${c.first_name} ${c.last_name}`,
      role: c.role || 'Alumni Member',
      company: c.current_company || 'Not specified',
      department: c.department || 'Not specified',
      batch: c.batch || 'Not specified',
      location: c.current_location || 'Not specified',
      skills: c.skills ? c.skills.split(',') : [],
      connectionStatus: c.connection_status
    }));

    res.json(formattedConnections);
  } catch (error) {
    console.error('Get connected alumni error:', error);
    res.status(500).json({
      message: 'Error retrieving connected alumni',
      error: error.message
    });
  }
};

exports.connectWithAlumni = async (req, res) => {
  try {
    const userId = req.user.id;
    const { connectedUserId } = req.body;

    // Check if connection already exists
    const [existingConnection] = await db.execute(
      'SELECT * FROM connections WHERE user_id = ? AND connected_user_id = ?',
      [userId, connectedUserId]
    );

    if (existingConnection.length > 0) {
      return res.status(400).json({
        message: 'Connection request already exists'
      });
    }

    // Create new connection request
    await db.execute(
      'INSERT INTO connections (user_id, connected_user_id, status) VALUES (?, ?, ?)',
      [userId, connectedUserId, 'pending']
    );

    res.json({
      message: 'Connection request sent successfully',
      status: 'pending'
    });
  } catch (error) {
    console.error('Connect with alumni error:', error);
    res.status(500).json({
      message: 'Error sending connection request',
      error: error.message
    });
  }
};

exports.getPendingRequests = async (req, res) => {
  try {
    const userId = req.user.id;

    const query = `
      SELECT 
        u.id,
        u.first_name,
        u.last_name,
        u.roll_number,
        up.current_company,
        up.designation as role,
        up.current_location,
        e.degree,
        e.year as batch,
        e.institution as department,
        GROUP_CONCAT(DISTINCT s.name) as skills,
        c.status as connection_status,
        c.id as connection_id
      FROM connections c
      JOIN users u ON c.user_id = u.id
      LEFT JOIN user_profiles up ON u.id = up.user_id
      LEFT JOIN education e ON u.id = e.user_id
      LEFT JOIN user_skills us ON u.id = us.user_id
      LEFT JOIN skills s ON us.skill_id = s.id
      WHERE c.connected_user_id = ? AND c.status = 'pending'
      GROUP BY u.id
    `;

    const [requests] = await db.execute(query, [userId]);

    const formattedRequests = requests.map(r => ({
      id: r.id,
      name: `${r.first_name} ${r.last_name}`,
      role: r.role || 'Alumni Member',
      company: r.current_company || 'Not specified',
      department: r.department || 'Not specified',
      batch: r.batch || 'Not specified',
      location: r.current_location || 'Not specified',
      skills: r.skills ? r.skills.split(',') : [],
      connectionStatus: r.connection_status,
      connectionId: r.connection_id
    }));

    res.json(formattedRequests);
  } catch (error) {
    console.error('Get pending requests error:', error);
    res.status(500).json({
      message: 'Error retrieving pending requests',
      error: error.message
    });
  }
};

exports.handleConnectionRequest = async (req, res) => {
  try {
    const userId = req.user.id;
    const { connectionId, action } = req.body;

    if (!['accept', 'reject'].includes(action)) {
      return res.status(400).json({
        message: 'Invalid action. Must be either "accept" or "reject"'
      });
    }

    // Verify the connection request exists and belongs to the user
    const [connection] = await db.execute(
      'SELECT * FROM connections WHERE id = ? AND connected_user_id = ? AND status = "pending"',
      [connectionId, userId]
    );

    if (connection.length === 0) {
      return res.status(404).json({
        message: 'Connection request not found'
      });
    }

    // Update the connection status
    const newStatus = action === 'accept' ? 'accepted' : 'rejected';
    await db.execute(
      'UPDATE connections SET status = ? WHERE id = ?',
      [newStatus, connectionId]
    );

    // If accepted, create a reciprocal connection
    if (action === 'accept') {
      await db.execute(
        'INSERT INTO connections (user_id, connected_user_id, status) VALUES (?, ?, "accepted")',
        [userId, connection[0].user_id]
      );
    }

    res.json({
      message: `Connection request ${action}ed successfully`
    });
  } catch (error) {
    console.error('Handle connection request error:', error);
    res.status(500).json({
      message: 'Error handling connection request',
      error: error.message
    });
  }
};

exports.getSentRequests = async (req, res) => {
  try {
    const userId = req.user.id;
    
    const query = `
      SELECT 
        c.id as connection_id,
        c.status,
        c.created_at,
        u.id,
        u.first_name,
        u.last_name,
        up.current_company,
        up.designation as role,
        up.current_location,
        e.degree,
        e.year as batch,
        e.institution as department,
        GROUP_CONCAT(DISTINCT s.name) as skills
      FROM connections c
      JOIN users u ON u.id = c.connected_user_id
      LEFT JOIN user_profiles up ON u.id = up.user_id
      LEFT JOIN education e ON u.id = e.user_id
      LEFT JOIN user_skills us ON u.id = us.user_id
      LEFT JOIN skills s ON us.skill_id = s.id
      WHERE c.user_id = ? AND c.status = 'pending'
      GROUP BY c.id
      ORDER BY c.created_at DESC
    `;

    const [sentRequests] = await db.execute(query, [userId]);

    const formattedRequests = sentRequests.map(request => ({
      connectionId: request.connection_id,
      status: request.status,
      sentAt: request.created_at,
      user: {
        id: request.id,
        name: `${request.first_name} ${request.last_name}`,
        role: request.role || 'Alumni Member',
        company: request.current_company || 'Not specified',
        department: request.department || 'Not specified',
        batch: request.batch || 'Not specified',
        location: request.current_location || 'Not specified',
        skills: request.skills ? request.skills.split(',') : []
      }
    }));

    res.json(formattedRequests);
  } catch (error) {
    console.error('Get sent requests error:', error);
    res.status(500).json({
      message: 'Error retrieving sent connection requests',
      error: error.message
    });
  }
};

exports.revokeConnectionRequest = async (req, res) => {
  try {
    const userId = req.user.id;
    const { connectionId } = req.body;

    // Verify the connection request exists and belongs to the user
    const [connection] = await db.execute(
      'SELECT * FROM connections WHERE id = ? AND user_id = ? AND status = "pending"',
      [connectionId, userId]
    );

    if (connection.length === 0) {
      return res.status(404).json({
        message: 'Connection request not found'
      });
    }

    // Delete the connection request
    await db.execute(
      'DELETE FROM connections WHERE id = ?',
      [connectionId]
    );

    res.json({
      message: 'Connection request revoked successfully'
    });
  } catch (error) {
    console.error('Revoke connection request error:', error);
    res.status(500).json({
      message: 'Error revoking connection request',
      error: error.message
    });
  }
};

exports.deleteAccount = async (req, res) => {
  let connection;
  try {
    const userId = req.user.id;
    console.log(`Starting account deletion process for user ID: ${userId}`);

    // Get a connection from the pool
    connection = await db.getConnection();
    
    // Start a transaction
    await connection.beginTransaction();
    console.log('Transaction started');

    try {
      // Delete user's social links
      const [socialResult] = await connection.execute('DELETE FROM social_links WHERE user_id = ?', [userId]);
      console.log(`Deleted ${socialResult.affectedRows} social links`);

      // Delete user's skills
      const [skillsResult] = await connection.execute('DELETE FROM user_skills WHERE user_id = ?', [userId]);
      console.log(`Deleted ${skillsResult.affectedRows} skills`);

      // Delete user's experience
      const [expResult] = await connection.execute('DELETE FROM experience WHERE user_id = ?', [userId]);
      console.log(`Deleted ${expResult.affectedRows} experience entries`);

      // Delete user's education
      const [eduResult] = await connection.execute('DELETE FROM education WHERE user_id = ?', [userId]);
      console.log(`Deleted ${eduResult.affectedRows} education entries`);

      // Delete user's profile
      const [profileResult] = await connection.execute('DELETE FROM user_profiles WHERE user_id = ?', [userId]);
      console.log(`Deleted ${profileResult.affectedRows} profile entries`);

      // Delete user's connections
      const [connResult] = await connection.execute('DELETE FROM connections WHERE user_id = ? OR connected_user_id = ?', [userId, userId]);
      console.log(`Deleted ${connResult.affectedRows} connections`);

      // Delete user's jobs
      const [jobsResult] = await connection.execute('DELETE FROM jobs WHERE posted_by = ?', [userId]);
      console.log(`Deleted ${jobsResult.affectedRows} jobs`);

      // Delete user's events
      const [eventsResult] = await connection.execute('DELETE FROM events WHERE created_by = ?', [userId]);
      console.log(`Deleted ${eventsResult.affectedRows} events`);

      // Delete user's mentorship
      const [mentorResult] = await connection.execute('DELETE FROM mentorship WHERE mentor_id = ?', [userId]);
      console.log(`Deleted ${mentorResult.affectedRows} mentorship entries`);

      // Finally, delete the user
      const [userResult] = await connection.execute('DELETE FROM users WHERE id = ?', [userId]);
      console.log(`Deleted user account with ID ${userId}`);

      if (userResult.affectedRows === 0) {
        throw new Error('User not found or already deleted');
      }

      // Commit the transaction
      await connection.commit();
      console.log('Transaction committed successfully');

      // Send a consistent response format
      return res.status(200).json({
        success: true,
        message: 'Account deleted successfully',
        details: {
          userId,
          deletedData: {
            socialLinks: socialResult.affectedRows,
            skills: skillsResult.affectedRows,
            experience: expResult.affectedRows,
            education: eduResult.affectedRows,
            profile: profileResult.affectedRows,
            connections: connResult.affectedRows,
            jobs: jobsResult.affectedRows,
            events: eventsResult.affectedRows,
            mentorship: mentorResult.affectedRows
          }
        }
      });
    } catch (error) {
      // Rollback the transaction if there's an error
      console.error('Error during deletion, rolling back transaction:', error);
      await connection.rollback();
      throw error;
    } finally {
      // Always release the connection back to the pool
      if (connection) {
        connection.release();
        console.log('Database connection released');
      }
    }
  } catch (error) {
    console.error('Delete account error:', error);
    return res.status(500).json({
      success: false,
      message: 'Error deleting account',
      error: error.message,
      details: error.stack
    });
  }
};

exports.deleteUserById = async (req, res) => {
  try {
    const userId = req.params.id;

    // Delete the user (this will cascade to all related tables)
    await db.execute(
      'DELETE FROM users WHERE id = ?',
      [userId]
    );

    res.json({
      message: 'User deleted successfully'
    });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      message: 'Error deleting user',
      error: error.message
    });
  }
};

exports.getAllCredentials = async (req, res) => {
  try {
    const [credentials] = await db.execute(
      'SELECT * FROM user_credentials ORDER BY created_at DESC'
    );
    res.json(credentials);
  } catch (error) {
    console.error('Get all credentials error:', error);
    res.status(500).json({
      message: 'Error retrieving credentials'
    });
  }
};

exports.createUserCredential = async (req, res) => {
  try {
    const { roll_number, unique_key } = req.body;
    
    console.log('Creating credential with:', { roll_number, unique_key });
    
    // Validate required fields
    if (!roll_number || !unique_key) {
      return res.status(400).json({
        message: 'Roll number and unique key are required'
      });
    }
    
    // Check if credential already exists
    const [existing] = await db.execute(
      'SELECT * FROM user_credentials WHERE roll_number = ? OR unique_key = ?',
      [roll_number, unique_key]
    );
    
    if (existing.length > 0) {
      return res.status(400).json({
        message: 'Credential with this roll number or unique key already exists'
      });
    }
    
    // Create new credential with the provided unique_key
    await db.execute(
      'INSERT INTO user_credentials (roll_number, unique_key, status) VALUES (?, ?, ?)',
      [roll_number, unique_key, 'available']
    );
    
    res.status(201).json({
      message: 'Credential created successfully'
    });
  } catch (error) {
    console.error('Create credential error:', error);
    res.status(500).json({
      message: 'Error creating credential'
    });
  }
};

exports.deleteCredential = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if credential exists
    const [credential] = await db.execute(
      'SELECT * FROM user_credentials WHERE id = ?',
      [id]
    );
    
    if (credential.length === 0) {
      return res.status(404).json({
        message: 'Credential not found'
      });
    }
    
    // Delete credential
    await db.execute(
      'DELETE FROM user_credentials WHERE id = ?',
      [id]
    );
    
    res.json({
      message: 'Credential deleted successfully'
    });
  } catch (error) {
    console.error('Delete credential error:', error);
    res.status(500).json({
      message: 'Error deleting credential'
    });
  }
};

exports.verifyUserCredential = async (req, res) => {
  try {
    const { roll_number, unique_key } = req.body;
    
    // Check if credential exists and is available
    const [credential] = await db.execute(
      'SELECT * FROM user_credentials WHERE roll_number = ? AND unique_key = ? AND status = ?',
      [roll_number, unique_key, 'available']
    );
    
    if (credential.length === 0) {
      return res.status(404).json({
        message: 'Invalid or already used credentials'
      });
    }
    
    res.json({
      message: 'Credentials verified successfully',
      valid: true
    });
  } catch (error) {
    console.error('Verify credential error:', error);
    res.status(500).json({
      message: 'Error verifying credentials'
    });
  }
};

exports.getExistingCredentials = async (req, res) => {
  try {
    const [rows] = await db.execute(
      'SELECT roll_number, unique_key FROM user_credentials WHERE status = ?',
      ['used']
    );
    res.json(rows);
  } catch (error) {
    console.error('Error getting existing credentials:', error);
    res.status(500).json({ message: 'Failed to get existing credentials' });
  }
};

exports.markCredentialAsUsed = async (roll_number, unique_key) => {
  try {
    console.log('Marking credential as used:', { roll_number, unique_key });
    
    // Update credential status to 'used'
    await db.execute(
      'UPDATE user_credentials SET status = ? WHERE roll_number = ? AND unique_key = ?',
      ['used', roll_number, unique_key]
    );
    
    console.log('Credential marked as used successfully');
  } catch (error) {
    console.error('Error marking credential as used:', error);
    throw error;
  }
};

exports.updateUserCredential = async (req, res) => {
  let connection;
  try {
    const { id } = req.params;
    const { unique_key } = req.body;
    
    // Get a connection from the pool
    connection = await db.getConnection();
    
    // Start transaction
    await connection.beginTransaction();
    
    try {
      // Check if credential exists and is available
      const [credential] = await connection.execute(
        'SELECT * FROM user_credentials WHERE id = ? AND status = ?',
        [id, 'available']
      );
      
      if (credential.length === 0) {
        await connection.rollback();
        return res.status(404).json({
          message: 'Credential not found or already used'
        });
      }
      
      // Check if new unique_key is already in use
      const [existing] = await connection.execute(
        'SELECT * FROM user_credentials WHERE unique_key = ? AND id != ?',
        [unique_key, id]
      );
      
      if (existing.length > 0) {
        await connection.rollback();
        return res.status(400).json({
          message: 'This unique key is already in use'
        });
      }
      
      // Update the credential
      await connection.execute(
        'UPDATE user_credentials SET unique_key = ? WHERE id = ?',
        [unique_key, id]
      );
      
      await connection.commit();
      
      res.json({
        message: 'Credential updated successfully'
      });
    } catch (error) {
      await connection.rollback();
      throw error;
    }
  } catch (error) {
    console.error('Update credential error:', error);
    res.status(500).json({
      message: 'Error updating credential',
      error: error.message
    });
  } finally {
    if (connection) {
      connection.release();
    }
  }
};
//New code to complete the registration part

// Insert social links
exports.insertSocialLinks = async (req, res) => {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const userId = req.user.id;
    const { linkedin, github, twitter, portfolio } = req.body;

    // Delete existing social links
    await connection.query(
      'DELETE FROM social_links WHERE user_id = ?',
      [userId]
    );

    // Insert new social links
    if (linkedin) {
      await connection.query(
        'INSERT INTO social_links (user_id, platform, url) VALUES (?, ?, ?)',
        [userId, 'linkedin', linkedin]
      );
    }
    if (github) {
      await connection.query(
        'INSERT INTO social_links (user_id, platform, url) VALUES (?, ?, ?)',
        [userId, 'github', github]
      );
    }
    if (twitter) {
      await connection.query(
        'INSERT INTO social_links (user_id, platform, url) VALUES (?, ?, ?)',
        [userId, 'twitter', twitter]
      );
    }
    if (portfolio) {
      await connection.query(
        'INSERT INTO social_links (user_id, platform, url) VALUES (?, ?, ?)',
        [userId, 'portfolio', portfolio]
      );
    }

    await connection.commit();
    res.json({ message: 'Social links updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Error updating social links:', error);
    res.status(500).json({ 
      message: 'Error updating social links',
      error: error.message 
    });
  } finally {
    connection.release();
  }
};

// Insert skills
exports.insertSkills = async (req, res) => {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const userId = req.user.id;
    const { skills } = req.body;

    // Delete existing user skills
    await connection.query(
      'DELETE FROM user_skills WHERE user_id = ?',
      [userId]
    );

    // Insert new skills
    for (const skillName of skills) {
      // First, get or create the skill
      const [skills] = await connection.query(
        'SELECT id FROM skills WHERE name = ?',
        [skillName]
      );

      let skillId;
      if (skills.length === 0) {
        const [result] = await connection.query(
          'INSERT INTO skills (name) VALUES (?)',
          [skillName]
        );
        skillId = result.insertId;
      } else {
        skillId = skills[0].id;
      }

      // Then, link the skill to the user
      await connection.query(
        'INSERT INTO user_skills (user_id, skill_id) VALUES (?, ?)',
        [userId, skillId]
      );
    }

    await connection.commit();
    res.json({ message: 'Skills updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Error updating skills:', error);
    res.status(500).json({ message: 'Error updating skills' });
  } finally {
    connection.release();
  }
};

// Insert experience
exports.insertExperience = async (req, res) => {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const userId = req.user.id;
    const experiences = req.body;

    if (!Array.isArray(experiences)) {
      throw new Error('Experience data must be an array');
    }

    // Delete existing experience records
    await connection.query(
      'DELETE FROM experience WHERE user_id = ?',
      [userId]
    );

    // Insert new experience records
    for (const exp of experiences) {
      if (!exp.role || !exp.company) {
        throw new Error('Role and company are required for each experience');
      }

      await connection.query(
        `INSERT INTO experience 
         (user_id, role, company, duration, description) 
         VALUES (?, ?, ?, ?, ?)`,
        [
          userId,
          exp.role,
          exp.company,
          exp.duration || null,
          exp.description || null
        ]
      );
    }

    await connection.commit();
    res.json({ message: 'Experience updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Error updating experience:', error);
    res.status(500).json({ 
      message: 'Error updating experience',
      error: error.message 
    });
  } finally {
    connection.release();
  }
};

// Insert education
exports.insertEducation = async (req, res) => {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const userId = req.user.id;
    const educationList = req.body;

    // Delete existing education records
    await connection.query(
      'DELETE FROM education WHERE user_id = ?',
      [userId]
    );

    // Insert new education records
    for (const edu of educationList) {
      await connection.query(
        `INSERT INTO education 
         (user_id, degree, institution, year, grade) 
         VALUES (?, ?, ?, ?, ?)`,
        [
          userId,
          edu.degree,
          edu.institution,
          edu.year,
          edu.grade
        ]
      );
    }

    await connection.commit();
    res.json({ message: 'Education updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Error updating education:', error);
    res.status(500).json({ message: 'Error updating education' });
  } finally {
    connection.release();
  }
};

// Update skills (add new skills without deleting existing ones)
exports.updateSkills = async (req, res) => {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const userId = req.user.id;
    const { skills } = req.body;

    if (!Array.isArray(skills)) {
      throw new Error('Skills data must be an array');
    }

    // Get existing skills for the user
    const [existingSkills] = await connection.query(
      `SELECT s.name FROM skills s 
       JOIN user_skills us ON s.id = us.skill_id 
       WHERE us.user_id = ?`,
      [userId]
    );

    const existingSkillNames = existingSkills.map(s => s.name);

    // Add new skills that don't already exist
    for (const skillName of skills) {
      if (!existingSkillNames.includes(skillName)) {
        // First, get or create the skill
        const [skills] = await connection.query(
          'SELECT id FROM skills WHERE name = ?',
          [skillName]
        );

        let skillId;
        if (skills.length === 0) {
          const [result] = await connection.query(
            'INSERT INTO skills (name) VALUES (?)',
            [skillName]
          );
          skillId = result.insertId;
        } else {
          skillId = skills[0].id;
        }

        // Then, link the skill to the user
        await connection.query(
          'INSERT INTO user_skills (user_id, skill_id) VALUES (?, ?)',
          [userId, skillId]
        );
      }
    }

    await connection.commit();
    res.json({ message: 'Skills updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Error updating skills:', error);
    res.status(500).json({ 
      message: 'Error updating skills',
      error: error.message 
    });
  } finally {
    connection.release();
  }
};

exports.getUserDetails = async (req, res) => {
  try {
    const userId = req.params.id;
    console.log('Fetching user details for ID:', userId);
    
    // First, check if user exists
    const [userCheck] = await db.execute('SELECT id FROM users WHERE id = ?', [userId]);
    if (!userCheck || userCheck.length === 0) {
      console.log('User not found in users table');
      return res.status(404).json({ message: 'User not found' });
    }
    console.log('User exists in users table');

    // Check if user has a profile
    const [profileCheck] = await db.execute('SELECT user_id FROM user_profiles WHERE user_id = ?', [userId]);
    console.log('Profile check result:', profileCheck);
    
    // Get basic user info with profile data
    const userQuery = `
      SELECT 
        u.id, u.first_name, u.last_name, u.email, u.role, u.roll_number, u.surname,
        u.created_at,
        up.designation, up.current_company, up.current_position, up.years_of_experience,
        up.phone, up.linkedin_url, up.github_url,
        up.degree, up.batch, up.department,
        up.avatar
      FROM users u
      LEFT JOIN user_profiles up ON u.id = up.user_id
      WHERE u.id = ?
    `;
    
    console.log('Executing user query:', userQuery);
    const [users] = await db.execute(userQuery, [userId]);
    console.log('Raw user query result:', users);

    if (!users || users.length === 0) {
      console.log('No user found for ID:', userId);
      return res.status(404).json({ message: 'User not found' });
    }

    const user = users[0];

    // Get user's skills
    const skillsQuery = `
      SELECT s.name as skill_name 
      FROM user_skills us
      JOIN skills s ON us.skill_id = s.id
      WHERE us.user_id = ?
    `;
    console.log('Executing skills query:', skillsQuery);
    const [skills] = await db.execute(skillsQuery, [userId]);
    console.log('Raw skills query result:', skills);

    // Get user's education
    const educationQuery = `
      SELECT 
        institution, degree, field, graduation_year, gpa
      FROM education 
      WHERE user_id = ?
      ORDER BY graduation_year DESC
    `;
    console.log('Executing education query:', educationQuery);
    const [education] = await db.execute(educationQuery, [userId]);
    console.log('Raw education query result:', education);

    // Get user's experience
    const experienceQuery = `
      SELECT 
        company, role, start_date, end_date, description
      FROM experience 
      WHERE user_id = ?
      ORDER BY start_date DESC
    `;
    console.log('Executing experience query:', experienceQuery);
    const [experience] = await db.execute(experienceQuery, [userId]);
    console.log('Raw experience query result:', experience);

    // Combine all data
    const userDetails = {
      ...user,
      skills: skills ? skills.map(s => s.skill_name) : [],
      education: education || [],
      experience: experience || []
    };

    console.log('Final user details object:', JSON.stringify(userDetails, null, 2));
    res.json(userDetails);
  } catch (error) {
    console.error('Error in getUserDetails:', error);
    console.error('Error stack:', error.stack);
    res.status(500).json({ message: 'Error fetching user details' });
  }
};

module.exports = exports; 