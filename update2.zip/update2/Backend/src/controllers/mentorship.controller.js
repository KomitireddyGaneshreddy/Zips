const db = require('../config/db.config');

// User-specific mentorship functions
exports.createMentorship = async (req, res) => {
  try {
    const {
      title,
      description,
      expertise,
      experience,
      availability,
      department,
      type,
      expectations,
      contact_email
    } = req.body;

    const [result] = await db.execute(
      `INSERT INTO mentorship (
        title, description, expertise, experience,
        availability, department, type, expectations, contact_email, mentor_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title,
        description,
        expertise,
        experience,
        availability,
        department,
        type,
        expectations,
        contact_email,
        req.user.id
      ]
    );

    res.status(201).json({
      message: 'Mentorship opportunity created successfully',
      mentorshipId: result.insertId
    });
  } catch (error) {
    console.error('Create mentorship error:', error);
    res.status(500).json({
      message: 'Error creating mentorship opportunity'
    });
  }
};

// This function is used by both users and admins
exports.getAllMentorships = async (req, res) => {
  try {
    const [mentorships] = await db.execute(`
      SELECT m.*, u.first_name, u.last_name, u.role,
        (SELECT degree FROM education WHERE user_id = u.id ORDER BY year DESC LIMIT 1) as degree,
        (SELECT year FROM education WHERE user_id = u.id ORDER BY year DESC LIMIT 1) as batch
      FROM mentorship m
      JOIN users u ON m.mentor_id = u.id
      ORDER BY m.created_at DESC
    `);

    res.json(mentorships);
  } catch (error) {
    console.error('Get all mentorships error:', error);
    res.status(500).json({
      message: 'Error retrieving mentorship opportunities'
    });
  }
};

// This function is used by both users and admins
exports.getMentorshipById = async (req, res) => {
  try {
    const { id } = req.params;

    const [mentorships] = await db.execute(`
      SELECT m.*, u.first_name, u.last_name, u.role,
        (SELECT degree FROM education WHERE user_id = u.id ORDER BY year DESC LIMIT 1) as degree,
        (SELECT year FROM education WHERE user_id = u.id ORDER BY year DESC LIMIT 1) as batch
      FROM mentorship m
      JOIN users u ON m.mentor_id = u.id
      WHERE m.id = ?
    `, [id]);

    if (mentorships.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found'
      });
    }

    res.json(mentorships[0]);
  } catch (error) {
    console.error('Get mentorship by ID error:', error);
    res.status(500).json({
      message: 'Error retrieving mentorship opportunity'
    });
  }
};

// User-specific mentorship update function
exports.updateMentorship = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      expertise,
      experience,
      availability,
      department,
      type,
      expectations,
      contact_email
    } = req.body;

    // Check if mentorship exists and user is the mentor
    const [mentorships] = await db.execute(
      'SELECT mentor_id FROM mentorship WHERE id = ?',
      [id]
    );

    if (mentorships.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found'
      });
    }

    if (mentorships[0].mentor_id !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to update this mentorship opportunity'
      });
    }

    await db.execute(
      `UPDATE mentorship SET
        title = ?,
        description = ?,
        expertise = ?,
        experience = ?,
        availability = ?,
        department = ?,
        type = ?,
        expectations = ?,
        contact_email = ?
      WHERE id = ?`,
      [
        title,
        description,
        expertise,
        experience,
        availability,
        department,
        type,
        expectations,
        contact_email,
        id
      ]
    );

    res.json({
      message: 'Mentorship opportunity updated successfully'
    });
  } catch (error) {
    console.error('Update mentorship error:', error);
    res.status(500).json({
      message: 'Error updating mentorship opportunity'
    });
  }
};

// User-specific mentorship delete function
exports.deleteMentorship = async (req, res) => {
  try {
    const mentorshipId = req.params.id;
    const userId = req.user.id;

    // Check if the mentorship exists
    const [mentorship] = await db.execute(
      'SELECT * FROM mentorship WHERE id = ?',
      [mentorshipId]
    );

    if (mentorship.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found'
      });
    }

    // Check if the mentorship belongs to the user
    if (mentorship[0].mentor_id !== userId) {
      return res.status(403).json({
        message: 'You are not authorized to delete this mentorship'
      });
    }

    // Delete the mentorship
    await db.execute('DELETE FROM mentorship WHERE id = ?', [mentorshipId]);

    res.json({
      message: 'Mentorship deleted successfully'
    });
  } catch (error) {
    console.error('Delete mentorship error:', error);
    res.status(500).json({
      message: 'Error deleting mentorship',
      error: error.message
    });
  }
};

// Admin-specific mentorship delete function
exports.adminDeleteMentorship = async (req, res) => {
  try {
    const mentorshipId = req.params.id;
    
    // Verify that the user is an admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        message: 'You are not authorized to perform admin actions'
      });
    }

    // Check if the mentorship exists
    const [mentorship] = await db.execute(
      'SELECT * FROM mentorship WHERE id = ?',
      [mentorshipId]
    );

    if (mentorship.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found'
      });
    }

    // Delete the mentorship
    await db.execute('DELETE FROM mentorship WHERE id = ?', [mentorshipId]);

    res.json({
      message: 'Mentorship deleted successfully by admin'
    });
  } catch (error) {
    console.error('Admin delete mentorship error:', error);
    res.status(500).json({
      message: 'Error deleting mentorship',
      error: error.message
    });
  }
};

// Admin-specific mentorship update function
exports.adminUpdateMentorship = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      expertise,
      experience,
      availability,
      department,
      type,
      expectations,
      contact_email
    } = req.body;

    // Verify that the user is an admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        message: 'You are not authorized to perform admin actions'
      });
    }

    // Check if mentorship exists
    const [mentorships] = await db.execute(
      'SELECT * FROM mentorship WHERE id = ?',
      [id]
    );

    if (mentorships.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found'
      });
    }

    await db.execute(
      `UPDATE mentorship SET
        title = ?,
        description = ?,
        expertise = ?,
        experience = ?,
        availability = ?,
        department = ?,
        type = ?,
        expectations = ?,
        contact_email = ?
      WHERE id = ?`,
      [
        title,
        description,
        expertise,
        experience,
        availability,
        department,
        type,
        expectations,
        contact_email,
        id
      ]
    );

    res.json({
      message: 'Mentorship opportunity updated successfully by admin'
    });
  } catch (error) {
    console.error('Admin update mentorship error:', error);
    res.status(500).json({
      message: 'Error updating mentorship opportunity'
    });
  }
};

// User-specific mentorship application functions
exports.applyForMentorship = async (req, res) => {
  try {
    const { id: mentorshipId } = req.params;
    const { motivation, experience, expectations } = req.body;
    const menteeId = req.user.id;

    // Check if mentorship exists and is still accepting applications
    const [mentorships] = await db.execute(`
      SELECT id, max_mentees, application_deadline, mentor_id,
        (SELECT COUNT(*) FROM mentorship_applications 
         WHERE mentorship_id = mentorships.id 
         AND status = 'accepted') as current_mentees
      FROM mentorships 
      WHERE id = ? AND application_deadline >= CURDATE()
    `, [mentorshipId]);

    if (mentorships.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found or applications closed'
      });
    }

    const mentorship = mentorships[0];

    // Check if user is trying to apply to their own mentorship
    if (mentorship.mentor_id === menteeId) {
      return res.status(400).json({
        message: 'You cannot apply to your own mentorship opportunity'
      });
    }

    // Check if mentorship is full
    if (mentorship.current_mentees >= mentorship.max_mentees) {
      return res.status(400).json({
        message: 'Mentorship opportunity is full'
      });
    }

    // Check if already applied
    const [existingApplications] = await db.execute(
      'SELECT id FROM mentorship_applications WHERE mentorship_id = ? AND mentee_id = ?',
      [mentorshipId, menteeId]
    );

    if (existingApplications.length > 0) {
      return res.status(400).json({
        message: 'You have already applied for this mentorship opportunity'
      });
    }

    // Create application
    const [result] = await db.execute(
      `INSERT INTO mentorship_applications (
        mentorship_id, mentee_id, motivation, experience,
        expectations, status
      ) VALUES (?, ?, ?, ?, ?, 'pending')`,
      [mentorshipId, menteeId, motivation, experience, expectations]
    );

    res.status(201).json({
      message: 'Application submitted successfully',
      applicationId: result.insertId
    });
  } catch (error) {
    console.error('Mentorship application error:', error);
    res.status(500).json({
      message: 'Error submitting mentorship application'
    });
  }
};

// This function is used by both users and admins
exports.getMentorshipApplications = async (req, res) => {
  try {
    const { id: mentorshipId } = req.params;
    const isAdmin = req.user.role === 'admin';

    // Check if mentorship exists
    const [mentorships] = await db.execute(
      'SELECT mentor_id FROM mentorships WHERE id = ?',
      [mentorshipId]
    );

    if (mentorships.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found'
      });
    }

    // If not admin, check if user is the mentor
    if (!isAdmin && mentorships[0].mentor_id !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to view applications'
      });
    }

    const [applications] = await db.execute(`
      SELECT 
        ma.*,
        u.first_name,
        u.last_name,
        u.email,
        u.roll_number
      FROM mentorship_applications ma
      JOIN users u ON ma.mentee_id = u.id
      WHERE ma.mentorship_id = ?
      ORDER BY ma.created_at DESC
    `, [mentorshipId]);

    res.json(applications);
  } catch (error) {
    console.error('Get mentorship applications error:', error);
    res.status(500).json({
      message: 'Error retrieving mentorship applications'
    });
  }
};

// This function is used by both users and admins
exports.updateApplicationStatus = async (req, res) => {
  try {
    const { id: mentorshipId, applicationId } = req.params;
    const { status } = req.body;
    const isAdmin = req.user.role === 'admin';

    // Check if mentorship exists
    const [mentorships] = await db.execute(
      'SELECT mentor_id FROM mentorships WHERE id = ?',
      [mentorshipId]
    );

    if (mentorships.length === 0) {
      return res.status(404).json({
        message: 'Mentorship opportunity not found'
      });
    }

    // If not admin, check if user is the mentor
    if (!isAdmin && mentorships[0].mentor_id !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to update application status'
      });
    }

    await db.execute(
      'UPDATE mentorship_applications SET status = ? WHERE id = ? AND mentorship_id = ?',
      [status, applicationId, mentorshipId]
    );

    res.json({
      message: 'Application status updated successfully'
    });
  } catch (error) {
    console.error('Update application status error:', error);
    res.status(500).json({
      message: 'Error updating application status'
    });
  }
}; 