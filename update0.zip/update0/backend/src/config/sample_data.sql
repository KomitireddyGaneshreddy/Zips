USE jntua_alumni;

-- Insert sample users (password is hashed version of 'password123')
INSERT INTO users (roll_number, surname, first_name, last_name, date_of_birth, email, current_phone, password, unique_key, role) VALUES
('19021A0501', 'Smith', 'John', 'Doe', '1998-05-15', 'john.doe@example.com', '1234567890', '$2b$10$YourHashedPasswordHere', 'unique1', 'alumni'),
('19021A0502', 'Johnson', 'Jane', 'Smith', '1997-08-20', 'jane.smith@example.com', '9876543210', '$2b$10$YourHashedPasswordHere', 'unique2', 'alumni'),
('19021A0503', 'Admin', 'Admin', 'User', '1990-01-01', 'admin@jntua.ac.in', '5555555555', '$2b$10$YourHashedPasswordHere', 'unique3', 'admin');

-- Insert user profiles
INSERT INTO user_profiles (user_id, bio, current_location, current_company, designation) VALUES
(1, 'Software Engineer with 3 years of experience', 'Bangalore, India', 'Tech Corp', 'Senior Developer'),
(2, 'Data Scientist passionate about AI/ML', 'Hyderabad, India', 'Data Analytics Ltd', 'Data Scientist'),
(3, 'University Administrator', 'Anantapur, India', 'JNTUA', 'Admin Officer');

-- Insert skills
INSERT INTO skills (name) VALUES
('JavaScript'),
('Python'),
('Machine Learning'),
('React'),
('Node.js');

-- Insert user skills
INSERT INTO user_skills (user_id, skill_id) VALUES
(1, 1), -- John knows JavaScript
(1, 4), -- John knows React
(2, 2), -- Jane knows Python
(2, 3); -- Jane knows Machine Learning

-- Insert education
INSERT INTO education (user_id, degree, institution, year, grade) VALUES
(1, 'B.Tech in CSE', 'JNTUA', '2019-2023', '8.5 CGPA'),
(2, 'B.Tech in CSE', 'JNTUA', '2019-2023', '9.0 CGPA');

-- Insert experience
INSERT INTO experience (user_id, role, company, duration, description) VALUES
(1, 'Software Engineer', 'Tech Corp', '2023-Present', 'Working on full-stack development'),
(2, 'Data Scientist', 'Data Analytics Ltd', '2023-Present', 'Working on ML models');

-- Insert social links
INSERT INTO social_links (user_id, platform, url) VALUES
(1, 'LinkedIn', 'https://linkedin.com/in/johndoe'),
(2, 'GitHub', 'https://github.com/janesmith');

-- Insert jobs
INSERT INTO jobs (posted_by, title, company, location, type, remote, department, experience, salary, description, requirements, application_link, deadline) VALUES
(3, 'Software Engineer', 'Tech Solutions', 'Bangalore', 'Full-time', true, 'CSE', '0-2 years', '8-12 LPA', 'Looking for passionate developers', 'B.Tech in CSE, Knowledge of React', 'https://apply.tech.com', '2024-05-30'),
(3, 'Data Analyst', 'Analytics Corp', 'Hyderabad', 'Full-time', false, 'CSE', '1-3 years', '6-10 LPA', 'Join our data team', 'B.Tech, Knowledge of Python', 'https://apply.analytics.com', '2024-05-25');

-- Insert events
INSERT INTO events (created_by, title, description, date, time, location, type, registration_link, max_attendees, department) VALUES
(3, 'Tech Meetup 2024', 'Annual alumni tech meetup', '2024-12-15', '10:00:00', 'JNTUA Campus', 'In-Person', 'https://register.event.com', 100, 'CSE'),
(3, 'Virtual Career Fair', 'Online job fair for alumni', '2024-12-20', '14:00:00', 'Zoom', 'Virtual', 'https://virtual-fair.com', 200, 'CSE');

-- Insert mentorship opportunities
INSERT INTO mentorship (mentor_id, title, description, expertise, experience, availability, department, type, expectations, contact_email) VALUES
(1, 'Web Development Mentoring', 'Learn modern web development', 'React, Node.js', '3 years', 'Weekends', 'CSE', 'Technical Mentoring', 'Dedication and basic programming knowledge', 'john.doe@example.com'),
(2, 'Data Science Guidance', 'Career guidance in Data Science', 'Python, ML', '2 years', 'Weekday evenings', 'CSE', 'Career Guidance', 'Basic understanding of statistics', 'jane.smith@example.com');

-- Insert connections
INSERT INTO connections (user_id, connected_user_id, status) VALUES
(1, 2, 'accepted'),
(2, 1, 'accepted'); 