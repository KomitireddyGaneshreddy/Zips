const db = require('../config/db.config');
const bcrypt = require('bcryptjs');

exports.getProfile = async (req, res) => {
  try {
    const userId = req.user.id;

    const [users] = await db.execute(
      'SELECT id, roll_number, first_name, last_name, surname, date_of_birth, email, current_phone, previous_phone, role FROM users WHERE id = ?',
      [userId]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    res.json(users[0]);
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      message: 'Error retrieving user profile'
    });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const {
      first_name,
      last_name,
      surname,
      current_phone,
      previous_phone
    } = req.body;

    await db.execute(
      `UPDATE users SET 
        first_name = ?,
        last_name = ?,
        surname = ?,
        current_phone = ?,
        previous_phone = ?
      WHERE id = ?`,
      [first_name, last_name, surname, current_phone, previous_phone, userId]
    );

    res.json({
      message: 'Profile updated successfully'
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      message: 'Error updating user profile'
    });
  }
};

exports.changePassword = async (req, res) => {
  try {
    const userId = req.user.id;
    const { currentPassword, newPassword } = req.body;

    // Get current user
    const [users] = await db.execute(
      'SELECT password FROM users WHERE id = ?',
      [userId]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    // Verify current password
    const isValidPassword = await bcrypt.compare(currentPassword, users[0].password);
    if (!isValidPassword) {
      return res.status(401).json({
        message: 'Current password is incorrect'
      });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password
    await db.execute(
      'UPDATE users SET password = ? WHERE id = ?',
      [hashedPassword, userId]
    );

    res.json({
      message: 'Password changed successfully'
    });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      message: 'Error changing password'
    });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const [users] = await db.execute(
      'SELECT id, roll_number, first_name, last_name, surname, email, role FROM users'
    );
    res.json(users);
  } catch (error) {
    console.error('Get all users error:', error);
    res.status(500).json({
      message: 'Error retrieving users'
    });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const userId = req.params.id;
    const [users] = await db.execute(
      'SELECT id, roll_number, first_name, last_name, surname, email, role FROM users WHERE id = ?',
      [userId]
    );

    if (users.length === 0) {
      return res.status(404).json({
        message: 'User not found'
      });
    }

    res.json(users[0]);
  } catch (error) {
    console.error('Get user by ID error:', error);
    res.status(500).json({
      message: 'Error retrieving user'
    });
  }
};

exports.getEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const [education] = await db.execute(
      'SELECT * FROM education WHERE user_id = ?',
      [userId]
    );
    res.json(education);
  } catch (error) {
    console.error('Get education error:', error);
    res.status(500).json({
      message: 'Error retrieving education details'
    });
  }
};

exports.addEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const { institution, degree, field_of_study, start_date, end_date } = req.body;

    const [result] = await db.execute(
      'INSERT INTO education (user_id, institution, degree, field_of_study, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, institution, degree, field_of_study, start_date, end_date]
    );

    res.status(201).json({
      id: result.insertId,
      message: 'Education added successfully'
    });
  } catch (error) {
    console.error('Add education error:', error);
    res.status(500).json({
      message: 'Error adding education details'
    });
  }
};

exports.updateEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const educationId = req.params.id;
    const { institution, degree, field_of_study, start_date, end_date } = req.body;

    await db.execute(
      'UPDATE education SET institution = ?, degree = ?, field_of_study = ?, start_date = ?, end_date = ? WHERE id = ? AND user_id = ?',
      [institution, degree, field_of_study, start_date, end_date, educationId, userId]
    );

    res.json({
      message: 'Education updated successfully'
    });
  } catch (error) {
    console.error('Update education error:', error);
    res.status(500).json({
      message: 'Error updating education details'
    });
  }
};

exports.deleteEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const educationId = req.params.id;

    await db.execute(
      'DELETE FROM education WHERE id = ? AND user_id = ?',
      [educationId, userId]
    );

    res.json({
      message: 'Education deleted successfully'
    });
  } catch (error) {
    console.error('Delete education error:', error);
    res.status(500).json({
      message: 'Error deleting education details'
    });
  }
};

exports.getExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const [experience] = await db.execute(
      'SELECT * FROM experience WHERE user_id = ?',
      [userId]
    );
    res.json(experience);
  } catch (error) {
    console.error('Get experience error:', error);
    res.status(500).json({
      message: 'Error retrieving experience details'
    });
  }
};

exports.addExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const { company, position, start_date, end_date, description } = req.body;

    const [result] = await db.execute(
      'INSERT INTO experience (user_id, company, position, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, company, position, start_date, end_date, description]
    );

    res.status(201).json({
      id: result.insertId,
      message: 'Experience added successfully'
    });
  } catch (error) {
    console.error('Add experience error:', error);
    res.status(500).json({
      message: 'Error adding experience details'
    });
  }
};

exports.updateExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const experienceId = req.params.id;
    const { company, position, start_date, end_date, description } = req.body;

    await db.execute(
      'UPDATE experience SET company = ?, position = ?, start_date = ?, end_date = ?, description = ? WHERE id = ? AND user_id = ?',
      [company, position, start_date, end_date, description, experienceId, userId]
    );

    res.json({
      message: 'Experience updated successfully'
    });
  } catch (error) {
    console.error('Update experience error:', error);
    res.status(500).json({
      message: 'Error updating experience details'
    });
  }
};

exports.deleteExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const experienceId = req.params.id;

    await db.execute(
      'DELETE FROM experience WHERE id = ? AND user_id = ?',
      [experienceId, userId]
    );

    res.json({
      message: 'Experience deleted successfully'
    });
  } catch (error) {
    console.error('Delete experience error:', error);
    res.status(500).json({
      message: 'Error deleting experience details'
    });
  }
};

exports.getSkills = async (req, res) => {
  try {
    const userId = req.user.id;
    const [skills] = await db.execute(
      'SELECT * FROM skills WHERE user_id = ?',
      [userId]
    );
    res.json(skills);
  } catch (error) {
    console.error('Get skills error:', error);
    res.status(500).json({
      message: 'Error retrieving skills'
    });
  }
};

exports.addSkills = async (req, res) => {
  try {
    const userId = req.user.id;
    const { skills } = req.body;

    // Delete existing skills
    await db.execute('DELETE FROM skills WHERE user_id = ?', [userId]);

    // Insert new skills
    for (const skill of skills) {
      await db.execute(
        'INSERT INTO skills (user_id, skill_name) VALUES (?, ?)',
        [userId, skill]
      );
    }

    res.status(201).json({
      message: 'Skills updated successfully'
    });
  } catch (error) {
    console.error('Add skills error:', error);
    res.status(500).json({
      message: 'Error updating skills'
    });
  }
};

exports.deleteSkill = async (req, res) => {
  try {
    const userId = req.user.id;
    const skillId = req.params.skillId;

    await db.execute(
      'DELETE FROM skills WHERE id = ? AND user_id = ?',
      [skillId, userId]
    );

    res.json({
      message: 'Skill deleted successfully'
    });
  } catch (error) {
    console.error('Delete skill error:', error);
    res.status(500).json({
      message: 'Error deleting skill'
    });
  }
};

exports.getSocialLinks = async (req, res) => {
  try {
    const userId = req.user.id;
    const [socialLinks] = await db.execute(
      'SELECT * FROM social_links WHERE user_id = ?',
      [userId]
    );
    res.json(socialLinks);
  } catch (error) {
    console.error('Get social links error:', error);
    res.status(500).json({
      message: 'Error retrieving social links'
    });
  }
};

exports.addSocialLink = async (req, res) => {
  try {
    const userId = req.user.id;
    const { platform, url } = req.body;

    const [result] = await db.execute(
      'INSERT INTO social_links (user_id, platform, url) VALUES (?, ?, ?)',
      [userId, platform, url]
    );

    res.status(201).json({
      id: result.insertId,
      message: 'Social link added successfully'
    });
  } catch (error) {
    console.error('Add social link error:', error);
    res.status(500).json({
      message: 'Error adding social link'
    });
  }
};

exports.updateSocialLink = async (req, res) => {
  try {
    const userId = req.user.id;
    const linkId = req.params.id;
    const { platform, url } = req.body;

    await db.execute(
      'UPDATE social_links SET platform = ?, url = ? WHERE id = ? AND user_id = ?',
      [platform, url, linkId, userId]
    );

    res.json({
      message: 'Social link updated successfully'
    });
  } catch (error) {
    console.error('Update social link error:', error);
    res.status(500).json({
      message: 'Error updating social link'
    });
  }
};

exports.deleteSocialLink = async (req, res) => {
  try {
    const userId = req.user.id;
    const linkId = req.params.id;

    await db.execute(
      'DELETE FROM social_links WHERE id = ? AND user_id = ?',
      [linkId, userId]
    );

    res.json({
      message: 'Social link deleted successfully'
    });
  } catch (error) {
    console.error('Delete social link error:', error);
    res.status(500).json({
      message: 'Error deleting social link'
    });
  }
};

exports.getNetworkStats = async (req, res) => {
  try {
    console.log('Fetching network stats...');
    
    // Get total users count
    const [userCount] = await db.execute('SELECT COUNT(*) as total FROM users');
    
    // Get total events count for upcoming events
    const [eventCount] = await db.execute(`
      SELECT COUNT(*) as total 
      FROM events 
      WHERE date >= CURDATE()`
    );
    
    // Get total active jobs count (where deadline is in the future)
    const [jobCount] = await db.execute(`
      SELECT COUNT(*) as total 
      FROM jobs 
      WHERE deadline >= CURDATE()`
    );
    
    // Get total mentorship count
    const [mentorshipCount] = await db.execute('SELECT COUNT(*) as total FROM mentorship');

    // Get user's connections count if user is logged in
    let connectionsCount = 0;
    let pendingConnectionsCount = 0;

    if (req.user) {
      // Get accepted connections
      const [connections] = await db.execute(`
        SELECT COUNT(*) as total 
        FROM connections 
        WHERE (user_id = ? OR connected_user_id = ?) 
        AND status = 'accepted'`,
        [req.user.id, req.user.id]
      );
      
      // Get pending connection requests
      const [pendingConnections] = await db.execute(`
        SELECT COUNT(*) as total 
        FROM connections 
        WHERE connected_user_id = ? 
        AND status = 'pending'`,
        [req.user.id]
      );

      connectionsCount = connections[0].total;
      pendingConnectionsCount = pendingConnections[0].total;
    }

    const stats = {
      totalUsers: userCount[0].total,
      upcomingEvents: eventCount[0].total,
      activeJobs: jobCount[0].total,
      activeMentorships: mentorshipCount[0].total,
      connections: connectionsCount,
      pendingConnections: pendingConnectionsCount
    };

    console.log('Network stats:', stats);
    res.json(stats);
  } catch (error) {
    console.error('Get network stats error:', error);
    res.status(500).json({
      message: 'Error retrieving network stats',
      error: error.message
    });
  }
}; 