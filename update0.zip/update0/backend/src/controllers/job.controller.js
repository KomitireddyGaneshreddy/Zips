const db = require('../config/db.config');

exports.createJob = async (req, res) => {
  try {
    const {
      title,
      company,
      location,
      description,
      requirements,
      salary_range,
      job_type,
      deadline
    } = req.body;

    const [result] = await db.execute(
      `INSERT INTO jobs (
        title, company, location, description, requirements,
        salary_range, job_type, deadline, posted_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title,
        company,
        location,
        description,
        requirements,
        salary_range,
        job_type,
        deadline,
        req.user.id
      ]
    );

    res.status(201).json({
      message: 'Job posted successfully',
      jobId: result.insertId
    });
  } catch (error) {
    console.error('Create job error:', error);
    res.status(500).json({
      message: 'Error creating job posting'
    });
  }
};

exports.getAllJobs = async (req, res) => {
  try {
    const [jobs] = await db.execute(`
      SELECT j.*, u.first_name, u.last_name 
      FROM jobs j
      JOIN users u ON j.posted_by = u.id
      ORDER BY j.created_at DESC
    `);

    res.json(jobs);
  } catch (error) {
    console.error('Get all jobs error:', error);
    res.status(500).json({
      message: 'Error retrieving jobs'
    });
  }
};

exports.getJobById = async (req, res) => {
  try {
    const { id } = req.params;

    const [jobs] = await db.execute(`
      SELECT j.*, u.first_name, u.last_name 
      FROM jobs j
      JOIN users u ON j.posted_by = u.id
      WHERE j.id = ?
    `, [id]);

    if (jobs.length === 0) {
      return res.status(404).json({
        message: 'Job not found'
      });
    }

    res.json(jobs[0]);
  } catch (error) {
    console.error('Get job by ID error:', error);
    res.status(500).json({
      message: 'Error retrieving job'
    });
  }
};

exports.updateJob = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      company,
      location,
      description,
      requirements,
      salary_range,
      job_type,
      deadline
    } = req.body;

    // Check if job exists and user is the owner
    const [jobs] = await db.execute(
      'SELECT posted_by FROM jobs WHERE id = ?',
      [id]
    );

    if (jobs.length === 0) {
      return res.status(404).json({
        message: 'Job not found'
      });
    }

    if (jobs[0].posted_by !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to update this job'
      });
    }

    await db.execute(
      `UPDATE jobs SET
        title = ?,
        company = ?,
        location = ?,
        description = ?,
        requirements = ?,
        salary_range = ?,
        job_type = ?,
        deadline = ?
      WHERE id = ?`,
      [
        title,
        company,
        location,
        description,
        requirements,
        salary_range,
        job_type,
        deadline,
        id
      ]
    );

    res.json({
      message: 'Job updated successfully'
    });
  } catch (error) {
    console.error('Update job error:', error);
    res.status(500).json({
      message: 'Error updating job'
    });
  }
};

exports.deleteJob = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if job exists and user is the owner
    const [jobs] = await db.execute(
      'SELECT posted_by FROM jobs WHERE id = ?',
      [id]
    );

    if (jobs.length === 0) {
      return res.status(404).json({
        message: 'Job not found'
      });
    }

    if (jobs[0].posted_by !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to delete this job'
      });
    }

    await db.execute('DELETE FROM jobs WHERE id = ?', [id]);

    res.json({
      message: 'Job deleted successfully'
    });
  } catch (error) {
    console.error('Delete job error:', error);
    res.status(500).json({
      message: 'Error deleting job'
    });
  }
};

exports.applyForJob = async (req, res) => {
  try {
    const { id: jobId } = req.params;
    const { cover_letter, resume_url } = req.body;
    const applicantId = req.user.id;

    // Check if job exists
    const [jobs] = await db.execute(
      'SELECT id FROM jobs WHERE id = ?',
      [jobId]
    );

    if (jobs.length === 0) {
      return res.status(404).json({
        message: 'Job not found'
      });
    }

    // Check if already applied
    const [existingApplications] = await db.execute(
      'SELECT id FROM job_applications WHERE job_id = ? AND applicant_id = ?',
      [jobId, applicantId]
    );

    if (existingApplications.length > 0) {
      return res.status(400).json({
        message: 'You have already applied for this job'
      });
    }

    // Create application
    const [result] = await db.execute(
      `INSERT INTO job_applications (
        job_id, applicant_id, cover_letter, resume_url, status
      ) VALUES (?, ?, ?, ?, 'pending')`,
      [jobId, applicantId, cover_letter, resume_url]
    );

    res.status(201).json({
      message: 'Application submitted successfully',
      applicationId: result.insertId
    });
  } catch (error) {
    console.error('Job application error:', error);
    res.status(500).json({
      message: 'Error submitting job application'
    });
  }
};

exports.getJobApplications = async (req, res) => {
  try {
    const { id: jobId } = req.params;

    // Check if job exists and user is the owner
    const [jobs] = await db.execute(
      'SELECT posted_by FROM jobs WHERE id = ?',
      [jobId]
    );

    if (jobs.length === 0) {
      return res.status(404).json({
        message: 'Job not found'
      });
    }

    if (jobs[0].posted_by !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to view applications'
      });
    }

    const [applications] = await db.execute(`
      SELECT 
        ja.*,
        u.first_name,
        u.last_name,
        u.email,
        u.roll_number
      FROM job_applications ja
      JOIN users u ON ja.applicant_id = u.id
      WHERE ja.job_id = ?
      ORDER BY ja.created_at DESC
    `, [jobId]);

    res.json(applications);
  } catch (error) {
    console.error('Get job applications error:', error);
    res.status(500).json({
      message: 'Error retrieving job applications'
    });
  }
};

exports.updateApplicationStatus = async (req, res) => {
  try {
    const { id: jobId, applicationId } = req.params;
    const { status } = req.body;

    // Check if job exists and user is the owner
    const [jobs] = await db.execute(
      'SELECT posted_by FROM jobs WHERE id = ?',
      [jobId]
    );

    if (jobs.length === 0) {
      return res.status(404).json({
        message: 'Job not found'
      });
    }

    if (jobs[0].posted_by !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to update application status'
      });
    }

    await db.execute(
      'UPDATE job_applications SET status = ? WHERE id = ? AND job_id = ?',
      [status, applicationId, jobId]
    );

    res.json({
      message: 'Application status updated successfully'
    });
  } catch (error) {
    console.error('Update application status error:', error);
    res.status(500).json({
      message: 'Error updating application status'
    });
  }
}; 