const express = require('express');
const router = express.Router();
const eventController = require('../controllers/event.controller');
const { verifyToken } = require('../middleware/auth');

// Public routes
router.get('/upcoming', eventController.getUpcomingEvents);
router.get('/', eventController.getAllEvents);
router.get('/:id', eventController.getEventById);

// Protected routes
router.post('/', verifyToken, eventController.createEvent);
router.put('/:id', verifyToken, eventController.updateEvent);
router.delete('/:id', verifyToken, eventController.deleteEvent);

// Event registration management
router.post('/:id/register', eventController.registerForEvent);
router.get('/:id/participants', eventController.getEventParticipants);
router.delete('/:id/register', eventController.cancelRegistration);

module.exports = router; 