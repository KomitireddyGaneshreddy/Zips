const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { verifyToken } = require('../middleware/auth');

// Public routes (no authentication required)
router.get('/network-stats', userController.getNetworkStats);

// Protected routes (require authentication)
router.use(verifyToken);

// Get user profile
router.get('/profile', userController.getProfile);

// Update user profile
router.put('/profile', userController.updateProfile);

// Change password
router.put('/change-password', userController.changePassword);

// Get all users (admin only)
router.get('/', userController.getAllUsers);

// Get user by ID
router.get('/:id', userController.getUserById);

// Get user's education
router.get('/education', userController.getEducation);

// Add education
router.post('/education', userController.addEducation);

// Update education
router.put('/education/:id', userController.updateEducation);

// Delete education
router.delete('/education/:id', userController.deleteEducation);

// Get user's experience
router.get('/experience', userController.getExperience);

// Add experience
router.post('/experience', userController.addExperience);

// Get user's skills
router.get('/skills', userController.getSkills);
router.post('/skills', userController.addSkills);
router.delete('/skills/:skillId', userController.deleteSkill);

// Get user's social links
router.get('/social-links', userController.getSocialLinks);
router.post('/social-links', userController.addSocialLink);
router.put('/social-links/:id', userController.updateSocialLink);
router.delete('/social-links/:id', userController.deleteSocialLink);

module.exports = router; 