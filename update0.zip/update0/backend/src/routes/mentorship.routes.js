const express = require('express');
const router = express.Router();
const mentorshipController = require('../controllers/mentorship.controller');
const { verifyToken } = require('../middleware/auth');

// Public routes
router.get('/', mentorshipController.getAllMentorships);
router.get('/:id', mentorshipController.getMentorshipById);

// Protected routes (require authentication)
router.use(verifyToken);

// Mentorship opportunity management
router.post('/', mentorshipController.createMentorship);
router.put('/:id', mentorshipController.updateMentorship);
router.delete('/:id', mentorshipController.deleteMentorship);

// Mentorship application management
router.post('/:id/apply', mentorshipController.applyForMentorship);
router.get('/:id/applications', mentorshipController.getMentorshipApplications);
router.put('/:id/applications/:applicationId', mentorshipController.updateApplicationStatus);

module.exports = router; 