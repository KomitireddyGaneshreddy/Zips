const db = require('../config/db.config');

class Job {
  static async create(jobData) {
    const [result] = await db.execute(
      'INSERT INTO jobs (posted_by, title, company, location, description) VALUES (?, ?, ?, ?, ?)',
      [jobData.posted_by, jobData.title, jobData.company, jobData.location, jobData.description]
    );
    return result.insertId;
  }

  static async findAll() {
    const [rows] = await db.execute(
      `SELECT j.*, u.first_name, u.last_name 
       FROM jobs j 
       LEFT JOIN users u ON j.posted_by = u.id 
       ORDER BY j.id DESC`
    );
    return rows;
  }

  static async findById(id) {
    const [rows] = await db.execute(
      `SELECT j.*, u.first_name, u.last_name 
       FROM jobs j 
       LEFT JOIN users u ON j.posted_by = u.id 
       WHERE j.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async update(id, jobData) {
    const [result] = await db.execute(
      'UPDATE jobs SET title = ?, company = ?, location = ?, description = ? WHERE id = ?',
      [jobData.title, jobData.company, jobData.location, jobData.description, id]
    );
    return result.affectedRows > 0;
  }

  static async delete(id) {
    const [result] = await db.execute('DELETE FROM jobs WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }
}

module.exports = Job; 