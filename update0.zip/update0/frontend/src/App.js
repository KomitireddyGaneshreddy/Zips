import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import ThemeWrapper from './components/ThemeWrapper';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/layout/Layout';

// Pages
import Login from './pages/Login';
import NewUser from './pages/NewUser';
import Home from './pages/Home';
import Jobs from './pages/Jobs';
import Events from './pages/Events';
import Profile from './pages/Profile';
import Network from './pages/Network';
import Settings from './pages/Settings';
import Mentorship from './pages/Mentorship';

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <ThemeWrapper>
          <Router>
            <Layout>
              <Routes>
                {/* Public routes */}
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<NewUser />} />
                <Route path="/new-user" element={<NewUser />} />
                
                {/* Protected routes */}
                <Route
                  path="/home"
                  element={
                    <ProtectedRoute>
                      <Home />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/jobs"
                  element={
                    <ProtectedRoute>
                      <Jobs />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/events"
                  element={
                    <ProtectedRoute>
                      <Events />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/profile"
                  element={
                    <ProtectedRoute>
                      <Profile />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/network"
                  element={
                    <ProtectedRoute>
                      <Network />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/settings"
                  element={
                    <ProtectedRoute>
                      <Settings />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/mentorship"
                  element={
                    <ProtectedRoute>
                      <Mentorship />
                    </ProtectedRoute>
                  }
                />
                
                {/* Redirect from root to login */}
                <Route path="/" element={<Navigate to="/login" />} />
                
                {/* Catch-all redirect to home for authenticated users or login for non-authenticated */}
                <Route
                  path="*"
                  element={
                    <ProtectedRoute>
                      <Navigate to="/home" />
                    </ProtectedRoute>
                  }
                />
              </Routes>
            </Layout>
          </Router>
        </ThemeWrapper>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
