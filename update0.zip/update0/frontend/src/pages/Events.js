import React, { useState } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
  Chip,
  MenuItem,
  Avatar,
  Paper,
  DialogContentText,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import EventIcon from '@mui/icons-material/Event';
import CloseIcon from '@mui/icons-material/Close';
import GroupIcon from '@mui/icons-material/Group';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { formatDistanceToNow } from 'date-fns';

const Events = () => {
  const [openPostEvent, setOpenPostEvent] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
    type: 'In-Person',
    registrationLink: '',
    maxAttendees: '',
    department: 'All',
  });

  const [eventsList, setEventsList] = useState([
    {
      id: 1,
      title: 'Annual Alumni Meet 2024',
      description: 'Join us for the annual alumni gathering with networking opportunities, keynote speakers, and cultural events.',
      date: '2024-05-15',
      time: '10:00',
      location: 'JNTUA Campus, Anantapur',
      type: 'In-Person',
      registrationLink: 'https://example.com/register',
      maxAttendees: 200,
      department: 'All',
      postedBy: {
        name: 'Dr. Ramesh Kumar',
        avatar: '#1a237e',
        designation: 'Alumni Coordinator',
        batch: '1995',
      },
      postedAt: new Date('2024-03-10'),
    },
    {
      id: 2,
      title: 'Tech Talk: AI in Industry',
      description: 'Virtual session on the impact of AI in various industries with Q&A.',
      date: '2024-04-20',
      time: '18:00',
      location: 'Online (Zoom)',
      type: 'Virtual',
      registrationLink: 'https://zoom.us/register',
      maxAttendees: 500,
      department: 'CSE',
      postedBy: {
        name: 'Suresh Reddy',
        avatar: '#c2185b',
        designation: 'Senior Tech Lead',
        batch: '2010',
      },
      postedAt: new Date('2024-03-12'),
    },
  ]);

  const handlePostEvent = () => {
    const newEvent = {
      id: eventsList.length + 1,
      ...eventForm,
      postedBy: {
        name: 'Current User',
        avatar: '#1a237e',
        designation: 'Alumni',
        batch: '2020',
      },
      postedAt: new Date(),
    };
    
    setEventsList([newEvent, ...eventsList]);
    setOpenPostEvent(false);
    setEventForm({
      title: '',
      description: '',
      date: '',
      time: '',
      location: '',
      type: 'In-Person',
      registrationLink: '',
      maxAttendees: '',
      department: 'All',
    });
  };

  const filteredEvents = eventsList.filter(event =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 1 }}>
              Events
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Discover and organize alumni events and gatherings
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setOpenPostEvent(true)}
            sx={{
              bgcolor: '#1a237e',
              '&:hover': { bgcolor: '#0d1b60' },
              px: 3,
              py: 1.5,
              borderRadius: 2,
            }}
          >
            Post Event
          </Button>
        </Box>

        {/* Search */}
        <Paper 
          elevation={0}
          sx={{ 
            p: 3,
            mb: 4,
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <TextField
            fullWidth
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search events by title, description, or location..."
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon color="action" />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'white',
              },
            }}
          />
        </Paper>

        {/* Post Event Dialog */}
        <Dialog 
          open={openPostEvent} 
          onClose={() => setOpenPostEvent(false)}
          maxWidth="sm"
          fullWidth
          PaperProps={{
            sx: {
              borderRadius: 2,
              '& .MuiDialogTitle-root': {
                bgcolor: '#1a237e',
                color: 'white',
                py: 1.5,
              },
            },
          }}
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Post a New Event
              <IconButton onClick={() => setOpenPostEvent(false)} sx={{ color: 'white' }}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers sx={{ bgcolor: '#f8f9fa', p: 2 }}>
            <DialogContentText sx={{ mb: 2, p: 1.5, bgcolor: 'white', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
              Share an event with the JNTUA alumni community.
            </DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Event Title"
                  value={eventForm.title}
                  onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  type="date"
                  label="Date"
                  value={eventForm.date}
                  onChange={(e) => setEventForm({ ...eventForm, date: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  type="time"
                  label="Time"
                  value={eventForm.time}
                  onChange={(e) => setEventForm({ ...eventForm, time: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Location"
                  value={eventForm.location}
                  onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  required
                  fullWidth
                  label="Event Type"
                  value={eventForm.type}
                  onChange={(e) => setEventForm({ ...eventForm, type: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                >
                  <MenuItem value="In-Person">In-Person</MenuItem>
                  <MenuItem value="Virtual">Virtual</MenuItem>
                  <MenuItem value="Hybrid">Hybrid</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  required
                  fullWidth
                  label="Department"
                  value={eventForm.department}
                  onChange={(e) => setEventForm({ ...eventForm, department: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                >
                  <MenuItem value="All">All Departments</MenuItem>
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Registration Link"
                  value={eventForm.registrationLink}
                  onChange={(e) => setEventForm({ ...eventForm, registrationLink: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Maximum Attendees"
                  type="number"
                  value={eventForm.maxAttendees}
                  onChange={(e) => setEventForm({ ...eventForm, maxAttendees: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  multiline
                  rows={4}
                  label="Event Description"
                  value={eventForm.description}
                  onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2, bgcolor: '#f8f9fa' }}>
            <Button 
              onClick={() => setOpenPostEvent(false)}
              sx={{ color: 'text.secondary' }}
            >
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handlePostEvent}
              disabled={!eventForm.title || !eventForm.description || !eventForm.date || !eventForm.location}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Post Event
            </Button>
          </DialogActions>
        </Dialog>

        {/* Event Cards */}
        <Grid container spacing={3}>
          {filteredEvents.map((event) => (
            <Grid item xs={12} key={event.id}>
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': {
                    borderColor: 'primary.main',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                  },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={8}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                        <Typography variant="h6" sx={{ fontWeight: 600 }}>
                          {event.title}
                        </Typography>
                        <Chip 
                          label={event.type} 
                          size="small"
                          sx={{ 
                            bgcolor: event.type === 'Virtual' ? '#e3f2fd' : '#e8f5e9',
                            color: event.type === 'Virtual' ? '#1565c0' : '#2e7d32'
                          }}
                        />
                      </Box>
                      <Box sx={{ display: 'flex', gap: 3, mb: 2, color: 'text.secondary' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <EventIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">
                            {new Date(event.date).toLocaleDateString()} at {event.time}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <LocationOnIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">{event.location}</Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <GroupIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">Max {event.maxAttendees} attendees</Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        {event.description}
                      </Typography>
                      {event.department !== 'All' && (
                        <Chip 
                          label={event.department}
                          size="small"
                          sx={{ bgcolor: '#f3e5f5', color: '#7b1fa2' }}
                        />
                      )}
                    </Grid>
                    <Grid item xs={12} md={4} sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                        <Avatar sx={{ bgcolor: event.postedBy.avatar, width: 32, height: 32, fontSize: '0.9rem' }}>
                          {event.postedBy.name[0]}
                        </Avatar>
                        <Box>
                          <Typography variant="subtitle2">{event.postedBy.name}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {event.postedBy.designation} • {event.postedBy.batch} batch
                          </Typography>
                        </Box>
                      </Box>
                      <Box>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 2 }}>
                          <AccessTimeIcon sx={{ fontSize: 16 }} />
                          Posted {formatDistanceToNow(event.postedAt)} ago
                        </Typography>
                        <Button 
                          variant="contained" 
                          fullWidth
                          href={event.registrationLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          sx={{
                            bgcolor: '#1a237e',
                            '&:hover': { bgcolor: '#0d1b60' },
                          }}
                        >
                          Register Now
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Events; 