import React, { useState } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
  Chip,
  MenuItem,
  Avatar,
  Paper,
  FormControlLabel,
  Checkbox,
  DialogContentText,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import WorkIcon from '@mui/icons-material/Work';
import BusinessIcon from '@mui/icons-material/Business';
import CloseIcon from '@mui/icons-material/Close';
import FilterListIcon from '@mui/icons-material/FilterList';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { formatDistanceToNow } from 'date-fns';

const Jobs = () => {
  const [openPostJob, setOpenPostJob] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    remote: false,
    fullTime: false,
    partTime: false,
    internship: false,
    experience: 'all',
    department: 'all',
  });

  // Updated Form state
  const [jobForm, setJobForm] = useState({
    title: '',
    company: '',
    location: '',
    type: 'Full-time',
    remote: false,
    department: 'CSE',
    experience: '0-1 year',
    description: '',
    requirements: '',
    applicationLink: '', // New field
    salary: '', // New field
    deadline: '', // New field
  });

  // Updated Mock jobs data
  const [jobsList, setJobsList] = useState([
    {
      id: 1,
      title: 'Senior Software Engineer',
      company: 'TechCorp',
      location: 'Bangalore, India',
      type: 'Full-time',
      remote: true,
      department: 'CSE',
      experience: '5+ years',
      salary: '₹20-30 LPA',
      deadline: '2024-04-10',
      applicationLink: 'https://techcorp.com/careers/sde',
      postedBy: {
        name: 'Ravi Kumar',
        avatar: '#1a237e',
        designation: 'Tech Lead',
        batch: '2015',
      },
      postedAt: new Date('2024-03-10'),
      description: 'Looking for an experienced software engineer...',
    },
    {
      id: 2,
      title: 'Machine Learning Engineer',
      company: 'AI Solutions',
      location: 'Hyderabad, India',
      type: 'Full-time',
      remote: false,
      department: 'CSE',
      experience: '3+ years',
      postedBy: {
        name: 'Priya Reddy',
        avatar: '#c2185b',
        designation: 'ML Manager',
        batch: '2016',
      },
      postedAt: new Date('2024-03-12'),
      description: 'Join our AI team to work on cutting-edge projects...',
    },
    {
      id: 3,
      title: 'Product Design Intern',
      company: 'Design Studios',
      location: 'Chennai, India',
      type: 'Internship',
      remote: true,
      department: 'ECE',
      experience: '0-1 year',
      postedBy: {
        name: 'Karthik S',
        avatar: '#00695c',
        designation: 'Design Director',
        batch: '2017',
      },
      postedAt: new Date('2024-03-13'),
      description: 'Great opportunity for fresh graduates...',
    },
  ]);

  const handlePostJob = () => {
    const newJob = {
      id: jobsList.length + 1,
      ...jobForm,
      postedBy: {
        name: 'Current User', // This should be replaced with actual user data
        avatar: '#1a237e',
        designation: 'Alumni',
        batch: '2020',
      },
      postedAt: new Date(),
    };
    
    setJobsList([newJob, ...jobsList]);
    setOpenPostJob(false);
    setJobForm({
      title: '',
      company: '',
      location: '',
      type: 'Full-time',
      remote: false,
      department: 'CSE',
      experience: '0-1 year',
      description: '',
      requirements: '',
      applicationLink: '',
      salary: '',
      deadline: '',
    });
  };

  const filteredJobs = jobsList.filter(job => {
    const matchesSearch = 
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRemote = !filters.remote || job.remote;
    const matchesType = 
      (!filters.fullTime && !filters.partTime && !filters.internship) ||
      (filters.fullTime && job.type === 'Full-time') ||
      (filters.partTime && job.type === 'Part-time') ||
      (filters.internship && job.type === 'Internship');
    
    const matchesExperience = filters.experience === 'all' || job.experience.includes(filters.experience);
    const matchesDepartment = filters.department === 'all' || job.department === filters.department;

    return matchesSearch && matchesRemote && matchesType && matchesExperience && matchesDepartment;
  });

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 1 }}>
              Job Board
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Find and post job opportunities within the JNTUA alumni network
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setOpenPostJob(true)}
            sx={{
              bgcolor: '#1a237e',
              '&:hover': { bgcolor: '#0d1b60' },
              px: 3,
              py: 1.5,
              borderRadius: 2,
            }}
          >
            Post a Job
          </Button>
        </Box>

        {/* Search and Filters */}
        <Paper 
          elevation={0}
          sx={{ 
            p: 3,
            mb: 4,
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search jobs by title, company, or location..."
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon color="action" />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    bgcolor: 'white',
                  },
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2" sx={{ mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                <FilterListIcon /> Filters
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.remote}
                      onChange={(e) => setFilters({ ...filters, remote: e.target.checked })}
                    />
                  }
                  label="Remote"
                />
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.fullTime}
                      onChange={(e) => setFilters({ ...filters, fullTime: e.target.checked })}
                    />
                  }
                  label="Full-time"
                />
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.partTime}
                      onChange={(e) => setFilters({ ...filters, partTime: e.target.checked })}
                    />
                  }
                  label="Part-time"
                />
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.internship}
                      onChange={(e) => setFilters({ ...filters, internship: e.target.checked })}
                    />
                  }
                  label="Internship"
                />
                <TextField
                  select
                  size="small"
                  value={filters.experience}
                  onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
                  sx={{ minWidth: 150 }}
                >
                  <MenuItem value="all">All Experience</MenuItem>
                  <MenuItem value="0">Fresher</MenuItem>
                  <MenuItem value="1">1+ years</MenuItem>
                  <MenuItem value="3">3+ years</MenuItem>
                  <MenuItem value="5">5+ years</MenuItem>
                </TextField>
                <TextField
                  select
                  size="small"
                  value={filters.department}
                  onChange={(e) => setFilters({ ...filters, department: e.target.value })}
                  sx={{ minWidth: 150 }}
                >
                  <MenuItem value="all">All Departments</MenuItem>
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                </TextField>
              </Box>
            </Grid>
          </Grid>
        </Paper>

        {/* Post Job Dialog */}
        <Dialog 
          open={openPostJob} 
          onClose={() => setOpenPostJob(false)}
          maxWidth="sm"
          fullWidth
          PaperProps={{
            sx: {
              borderRadius: 2,
              '& .MuiDialogTitle-root': {
                bgcolor: '#1a237e',
                color: 'white',
                py: 1.5,
              },
            },
          }}
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Post a New Job
              <IconButton onClick={() => setOpenPostJob(false)} sx={{ color: 'white' }}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers sx={{ bgcolor: '#f8f9fa', p: 2 }}>
            <DialogContentText sx={{ mb: 2, p: 1.5, bgcolor: 'white', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
              Share a job opportunity with the JNTUA alumni community.
            </DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Job Title"
                  value={jobForm.title}
                  onChange={(e) => setJobForm({ ...jobForm, title: e.target.value })}
                  placeholder="e.g. Senior Software Engineer"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Company"
                  value={jobForm.company}
                  onChange={(e) => setJobForm({ ...jobForm, company: e.target.value })}
                  placeholder="e.g. TechCorp"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Location"
                  value={jobForm.location}
                  onChange={(e) => setJobForm({ ...jobForm, location: e.target.value })}
                  placeholder="e.g. Bangalore, India"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  required
                  fullWidth
                  label="Job Type"
                  value={jobForm.type}
                  onChange={(e) => setJobForm({ ...jobForm, type: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                >
                  <MenuItem value="Full-time">Full-time</MenuItem>
                  <MenuItem value="Part-time">Part-time</MenuItem>
                  <MenuItem value="Internship">Internship</MenuItem>
                  <MenuItem value="Contract">Contract</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  required
                  fullWidth
                  label="Department"
                  value={jobForm.department}
                  onChange={(e) => setJobForm({ ...jobForm, department: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                >
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  required
                  fullWidth
                  label="Experience Required"
                  value={jobForm.experience}
                  onChange={(e) => setJobForm({ ...jobForm, experience: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                >
                  <MenuItem value="0-1 year">0-1 year</MenuItem>
                  <MenuItem value="1-3 years">1-3 years</MenuItem>
                  <MenuItem value="3-5 years">3-5 years</MenuItem>
                  <MenuItem value="5+ years">5+ years</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Salary Range"
                  value={jobForm.salary}
                  onChange={(e) => setJobForm({ ...jobForm, salary: e.target.value })}
                  placeholder="e.g. ₹10-15 LPA"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  type="date"
                  label="Application Deadline"
                  value={jobForm.deadline}
                  onChange={(e) => setJobForm({ ...jobForm, deadline: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Application Link"
                  value={jobForm.applicationLink}
                  onChange={(e) => setJobForm({ ...jobForm, applicationLink: e.target.value })}
                  placeholder="e.g. https://company.com/careers/job-title"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  multiline
                  rows={4}
                  label="Job Description"
                  value={jobForm.description}
                  onChange={(e) => setJobForm({ ...jobForm, description: e.target.value })}
                  placeholder="Describe the job responsibilities, team structure, and growth opportunities..."
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  multiline
                  rows={4}
                  label="Requirements"
                  value={jobForm.requirements}
                  onChange={(e) => setJobForm({ ...jobForm, requirements: e.target.value })}
                  placeholder="List technical skills, qualifications, and experience required..."
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={jobForm.remote}
                      onChange={(e) => setJobForm({ ...jobForm, remote: e.target.checked })}
                    />
                  }
                  label="This is a remote position"
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2, bgcolor: '#f8f9fa' }}>
            <Button 
              onClick={() => setOpenPostJob(false)}
              sx={{ color: 'text.secondary' }}
            >
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handlePostJob}
              disabled={!jobForm.title || !jobForm.company || !jobForm.description || !jobForm.requirements || !jobForm.applicationLink}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Post Job
            </Button>
          </DialogActions>
        </Dialog>

        {/* Job Cards */}
        <Grid container spacing={3}>
          {filteredJobs.map((job) => (
            <Grid item xs={12} key={job.id}>
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': {
                    borderColor: 'primary.main',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                  },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={8}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                        <Typography variant="h6" sx={{ fontWeight: 600 }}>
                          {job.title}
                        </Typography>
                        {job.remote && (
                          <Chip 
                            label="Remote" 
                            size="small"
                            sx={{ bgcolor: '#e3f2fd', color: '#1565c0' }}
                          />
                        )}
                      </Box>
                      <Box sx={{ display: 'flex', gap: 3, mb: 2, color: 'text.secondary' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <BusinessIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">{job.company}</Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <LocationOnIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">{job.location}</Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <WorkIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">{job.type}</Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        {job.description}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <Chip 
                          label={job.department}
                          size="small"
                          sx={{ bgcolor: '#f3e5f5', color: '#7b1fa2' }}
                        />
                        <Chip 
                          label={job.experience}
                          size="small"
                          sx={{ bgcolor: '#e8f5e9', color: '#2e7d32' }}
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={4} sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                        <Avatar sx={{ bgcolor: job.postedBy.avatar, width: 32, height: 32, fontSize: '0.9rem' }}>
                          {job.postedBy.name[0]}
                        </Avatar>
                        <Box>
                          <Typography variant="subtitle2">{job.postedBy.name}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {job.postedBy.designation} • {job.postedBy.batch} batch
                          </Typography>
                        </Box>
                      </Box>
                      <Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          Salary: {job.salary}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 2 }}>
                          <AccessTimeIcon sx={{ fontSize: 16 }} />
                          Posted {formatDistanceToNow(job.postedAt)} ago
                        </Typography>
                        <Button 
                          variant="contained" 
                          fullWidth
                          href={job.applicationLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          sx={{
                            bgcolor: '#1a237e',
                            '&:hover': { bgcolor: '#0d1b60' },
                          }}
                        >
                          Apply Now
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Jobs; 