import React, { useState } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
  Chip,
  MenuItem,
  Avatar,
  Paper,
  DialogContentText,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import CloseIcon from '@mui/icons-material/Close';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { formatDistanceToNow } from 'date-fns';

const Mentorship = () => {
  const [openPostMentorship, setOpenPostMentorship] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [mentorshipForm, setMentorshipForm] = useState({
    title: '',
    description: '',
    expertise: '',
    experience: '',
    availability: '',
    department: 'CSE',
    type: 'Career Guidance',
    expectations: '',
    contactEmail: '',
  });

  const [mentorshipList, setMentorshipList] = useState([
    {
      id: 1,
      title: 'Career Guidance in Software Development',
      description: 'Offering mentorship in full-stack development, system design, and career growth in tech companies.',
      expertise: 'Full-stack Development, System Design',
      experience: '8+ years',
      availability: '2 hours/week',
      department: 'CSE',
      type: 'Career Guidance',
      expectations: 'Looking for dedicated mentees interested in software development',
      contactEmail: 'mentor@example.com',
      postedBy: {
        name: 'Srinivas Rao',
        avatar: '#1a237e',
        designation: 'Senior Software Engineer',
        batch: '2015',
        company: 'Google',
      },
      postedAt: new Date('2024-03-10'),
    },
    {
      id: 2,
      title: 'Research Mentorship in AI/ML',
      description: 'Guidance for research papers, project implementation, and higher studies in AI/ML.',
      expertise: 'Machine Learning, Deep Learning',
      experience: '5+ years',
      availability: 'Flexible',
      department: 'CSE',
      type: 'Research',
      expectations: 'Strong foundation in mathematics and programming',
      contactEmail: 'aimentor@example.com',
      postedBy: {
        name: 'Dr. Lakshmi Prasad',
        avatar: '#c2185b',
        designation: 'Research Scientist',
        batch: '2012',
        company: 'Microsoft Research',
      },
      postedAt: new Date('2024-03-12'),
    },
  ]);

  const handlePostMentorship = () => {
    const newMentorship = {
      id: mentorshipList.length + 1,
      ...mentorshipForm,
      postedBy: {
        name: 'Current User',
        avatar: '#1a237e',
        designation: 'Alumni',
        batch: '2020',
        company: 'Company Name',
      },
      postedAt: new Date(),
    };
    
    setMentorshipList([newMentorship, ...mentorshipList]);
    setOpenPostMentorship(false);
    setMentorshipForm({
      title: '',
      description: '',
      expertise: '',
      experience: '',
      availability: '',
      department: 'CSE',
      type: 'Career Guidance',
      expectations: '',
      contactEmail: '',
    });
  };

  const filteredMentorships = mentorshipList.filter(mentorship =>
    mentorship.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mentorship.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mentorship.expertise.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 1 }}>
              Mentorship
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Connect with alumni mentors for guidance and support
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setOpenPostMentorship(true)}
            sx={{
              bgcolor: '#1a237e',
              '&:hover': { bgcolor: '#0d1b60' },
              px: 3,
              py: 1.5,
              borderRadius: 2,
            }}
          >
            Offer Mentorship
          </Button>
        </Box>

        {/* Search */}
        <Paper 
          elevation={0}
          sx={{ 
            p: 3,
            mb: 4,
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <TextField
            fullWidth
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search mentorship opportunities by title, description, or expertise..."
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon color="action" />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'white',
              },
            }}
          />
        </Paper>

        {/* Post Mentorship Dialog */}
        <Dialog 
          open={openPostMentorship} 
          onClose={() => setOpenPostMentorship(false)}
          maxWidth="sm"
          fullWidth
          PaperProps={{
            sx: {
              borderRadius: 2,
              '& .MuiDialogTitle-root': {
                bgcolor: '#1a237e',
                color: 'white',
                py: 1.5,
              },
            },
          }}
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Offer Mentorship
              <IconButton onClick={() => setOpenPostMentorship(false)} sx={{ color: 'white' }}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers sx={{ bgcolor: '#f8f9fa', p: 2 }}>
            <DialogContentText sx={{ mb: 2, p: 1.5, bgcolor: 'white', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
              Share your expertise and guide fellow alumni in their professional journey.
            </DialogContentText>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Title"
                  value={mentorshipForm.title}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, title: e.target.value })}
                  placeholder="e.g. Career Guidance in Software Development"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  required
                  fullWidth
                  label="Department"
                  value={mentorshipForm.department}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, department: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                >
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  required
                  fullWidth
                  label="Mentorship Type"
                  value={mentorshipForm.type}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, type: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                >
                  <MenuItem value="Career Guidance">Career Guidance</MenuItem>
                  <MenuItem value="Technical Skills">Technical Skills</MenuItem>
                  <MenuItem value="Research">Research</MenuItem>
                  <MenuItem value="Higher Studies">Higher Studies</MenuItem>
                  <MenuItem value="Entrepreneurship">Entrepreneurship</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Areas of Expertise"
                  value={mentorshipForm.expertise}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, expertise: e.target.value })}
                  placeholder="e.g. Full-stack Development, System Design"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Experience"
                  value={mentorshipForm.experience}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, experience: e.target.value })}
                  placeholder="e.g. 5+ years"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Availability"
                  value={mentorshipForm.availability}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, availability: e.target.value })}
                  placeholder="e.g. 2 hours/week"
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  label="Contact Email"
                  type="email"
                  value={mentorshipForm.contactEmail}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, contactEmail: e.target.value })}
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  multiline
                  rows={4}
                  label="Description"
                  value={mentorshipForm.description}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, description: e.target.value })}
                  placeholder="Describe your mentorship approach and what mentees can expect..."
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  multiline
                  rows={4}
                  label="Expectations from Mentees"
                  value={mentorshipForm.expectations}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, expectations: e.target.value })}
                  placeholder="List prerequisites, commitment expectations, etc..."
                  sx={{ bgcolor: 'white' }}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2, bgcolor: '#f8f9fa' }}>
            <Button 
              onClick={() => setOpenPostMentorship(false)}
              sx={{ color: 'text.secondary' }}
            >
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handlePostMentorship}
              disabled={!mentorshipForm.title || !mentorshipForm.description || !mentorshipForm.expertise || !mentorshipForm.contactEmail}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Post Mentorship
            </Button>
          </DialogActions>
        </Dialog>

        {/* Mentorship Cards */}
        <Grid container spacing={3}>
          {filteredMentorships.map((mentorship) => (
            <Grid item xs={12} key={mentorship.id}>
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': {
                    borderColor: 'primary.main',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                  },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={8}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                        <Typography variant="h6" sx={{ fontWeight: 600 }}>
                          {mentorship.title}
                        </Typography>
                        <Chip 
                          label={mentorship.type} 
                          size="small"
                          sx={{ bgcolor: '#e3f2fd', color: '#1565c0' }}
                        />
                      </Box>
                      <Box sx={{ display: 'flex', gap: 3, mb: 2, color: 'text.secondary' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <WorkIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">{mentorship.experience}</Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <SchoolIcon sx={{ fontSize: 18 }} />
                          <Typography variant="body2">{mentorship.department}</Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        {mentorship.description}
                      </Typography>
                      <Box sx={{ mb: 2 }}>
                        <Typography variant="subtitle2" gutterBottom>Areas of Expertise:</Typography>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                          {mentorship.expertise.split(',').map((skill, index) => (
                            <Chip 
                              key={index}
                              label={skill.trim()}
                              size="small"
                              sx={{ bgcolor: '#f3e5f5', color: '#7b1fa2' }}
                            />
                          ))}
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary">
                        <strong>Availability:</strong> {mentorship.availability}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={4} sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                        <Avatar sx={{ bgcolor: mentorship.postedBy.avatar, width: 32, height: 32, fontSize: '0.9rem' }}>
                          {mentorship.postedBy.name[0]}
                        </Avatar>
                        <Box>
                          <Typography variant="subtitle2">{mentorship.postedBy.name}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {mentorship.postedBy.designation} at {mentorship.postedBy.company}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" display="block">
                            {mentorship.postedBy.batch} batch
                          </Typography>
                        </Box>
                      </Box>
                      <Box>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 2 }}>
                          <AccessTimeIcon sx={{ fontSize: 16 }} />
                          Posted {formatDistanceToNow(mentorship.postedAt)} ago
                        </Typography>
                        <Button 
                          variant="contained" 
                          fullWidth
                          href={`mailto:${mentorship.contactEmail}`}
                          sx={{
                            bgcolor: '#1a237e',
                            '&:hover': { bgcolor: '#0d1b60' },
                          }}
                        >
                          Request Mentorship
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Mentorship; 