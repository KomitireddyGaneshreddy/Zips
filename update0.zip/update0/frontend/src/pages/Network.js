import React, { useState, useMemo } from 'react';
import {
  Box,
  Typography,
  TextField,
  MenuItem,
  Grid,
  Card,
  CardContent,
  Button,
  Avatar,
  Tabs,
  Tab,
  InputAdornment,
  Chip,
  Container,
  Paper,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import PersonIcon from '@mui/icons-material/Person';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import GroupIcon from '@mui/icons-material/Group';
import EventIcon from '@mui/icons-material/Event';
import { alpha } from '@mui/material/styles';

const Network = () => {
  const [tab, setTab] = useState(0);
  const [department, setDepartment] = useState('All Departments');
  const [batch, setBatch] = useState('All Batches');
  const [searchQuery, setSearchQuery] = useState('');
  const [connections, setConnections] = useState(new Set());

  // Mock data - will be replaced with API calls
  const suggestedConnections = [
    {
      id: 1,
      name: 'Surya Teja',
      role: 'Senior Product Manager',
      company: 'TechCorp',
      department: 'CSE',
      batch: '2016',
      commonalities: ['Same department', '2 years apart'],
      avatarColor: '#ff5722',
    },
    {
      id: 2,
      name: 'Sai Krishna',
      role: 'ML Engineer',
      company: 'DataVision',
      department: 'CSE',
      batch: '2019',
      commonalities: ['Same department', '1 year apart'],
      avatarColor: '#4caf50',
    },
    {
      id: 3,
      name: 'Venkata Ramana',
      role: 'Software Architect',
      company: 'Infosys',
      department: 'CSE',
      batch: '2018',
      commonalities: ['Same batch', 'Same department'],
      avatarColor: '#2196f3',
    },
    {
      id: 4,
      name: 'Lakshmi Prasanna',
      role: 'Data Scientist',
      company: 'Amazon',
      department: 'ECE',
      batch: '2017',
      commonalities: ['Common interests', 'Similar career path'],
      avatarColor: '#9c27b0',
    }
  ];

  const handleTabChange = (event, newValue) => {
    setTab(newValue);
  };

  const handleConnect = (alumniId) => {
    setConnections(prev => {
      const newConnections = new Set(prev);
      if (newConnections.has(alumniId)) {
        newConnections.delete(alumniId);
      } else {
        newConnections.add(alumniId);
      }
      return newConnections;
    });
  };

  // Filter alumni based on search query and filters
  const filteredAlumni = useMemo(() => {
    return suggestedConnections.filter(alumni => {
      const matchesSearch = searchQuery === '' || 
        alumni.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        alumni.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
        alumni.company.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDepartment = department === 'All Departments' || 
        alumni.department === department;

      const matchesBatch = batch === 'All Batches' || 
        alumni.batch === batch;

      return matchesSearch && matchesDepartment && matchesBatch;
    });
  }, [searchQuery, department, batch]);

  // Get connected alumni
  const connectedAlumni = useMemo(() => {
    return suggestedConnections.filter(alumni => connections.has(alumni.id));
  }, [connections]);

  const renderAlumniCard = (alumni) => (
    <Grid item xs={12} key={alumni.id}>
      <Card 
        elevation={0}
        sx={{ 
          borderRadius: 2,
          border: '1px solid',
          borderColor: 'divider',
          transition: 'transform 0.2s ease, box-shadow 0.2s ease',
          maxWidth: '700px',
          mx: 'auto',
          '&:hover': {
            transform: 'translateY(-2px)',
            boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
          },
        }}
      >
        <CardContent sx={{ p: 2 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item>
              <Avatar 
                sx={{ 
                  width: 45, 
                  height: 45,
                  bgcolor: alumni.avatarColor,
                  fontSize: '1.1rem',
                  fontWeight: 500,
                }}
              >
                {alumni.name[0]}
              </Avatar>
            </Grid>
            <Grid item xs>
              <Typography variant="subtitle1" sx={{ fontWeight: 600, fontSize: '0.9rem' }}>
                {alumni.name}
              </Typography>
              <Typography 
                sx={{ 
                  color: 'text.secondary',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                  mb: 0.5,
                  fontSize: '0.8rem'
                }}
              >
                <WorkIcon sx={{ fontSize: 14 }} />
                {alumni.role} at {alumni.company}
              </Typography>
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 0.5 }}>
                <Chip 
                  icon={<SchoolIcon sx={{ fontSize: '0.9rem' }} />}
                  label={alumni.department}
                  size="small"
                  sx={{ 
                    bgcolor: alpha(alumni.avatarColor, 0.1),
                    height: '22px',
                    '& .MuiChip-label': {
                      fontSize: '0.75rem',
                      px: 1
                    }
                  }}
                />
                <Chip 
                  icon={<PersonIcon sx={{ fontSize: '0.9rem' }} />}
                  label={`Class of ${alumni.batch}`}
                  size="small"
                  sx={{ 
                    bgcolor: alpha(alumni.avatarColor, 0.1),
                    height: '22px',
                    '& .MuiChip-label': {
                      fontSize: '0.75rem',
                      px: 1
                    }
                  }}
                />
              </Box>
              <Box>
                <Typography 
                  variant="caption" 
                  color="text.secondary"
                  sx={{ display: 'block', mb: 0.5 }}
                >
                  You have in common:
                </Typography>
                {alumni.commonalities.map((common, index) => (
                  <Chip
                    key={index}
                    label={common}
                    size="small"
                    sx={{ 
                      mr: 0.5,
                      mb: 0.5,
                      bgcolor: 'transparent',
                      border: '1px solid',
                      borderColor: 'divider',
                      height: '20px',
                      '& .MuiChip-label': {
                        fontSize: '0.7rem',
                        px: 1
                      }
                    }}
                  />
                ))}
              </Box>
            </Grid>
            <Grid item>
              <Button 
                variant="contained" 
                size="small"
                onClick={() => handleConnect(alumni.id)}
                sx={{ 
                  bgcolor: connections.has(alumni.id) ? 'success.main' : alumni.avatarColor,
                  fontSize: '0.8rem',
                  py: 0.5,
                  minWidth: '80px',
                  '&:hover': {
                    bgcolor: connections.has(alumni.id) 
                      ? 'success.dark'
                      : alpha(alumni.avatarColor, 0.9),
                  },
                }}
              >
                {connections.has(alumni.id) ? 'Connected' : 'Connect'}
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Grid>
  );

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Page Header */}
        <Box sx={{ mb: 4, textAlign: 'center' }}>
          <Typography 
            variant="h4" 
            sx={{ 
              fontWeight: 600,
              color: '#1a237e',
              mb: 1,
            }}
          >
            Alumni Network
          </Typography>
          <Typography 
            variant="subtitle1" 
            color="text.secondary"
            sx={{ maxWidth: 600, mx: 'auto' }}
          >
            Connect with fellow alumni, share experiences, and grow your professional network
          </Typography>
        </Box>

        {/* Network Stats */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3, 
                textAlign: 'center',
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: 2,
                transition: 'transform 0.2s ease',
                '&:hover': {
                  transform: 'translateY(-4px)',
                },
              }}
            >
              <GroupIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
              <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>5,000+</Typography>
              <Typography color="text.secondary">Alumni Members</Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3, 
                textAlign: 'center',
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: 2,
                transition: 'transform 0.2s ease',
                '&:hover': {
                  transform: 'translateY(-4px)',
                },
              }}
            >
              <SchoolIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
              <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>16+</Typography>
              <Typography color="text.secondary">Batches</Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3, 
                textAlign: 'center',
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: 2,
                transition: 'transform 0.2s ease',
                '&:hover': {
                  transform: 'translateY(-4px)',
                },
              }}
            >
              <EventIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
              <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>1+</Typography>
              <Typography color="text.secondary">Alumni Meetups</Typography>
            </Paper>
          </Grid>
        </Grid>

        {/* Tabs */}
        <Paper 
          elevation={0}
          sx={{ 
            mb: 4,
            borderRadius: 2,
            overflow: 'hidden',
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <Tabs 
            value={tab} 
            onChange={handleTabChange}
            sx={{ 
              bgcolor: 'white',
              borderBottom: '1px solid',
              borderColor: 'divider',
              '& .MuiTab-root': {
                minHeight: 64,
                fontSize: '1rem',
              },
            }}
          >
            <Tab 
              label="Discover Alumni" 
              icon={<SearchIcon />}
              iconPosition="start"
            />
            <Tab 
              label="Connected Alumni" 
              icon={<GroupIcon />}
              iconPosition="start"
            />
          </Tabs>
        </Paper>

        {tab === 0 && (
          <>
            {/* Search and Filters */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                mb: 4,
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search alumni by name, role, or company..."
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon color="action" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'white',
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={6} md={3}>
                  <TextField
                    select
                    fullWidth
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    label="Department"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'white',
                      },
                    }}
                  >
                    <MenuItem value="All Departments">All Departments</MenuItem>
                    <MenuItem value="CSE">CSE</MenuItem>
                    <MenuItem value="ECE">ECE</MenuItem>
                    <MenuItem value="MECH">MECH</MenuItem>
                  </TextField>
                </Grid>
                <Grid item xs={6} md={3}>
                  <TextField
                    select
                    fullWidth
                    value={batch}
                    onChange={(e) => setBatch(e.target.value)}
                    label="Batch"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'white',
                      },
                    }}
                  >
                    <MenuItem value="All Batches">All Batches</MenuItem>
                    <MenuItem value="2023">2023</MenuItem>
                    <MenuItem value="2022">2022</MenuItem>
                    <MenuItem value="2021">2021</MenuItem>
                  </TextField>
                </Grid>
              </Grid>
            </Paper>

            {/* Suggested Connections */}
            <Typography 
              variant="h6" 
              sx={{ 
                mb: 3,
                fontWeight: 600,
                color: '#1a237e',
              }}
            >
              Suggested Connections
            </Typography>

            <Grid container spacing={2}>
              {filteredAlumni.length > 0 ? (
                filteredAlumni.map(alumni => renderAlumniCard(alumni))
              ) : (
                <Grid item xs={12}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      textAlign: 'center', 
                      py: 6,
                      borderRadius: 2,
                      border: '1px solid',
                      borderColor: 'divider',
                    }}
                  >
                    <SearchIcon 
                      sx={{ 
                        fontSize: 48,
                        color: 'text.secondary',
                        mb: 2,
                      }}
                    />
                    <Typography variant="h6" color="text.secondary" gutterBottom>
                      No matching alumni found
                    </Typography>
                    <Typography color="text.secondary" sx={{ mb: 2 }}>
                      Try adjusting your search or filters
                    </Typography>
                    {(searchQuery || department !== 'All Departments' || batch !== 'All Batches') && (
                      <Button
                        variant="outlined"
                        onClick={() => {
                          setSearchQuery('');
                          setDepartment('All Departments');
                          setBatch('All Batches');
                        }}
                        startIcon={<SearchIcon />}
                      >
                        Clear all filters
                      </Button>
                    )}
                  </Paper>
                </Grid>
              )}
            </Grid>
          </>
        )}

        {tab === 1 && (
          <>
            {connectedAlumni.length > 0 ? (
              <>
                <Typography 
                  variant="h6" 
                  sx={{ 
                    mb: 3,
                    fontWeight: 600,
                    color: '#1a237e',
                  }}
                >
                  Your Connections ({connectedAlumni.length})
                </Typography>
                <Grid container spacing={2}>
                  {connectedAlumni.map(alumni => renderAlumniCard(alumni))}
                </Grid>
              </>
            ) : (
              <Paper 
                elevation={0}
                sx={{ 
                  textAlign: 'center', 
                  py: 8,
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                }}
              >
                <GroupIcon 
                  sx={{ 
                    fontSize: 64,
                    color: 'text.secondary',
                    mb: 2,
                  }}
                />
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  No connections yet
                </Typography>
                <Typography color="text.secondary" sx={{ mb: 3 }}>
                  Start connecting with other alumni to build your network
                </Typography>
                <Button
                  variant="contained"
                  onClick={() => setTab(0)}
                  startIcon={<SearchIcon />}
                >
                  Discover Alumni
                </Button>
              </Paper>
            )}
          </>
        )}
      </Container>
    </Box>
  );
};

export default Network; 