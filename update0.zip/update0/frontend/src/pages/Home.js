import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  Button,
  Avatar,
  Container,
  Card,
  CardContent,
  Chip,
  IconButton,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  CircularProgress,
  Alert,
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import {
  Work as WorkIcon,
  Event as EventIcon,
  School as SchoolIcon,
  Group as GroupIcon,
  Person as PersonIcon,
} from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import { authService } from '../services/api';
import { formatDistanceToNow } from 'date-fns';

const Home = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [featuredJobs, setFeaturedJobs] = useState([]);
  const [networkStats, setNetworkStats] = useState({
    totalUsers: 0,
    upcomingEvents: 0,
    activeJobs: 0,
    activeMentorships: 0,
    connections: 0,
    pendingConnections: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch user profile
        const profileResponse = await authService.getProfile();
        console.log('User Profile:', profileResponse);
        setUserProfile(profileResponse);

        // Fetch upcoming events
        const eventsResponse = await authService.getUpcomingEvents();
        console.log('Upcoming Events:', eventsResponse);
        setUpcomingEvents(eventsResponse);

        // Fetch featured jobs
        const jobsResponse = await authService.getAllJobs();
        console.log('Featured Jobs:', jobsResponse);
        setFeaturedJobs(jobsResponse.slice(0, 3)); // Show only 3 featured jobs

        // Fetch network statistics
        const statsResponse = await authService.getNetworkStats();
        console.log('Network stats response:', statsResponse); // Debug log
        setNetworkStats(statsResponse);

      } catch (err) {
        setError(err.message || 'Failed to fetch data');
        console.error('Error fetching data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh' }}>
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Grid container spacing={3}>
          {/* Left Column */}
          <Grid item xs={12} md={3}>
            {/* Profile Card */}
            <RouterLink 
              to="/profile" 
              style={{ textDecoration: 'none' }}
            >
              <Paper 
                elevation={0}
                sx={{ 
                  p: 3,
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  mb: 3,
                  bgcolor: 'background.paper',
                  cursor: 'pointer',
                  '&:hover': {
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                  },
                }}
              >
                <Box sx={{ textAlign: 'center', mb: 2 }}>
                  <Avatar
                    sx={{
                      width: 100,
                      height: 100,
                      mx: 'auto',
                      mb: 2,
                      bgcolor: 'primary.main',
                      fontSize: '2rem',
                    }}
                  > 
                    {userProfile?.first_name?.[0] || <PersonIcon />}
                  </Avatar>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 0.5 }}>
                    {userProfile?.first_name} {userProfile?.last_name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {userProfile?.current_company ? `${userProfile.current_company} • ${userProfile.designation}` : 'Complete your profile to get started'}
                  </Typography>
                  <Button
                    variant="outlined"
                    startIcon={<PersonIcon />}
                    fullWidth
                    sx={{ mb: 1 }}
                    component={RouterLink}
                    to="/profile"
                    onClick={(e) => e.stopPropagation()}
                  >
                    Edit Profile
                  </Button>
                  <Button
                    variant="contained"
                    startIcon={<PersonIcon />}
                    fullWidth
                    onClick={(e) => {
                      e.stopPropagation();
                      navigator.clipboard.writeText(window.location.origin + '/profile');
                    }}
                  >
                    Share Profile
                  </Button>
                </Box>
                <Divider sx={{ my: 2 }} />
                <Box>
                  <List>
                    <ListItem>
                      <ListItemText
                        primary="Education"
                        secondary={
                          <>
                            <Typography variant="body2" color="text.primary">
                              {userProfile?.education?.degree}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {userProfile?.education?.institution}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {userProfile?.education?.year}
                            </Typography>
                            {userProfile?.education?.grade && (
                              <Typography variant="body2" color="text.secondary">
                                Grade: {userProfile.education.grade}
                              </Typography>
                            )}
                          </>
                        }
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText
                        primary="Experience"
                        secondary={
                          <>
                            <Typography variant="body2" color="text.primary">
                              {userProfile?.experience?.role}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {userProfile?.experience?.company}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {userProfile?.experience?.duration}
                            </Typography>
                            {userProfile?.experience?.description && (
                              <Typography variant="body2" color="text.secondary">
                                {userProfile.experience.description}
                              </Typography>
                            )}
                          </>
                        }
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText
                        primary="Skills"
                        secondary={
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                            {userProfile?.skills?.map((skill, index) => (
                              <Chip
                                key={index}
                                label={skill.name}
                                size="small"
                                sx={{ m: 0.5 }}
                              />
                            ))}
                          </Box>
                        }
                      />
                    </ListItem>
                  </List>
                </Box>
              </Paper>
            </RouterLink>

            {/* Quick Actions */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                Quick Actions
              </Typography>
              <List>
                <ListItem button>
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: 'primary.main' }}>
                      <WorkIcon />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText primary="Post a Job" secondary="Share opportunities with alumni" />
                </ListItem>
                <ListItem button>
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: 'success.main' }}>
                      <EventIcon />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText primary="Create Event" secondary="Organize alumni meetups" />
                </ListItem>
                <ListItem button>
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: 'info.main' }}>
                      <SchoolIcon />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText primary="Mentorship" secondary="Share your expertise" />
                </ListItem>
              </List>
            </Paper>
          </Grid>

          {/* Center Column */}
          <Grid item xs={12} md={6}>
            {/* Upcoming Events */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Upcoming Events
                </Typography>
                <Button 
                  component={RouterLink} 
                  to="/events"
                  sx={{ color: 'primary.main' }}
                >
                  View All
                </Button>
              </Box>
              <List>
                {upcomingEvents.map((event) => (
                  <React.Fragment key={event.id}>
                    <ListItem>
                      <ListItemAvatar>
                        <Avatar sx={{ bgcolor: 'secondary.main' }}>
                          <EventIcon />
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={event.title}
                        secondary={
                          <>
                            <Typography component="span" variant="body2" color="text.primary">
                              {new Date(event.date).toLocaleDateString()} • {event.time}
                            </Typography>
                            <br />
                            {event.location}
                          </>
                        }
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                  </React.Fragment>
                ))}
                {upcomingEvents.length === 0 && (
                  <ListItem>
                    <ListItemText primary="No upcoming events" />
                  </ListItem>
                )}
              </List>
            </Paper>

            {/* Featured Jobs */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Featured Jobs
                </Typography>
                <Button 
                  component={RouterLink} 
                  to="/jobs"
                  sx={{ color: 'primary.main' }}
                >
                  View All
                </Button>
              </Box>
              <List>
                {featuredJobs.map((job) => (
                  <React.Fragment key={job.id}>
                    <ListItem>
                      <ListItemAvatar>
                        <Avatar sx={{ bgcolor: 'primary.main' }}>
                          <WorkIcon />
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText
                        primary={job.title}
                        secondary={
                          <>
                            <Typography component="span" variant="body2" color="text.primary">
                        {job.company}
                      </Typography>
                            <br />
                          {job.location}
                          </>
                        }
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                  </React.Fragment>
                ))}
                {featuredJobs.length === 0 && (
                  <ListItem>
                    <ListItemText primary="No featured jobs" />
                  </ListItem>
                )}
              </List>
            </Paper>
          </Grid>

          {/* Right Column */}
          <Grid item xs={12} md={3}>
            {/* JNTUA Alumni Card */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
                bgcolor: 'primary.main',
                color: 'white',
              }}
            >
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
                JNTUA Alumni
              </Typography>
              <Typography variant="body2" sx={{ mb: 2, opacity: 0.9 }}>
                Connect with fellow alumni and stay updated with the latest events and opportunities.
              </Typography>
              <Button
                variant="contained"
                component={RouterLink}
                to="/network"
                sx={{ 
                  bgcolor: 'white',
                  color: 'primary.main',
                  '&:hover': {
                    bgcolor: 'rgba(255, 255, 255, 0.9)',
                  },
                }}
              >
                Join Network
              </Button>
            </Paper>

            {/* Stats Card */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
                Your Network
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6} sm={4}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="primary.main">
                      {networkStats.connections}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Connections
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={4}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="primary.main">
                      {networkStats.pendingConnections}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Pending
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={4}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="primary.main">
                      {networkStats.totalUsers}
                  </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Total Members
                  </Typography>
                </Box>
                </Grid>
                <Grid item xs={6} sm={4}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="primary.main">
                      {networkStats.upcomingEvents}
                  </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Events
                  </Typography>
                </Box>
                </Grid>
                <Grid item xs={6} sm={4}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="primary.main">
                      {networkStats.activeJobs}
                  </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Jobs
                  </Typography>
                </Box>
                </Grid>
                <Grid item xs={6} sm={4}>
                  <Box textAlign="center">
                    <Typography variant="h4" color="primary.main">
                      {networkStats.activeMentorships}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Mentorships
                    </Typography>
              </Box>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default Home; 