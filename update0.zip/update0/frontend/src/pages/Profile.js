import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  Grid,
  Card,
  CardContent,
  Avatar,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Snackbar,
  Alert,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import ShareIcon from '@mui/icons-material/Share';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import EmailIcon from '@mui/icons-material/Email';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import CloseIcon from '@mui/icons-material/Close';

// Initial user data that matches the home page
const initialUserData = {
  name: ' Teja Reddy',
  avatar: '#1a237e',
  email: 'suryateja@gmail.com',
  department: 'CSE',
  batch: '2020',
  designation: 'Software Engineer',
  company: 'Google',
  location: 'Bangalore, India',
  bio: 'Experienced software engineer passionate about building scalable applications and solving complex problems.',
  skills: ['React', 'Node.js', 'Python', 'System Design', 'Cloud Computing'],
  education: [
    {
      degree: 'B.Tech in Computer Science',
      institution: 'JNTUA College of Engineering',
      year: '2016-2020',
      grade: '8.5 CGPA'
    }
  ],
  experience: [
    {
      role: 'Software Engineer',
      company: 'Google',
      duration: '2020 - Present',
      description: 'Working on large-scale distributed systems and cloud infrastructure.'
    },
    {
      role: 'Software Engineering Intern',
      company: 'Microsoft',
      duration: 'Summer 2019',
      description: 'Worked on Azure cloud services and containerization.'
    }
  ],
  socialLinks: {
    linkedin: 'linkedin.com/in/suryateja',
    github: 'https://github.com/suryateja'
  }
};

const Profile = () => {
  const [profile, setProfile] = useState(initialUserData);
  const [editForm, setEditForm] = useState(initialUserData);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [openShareDialog, setOpenShareDialog] = useState(false);
  const [showSnackbar, setShowSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  // Load user data from localStorage when component mounts
  useEffect(() => {
    const savedUserData = localStorage.getItem('userData');
    if (savedUserData) {
      try {
        const parsedData = JSON.parse(savedUserData);
        setProfile(prevProfile => ({
          ...prevProfile,
          ...parsedData
        }));
        setEditForm(prevForm => ({
          ...prevForm,
          ...parsedData
        }));
      } catch (error) {
        console.error('Error parsing user data:', error);
      }
    }
  }, []);

  const handleEditFormChange = (field, value) => {
    setEditForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleEducationChange = (index, field, value) => {
    setEditForm(prev => {
      const newEducation = [...prev.education];
      newEducation[index] = {
        ...newEducation[index],
        [field]: value
      };
      return {
        ...prev,
        education: newEducation
      };
    });
  };

  const handleExperienceChange = (index, field, value) => {
    setEditForm(prev => {
      const newExperience = [...prev.experience];
      newExperience[index] = {
        ...newExperience[index],
        [field]: value
      };
      return {
        ...prev,
        experience: newExperience
      };
    });
  };

  const handleSocialLinksChange = (platform, value) => {
    setEditForm(prev => ({
      ...prev,
      socialLinks: {
        ...prev.socialLinks,
        [platform]: value
      }
    }));
  };

  const handleSkillsChange = (skills) => {
    setEditForm(prev => ({
      ...prev,
      skills: skills
    }));
  };

  const handleEditProfile = () => {
    setProfile(editForm);
    // Save to localStorage
    localStorage.setItem('userData', JSON.stringify(editForm));
    setOpenEditDialog(false);
    setSnackbarMessage('Profile updated successfully!');
    setShowSnackbar(true);
  };

  const handleShareProfile = () => {
    // Generate a shareable link or copy profile data
    navigator.clipboard.writeText(`Check out my JNTUA Alumni profile: ${window.location.href}`);
    setOpenShareDialog(false);
    setSnackbarMessage('Profile link copied to clipboard!');
    setShowSnackbar(true);
  };

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Profile Header */}
        <Card 
          elevation={0}
          sx={{ 
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
            mb: 3,
          }}
        >
          <CardContent sx={{ p: 4 }}>
            <Grid container spacing={3} alignItems="center">
              <Grid item>
                <Avatar 
                  sx={{ 
                    width: 120,
                    height: 120,
                    bgcolor: profile.avatar,
                    fontSize: '3rem'
                  }}
                >
                  {profile.name[0]}
                </Avatar>
              </Grid>
              <Grid item xs>
                <Typography variant="h4" sx={{ fontWeight: 600, mb: 1 }}>
                  {profile.name}
                </Typography>
                <Box sx={{ display: 'flex', gap: 3, color: 'text.secondary', mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <WorkIcon sx={{ fontSize: 20 }} />
                    <Typography>{profile.designation} at {profile.company}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <SchoolIcon sx={{ fontSize: 20 }} />
                    <Typography>{profile.department} • {profile.batch} batch</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <LocationOnIcon sx={{ fontSize: 20 }} />
                    <Typography>{profile.location}</Typography>
                  </Box>
                </Box>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <IconButton 
                    href={profile.socialLinks.linkedin}
                    target="_blank"
                    sx={{ color: '#0077b5' }}
                  >
                    <LinkedInIcon />
                  </IconButton>
                  <IconButton 
                    href={profile.socialLinks.github}
                    target="_blank"
                    sx={{ color: '#333' }}
                  >
                    <GitHubIcon />
                  </IconButton>
                  <IconButton 
                    href={`mailto:${profile.email}`}
                    sx={{ color: '#d32f2f' }}
                  >
                    <EmailIcon />
                  </IconButton>
                </Box>
              </Grid>
              <Grid item>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    variant="outlined"
                    startIcon={<ShareIcon />}
                    onClick={() => setOpenShareDialog(true)}
                    sx={{ borderRadius: 2 }}
                  >
                    Share Profile
                  </Button>
                  <Button
                    variant="contained"
                    startIcon={<EditIcon />}
                    onClick={() => setOpenEditDialog(true)}
                    sx={{
                      bgcolor: '#1a237e',
                      '&:hover': { bgcolor: '#0d1b60' },
                      borderRadius: 2,
                    }}
                  >
                    Edit Profile
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        {/* Profile Content */}
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            {/* About */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  About
                </Typography>
                <Typography color="text.secondary">
                  {profile.bio}
                </Typography>
              </CardContent>
            </Card>

            {/* Experience */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Experience
                </Typography>
                {profile.experience.map((exp, index) => (
                  <Box key={index} sx={{ mb: index !== profile.experience.length - 1 ? 3 : 0 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                      {exp.role}
                    </Typography>
                    <Typography color="text.secondary" gutterBottom>
                      {exp.company} • {exp.duration}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {exp.description}
                    </Typography>
                  </Box>
                ))}
              </CardContent>
            </Card>

            {/* Education */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Education
                </Typography>
                {profile.education.map((edu, index) => (
                  <Box key={index}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                      {edu.degree}
                    </Typography>
                    <Typography color="text.secondary" gutterBottom>
                      {edu.institution} • {edu.year}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Grade: {edu.grade}
                    </Typography>
                  </Box>
                ))}
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={4}>
            {/* Skills */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Skills
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                  {profile.skills.map((skill, index) => (
                    <Chip 
                      key={index}
                      label={skill}
                      sx={{ bgcolor: '#f3e5f5', color: '#7b1fa2' }}
                    />
                  ))}
                </Box>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Contact Information
                </Typography>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <EmailIcon color="action" />
                    <Typography color="text.secondary">{profile.email}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <LocationOnIcon color="action" />
                    <Typography color="text.secondary">{profile.location}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <LinkedInIcon color="action" />
                    <Typography 
                      color="primary"
                      component="a"
                      href={profile.socialLinks.linkedin}
                      target="_blank"
                      sx={{ textDecoration: 'none' }}
                    >
                      LinkedIn Profile
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <GitHubIcon color="action" />
                    <Typography 
                      color="primary"
                      component="a"
                      href={profile.socialLinks.github}
                      target="_blank"
                      sx={{ textDecoration: 'none' }}
                    >
                      GitHub Profile
                    </Typography>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Edit Profile Dialog */}
        <Dialog 
          open={openEditDialog} 
          onClose={() => setOpenEditDialog(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Edit Profile
              <IconButton onClick={() => setOpenEditDialog(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Full Name"
                  value={editForm.name}
                  onChange={(e) => handleEditFormChange('name', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  value={editForm.email}
                  onChange={(e) => handleEditFormChange('email', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Department"
                  value={editForm.department}
                  onChange={(e) => handleEditFormChange('department', e.target.value)}
                >
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Batch"
                  value={editForm.batch}
                  onChange={(e) => handleEditFormChange('batch', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Bio"
                  value={editForm.bio}
                  onChange={(e) => handleEditFormChange('bio', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Company"
                  value={editForm.company}
                  onChange={(e) => handleEditFormChange('company', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Location"
                  value={editForm.location}
                  onChange={(e) => handleEditFormChange('location', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="LinkedIn Profile"
                  value={editForm.socialLinks.linkedin}
                  onChange={(e) => handleSocialLinksChange('linkedin', e.target.value)}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={() => setOpenEditDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handleEditProfile}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Save Changes
            </Button>
          </DialogActions>
        </Dialog>

        {/* Share Profile Dialog */}
        <Dialog 
          open={openShareDialog} 
          onClose={() => setOpenShareDialog(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Share Profile
              <IconButton onClick={() => setOpenShareDialog(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Typography gutterBottom>
              Share your profile with other alumni and professionals.
            </Typography>
            <TextField
              fullWidth
              value={window.location.href}
              InputProps={{
                readOnly: true,
              }}
              sx={{ mt: 2 }}
            />
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={() => setOpenShareDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handleShareProfile}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Copy Link
            </Button>
          </DialogActions>
        </Dialog>

        {/* Snackbar for notifications */}
        <Snackbar
          open={showSnackbar}
          autoHideDuration={4000}
          onClose={() => setShowSnackbar(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setShowSnackbar(false)} 
            severity="success"
            sx={{ width: '100%' }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Container>
    </Box>
  );
};

export default Profile; 