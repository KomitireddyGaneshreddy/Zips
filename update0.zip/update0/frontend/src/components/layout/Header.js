import React from 'react';
import { Box, Container, Typography, useTheme } from '@mui/material';
import { styled } from '@mui/material/styles';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';

const HeaderWrapper = styled(Box)(({ theme }) => ({
  background: '#fff',
  borderBottom: '1px solid',
  borderColor: theme.palette.divider,
  padding: theme.spacing(1.5, 0),
}));

const ContactInfo = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(4),
  color: theme.palette.text.secondary,
  [theme.breakpoints.down('md')]: {
    gap: theme.spacing(2),
  },
  [theme.breakpoints.down('sm')]: {
    display: 'none',
  },
}));

const ContactItem = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
  fontSize: '0.875rem',
  transition: 'color 0.2s ease',
  '& svg': {
    fontSize: '1rem',
    color: theme.palette.primary.main,
  },
  '&:hover': {
    color: theme.palette.primary.main,
  },
}));

const LogoImage = styled('img')({
  width: '100%',
  height: '100%',
  objectFit: 'contain',
});

const Header = () => {
  const theme = useTheme();

  return (
    <HeaderWrapper>
      <Container maxWidth="xl">
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          {/* Left: Logo and College Name */}
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center',
            gap: 2.5,
          }}>
            <Box sx={{ 
              width: { xs: 55, sm: 65, md: 75 },
              height: { xs: 55, sm: 65, md: 75 },
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              bgcolor: 'white',
              borderRadius: '50%',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              overflow: 'hidden',
              padding: '8px',
            }}>
              <LogoImage
                src="/jntua-logo.png"
                alt="JNTUA Logo"
                onError={(e) => {
                  e.target.src = 'https://www.jntuacep.ac.in/images/logo.png';
                }}
              />
            </Box>
            <Box sx={{ 
              display: { xs: 'none', sm: 'block' },
            }}>
              <Typography
                variant="h6"
                sx={{
                  color: theme.palette.text.primary,
                  fontWeight: 600,
                  fontSize: { sm: '1rem', md: '1.1rem' },
                  letterSpacing: '0.5px',
                  lineHeight: 1.2,
                }}
              >
                JAWAHARLAL NEHRU
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  color: theme.palette.text.secondary,
                  fontSize: { sm: '0.75rem', md: '0.8rem' },
                  letterSpacing: '0.5px',
                  textTransform: 'uppercase',
                  marginTop: '2px',
                }}
              >
                Technological University Anantapur
              </Typography>
            </Box>
          </Box>

          {/* Right: Contact Information */}
          <ContactInfo>
            <ContactItem component="a" href="mailto:contact@jntua.ac.in">
              <EmailIcon />
              <span>alumni@jntua.ac.in</span>
            </ContactItem>
            <ContactItem component="a" href="tel:+919876543210">
              <PhoneIcon />
              <span>+91 987-654-3210</span>
            </ContactItem>
            <ContactItem>
              <LocationOnIcon />
              <span>Pulivendula, AP</span>
            </ContactItem>
          </ContactInfo>
        </Box>
      </Container>
    </HeaderWrapper>
  );
};

export default Header; 