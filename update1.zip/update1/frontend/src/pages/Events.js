import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
  Chip,
  MenuItem,
  Avatar,
  Paper,
  DialogContentText,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import EventIcon from '@mui/icons-material/Event';
import CloseIcon from '@mui/icons-material/Close';
import GroupIcon from '@mui/icons-material/Group';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { formatDistanceToNow } from 'date-fns';
import { eventService } from '../services/api';
import { useAuth } from '../context/AuthContext';

const Events = () => {
  const { user } = useAuth();
  const [openPostEvent, setOpenPostEvent] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
    type: 'In-Person',
    registration_link: '',
    max_attendees: '',
    department: 'All',
  });

  const [eventsList, setEventsList] = useState([]);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        setLoading(true);
        const events = await eventService.getAllEvents();
        console.log('Fetched events:', events);
        // Transform backend data to match the UI structure
        const transformedEvents = events.map(event => ({
          id: event.id,
          title: event.title,
          description: event.description,
          date: event.date,
          time: event.time,
          location: event.location,
          type: event.type,
          registrationLink: event.registration_link,
          maxAttendees: event.max_attendees,
          department: event.department,
          postedBy: {
            name: `${event.first_name} ${event.last_name}`,
            // Separate role field instead of using designation
            role: event.role || 'Alumni',
            degree: event.degree || 'Not specified',
            batch: event.batch || 'Not specified',
            avatar: '#1a237e',
          },
          postedAt: new Date(event.created_at),
        }));
        console.log('Transformed events:', transformedEvents);
        setEventsList(transformedEvents);
      } catch (error) {
        console.error('Error fetching events:', error);
        setError('Failed to load events. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  const handlePostEvent = async () => {
    try {
      // Format the time to include seconds
      const formattedTime = eventForm.time ? `${eventForm.time}:00` : '10:00:00';
      
      const eventData = {
        title: eventForm.title,
        description: eventForm.description,
        date: eventForm.date,
        time: formattedTime,
        location: eventForm.location,
        type: eventForm.type,
        registration_link: eventForm.registration_link || null,
        max_attendees: eventForm.max_attendees ? parseInt(eventForm.max_attendees) : null,
        department: eventForm.department
      };

      console.log('Submitting event data:', eventData);
      const newEvent = await eventService.postEvent(eventData);
      console.log('Posted new event:', newEvent);
      
      // Transform the new event to match UI structure
      const transformedEvent = {
        id: newEvent.eventId,
        title: eventForm.title,
        description: eventForm.description,
        date: eventForm.date,
        time: formattedTime,
        location: eventForm.location,
        type: eventForm.type,
        registrationLink: eventForm.registration_link,
        maxAttendees: eventForm.max_attendees,
        department: eventForm.department,
        postedBy: {
          name: `${user.first_name} ${user.last_name}`,
          avatar: '#1a237e',
          role: user.role || 'Alumni',
          degree: user.degree || 'Not specified',
          batch: user.batch || 'Not specified',
        },
        postedAt: new Date(),
      };
      
      setEventsList([transformedEvent, ...eventsList]);
      setOpenPostEvent(false);
      setEventForm({
        title: '',
        description: '',
        date: '',
        time: '',
        location: '',
        type: 'In-Person',
        registration_link: '',
        max_attendees: '',
        department: 'All',
      });
    } catch (error) {
      console.error('Error posting event:', error);
      if (error.response?.data?.message) {
        setError(error.response.data.message);
      } else {
        setError('Failed to post event. Please try again later.');
      }
    }
  };

  const filteredEvents = eventsList.filter(event =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography>Loading events...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 1 }}>
              Events
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Discover and organize alumni events and gatherings
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setOpenPostEvent(true)}
            sx={{
              bgcolor: '#1a237e',
              '&:hover': { bgcolor: '#0d1b60' },
              px: 3,
              py: 1.5,
              borderRadius: 2,
            }}
          >
            Post Event
          </Button>
        </Box>

        {/* Search */}
        <Paper 
          elevation={0}
          sx={{ 
            p: 3,
            mb: 4,
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <TextField
            fullWidth
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search events by title, description, or location..."
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon color="action" />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'white',
              },
            }}
          />
        </Paper>

        {/* Events List */}
        <Grid container spacing={3}>
          {filteredEvents.map((event) => (
            <Grid item xs={12} key={event.id}>
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': {
                    borderColor: 'primary.main',
                    boxShadow: 1,
                  },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={8}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                        <Avatar 
                          sx={{ 
                            width: 48,
                            height: 48,
                            bgcolor: event.postedBy.avatar,
                            fontSize: '1.5rem'
                          }}
                        >
                          {event.postedBy.name[0]}
                        </Avatar>
                        <Box>
                          <Typography
                            variant="h6"
                            sx={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 1 }}
                          >
                            {event.title}
                            <Chip
                              label={event.type}
                              size="small"
                              sx={{ bgcolor: '#e3f2fd', color: '#1976d2' }}
                            />
                          </Typography>
                          <Typography color="text.secondary">
                            Posted by {event.postedBy.name} • Role: {event.postedBy.role} • Degree: {event.postedBy.degree} • Batch: {event.postedBy.batch}
                          </Typography>
                        </Box>
                      </Box>
                      <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <EventIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            Event: {new Date(event.date).toLocaleDateString()} at {event.time}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <LocationOnIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            {event.location}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <GroupIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            Max {event.maxAttendees} attendees
                          </Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        {event.description}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        <Chip 
                          label={event.department}
                          size="small"
                          sx={{ bgcolor: '#f3e5f5', color: '#7b1fa2' }}
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, height: '100%', justifyContent: 'center' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: 'text.secondary' }}>
                          <AccessTimeIcon sx={{ fontSize: 20 }} />
                          <Typography variant="body2">
                            Posted {formatDistanceToNow(event.postedAt, { addSuffix: true })}
                          </Typography>
                        </Box>
                        <Button
                          variant="contained"
                          fullWidth
                          href={event.registrationLink}
                          target="_blank"
                          sx={{
                            bgcolor: '#1a237e',
                            '&:hover': { bgcolor: '#0d1b60' },
                          }}
                        >
                          Register Now
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Post Event Dialog */}
        <Dialog 
          open={openPostEvent} 
          onClose={() => setOpenPostEvent(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Post an Event
              <IconButton onClick={() => setOpenPostEvent(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Event Title"
                  value={eventForm.title}
                  onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  type="date"
                  label="Date"
                  value={eventForm.date}
                  onChange={(e) => setEventForm({ ...eventForm, date: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  type="time"
                  label="Time"
                  value={eventForm.time}
                  onChange={(e) => setEventForm({ ...eventForm, time: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Location"
                  value={eventForm.location}
                  onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Event Type"
                  value={eventForm.type}
                  onChange={(e) => setEventForm({ ...eventForm, type: e.target.value })}
                >
                  <MenuItem value="In-Person">In-Person</MenuItem>
                  <MenuItem value="Virtual">Virtual</MenuItem>
                  <MenuItem value="Hybrid">Hybrid</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Department"
                  value={eventForm.department}
                  onChange={(e) => setEventForm({ ...eventForm, department: e.target.value })}
                >
                  <MenuItem value="All">All Departments</MenuItem>
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Registration Link"
                  value={eventForm.registration_link}
                  onChange={(e) => setEventForm({ ...eventForm, registration_link: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  type="number"
                  label="Maximum Attendees"
                  value={eventForm.max_attendees}
                  onChange={(e) => setEventForm({ ...eventForm, max_attendees: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Event Description"
                  value={eventForm.description}
                  onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={() => setOpenPostEvent(false)}>
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handlePostEvent}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Post Event
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

export default Events;
