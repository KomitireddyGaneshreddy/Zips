import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
  Chip,
  MenuItem,
  Avatar,
  Paper,
  DialogContentText,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import EventIcon from '@mui/icons-material/Event';
import CloseIcon from '@mui/icons-material/Close';
import GroupIcon from '@mui/icons-material/Group';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { formatDistanceToNow } from 'date-fns';
import { mentorshipService } from '../services/api';
import { useAuth } from '../context/AuthContext';

const Mentorship = () => {
  const { user } = useAuth();
  const [openPostMentorship, setOpenPostMentorship] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [mentorshipForm, setMentorshipForm] = useState({
    title: '',
    description: '',
    expertise: '',
    experience: '',
    availability: '',
    department: 'All',
    type: 'Career Guidance',
    expectations: '',
    contactEmail: '',
  });

  const [mentorshipsList, setMentorshipsList] = useState([]);

  useEffect(() => {
    const fetchMentorships = async () => {
      try {
        setLoading(true);
        const mentorships = await mentorshipService.getAllMentorships();
        console.log('Fetched mentorships:', mentorships);
        // Transform backend data to match the UI structure
        const transformedMentorships = mentorships.map(mentorship => ({
          id: mentorship.id,
          title: mentorship.title,
          description: mentorship.description,
          expertise: mentorship.expertise,
          experience: mentorship.experience,
          availability: mentorship.availability,
          department: mentorship.department,
          type: mentorship.type,
          expectations: mentorship.expectations,
          contactEmail: mentorship.contact_email,
          postedBy: {
            name: `${mentorship.first_name} ${mentorship.last_name}`,
            avatar: '#1a237e',
            designation: mentorship.role || 'Alumni',
            degree: mentorship.degree || 'Not specified',
            batch: mentorship.batch || 'Not specified',
          },
          postedAt: new Date(mentorship.created_at),
        }));
        console.log('Transformed mentorships:', transformedMentorships);
        setMentorshipsList(transformedMentorships);
      } catch (error) {
        console.error('Error fetching mentorships:', error);
        setError('Failed to load mentorships. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchMentorships();
  }, []);

  const handlePostMentorship = async () => {
    try {
      // Transform form data to match backend structure
      const mentorshipData = {
        title: mentorshipForm.title,
        description: mentorshipForm.description,
        expertise: mentorshipForm.expertise,
        experience: mentorshipForm.experience,
        availability: mentorshipForm.availability,
        department: mentorshipForm.department,
        type: mentorshipForm.type,
        expectations: mentorshipForm.expectations,
        contact_email: mentorshipForm.contactEmail,
      };

      const newMentorship = await mentorshipService.postMentorship(mentorshipData);
      console.log('Posted new mentorship:', newMentorship);
      
      // Transform the new mentorship to match UI structure
      const transformedMentorship = {
        id: newMentorship.id,
        ...mentorshipForm,
        postedBy: {
          name: `${user.first_name} ${user.last_name}`,
          avatar: '#1a237e',
          designation: user.role || 'Alumni',
          degree: user.degree || 'Not specified',
          batch: user.batch || 'Not specified',
        },
        postedAt: new Date(),
      };
      
      setMentorshipsList([transformedMentorship, ...mentorshipsList]);
      setOpenPostMentorship(false);
      setMentorshipForm({
        title: '',
        description: '',
        expertise: '',
        experience: '',
        availability: '',
        department: 'All',
        type: 'Career Guidance',
        expectations: '',
        contactEmail: '',
      });
    } catch (error) {
      console.error('Error posting mentorship:', error);
      setError('Failed to post mentorship. Please try again later.');
    }
  };

  const filteredMentorships = mentorshipsList.filter(mentorship =>
    mentorship.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mentorship.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    mentorship.expertise.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography>Loading mentorships...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 1 }}>
              Mentorship
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Connect with experienced alumni for guidance and mentorship
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setOpenPostMentorship(true)}
            sx={{
              bgcolor: '#1a237e',
              '&:hover': { bgcolor: '#0d1b60' },
              px: 3,
              py: 1.5,
              borderRadius: 2,
            }}
          >
            Offer Mentorship
          </Button>
        </Box>

        {/* Search */}
        <Paper 
          elevation={0}
          sx={{ 
            p: 3,
            mb: 4,
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <TextField
            fullWidth
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search mentorships by title, description, or expertise..."
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon color="action" />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: 'white',
              },
            }}
          />
        </Paper>

        {/* Mentorships List */}
        <Grid container spacing={3}>
          {filteredMentorships.map((mentorship) => (
            <Grid item xs={12} key={mentorship.id}>
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': {
                    borderColor: 'primary.main',
                    boxShadow: 1,
                  },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={8}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                        <Avatar 
                          sx={{ 
                            width: 48,
                            height: 48,
                            bgcolor: mentorship.postedBy.avatar,
                            fontSize: '1.5rem'
                          }}
                        >
                          {mentorship.postedBy.name[0]}
                        </Avatar>
                        <Box>
                          <Typography variant="h6" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 1 }}>
                            {mentorship.title}
                          </Typography>
                          <Typography color="text.secondary">
                            Posted by {mentorship.postedBy.name} • {mentorship.postedBy.designation} • {mentorship.postedBy.degree} • {mentorship.postedBy.batch} batch
                          </Typography>
                        </Box>
                      </Box>
                      <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <GroupIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            {mentorship.experience} experience
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <LocationOnIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            {mentorship.availability}
                          </Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        {mentorship.description}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
                        <Chip 
                          label={mentorship.type}
                          size="small"
                          sx={{ 
                            bgcolor: '#e8f5e9',
                            color: '#2e7d32',
                            '&:hover': {
                              bgcolor: '#c8e6c9',
                            },
                            borderRadius: 1,
                            height: 24,
                            '& .MuiChip-label': {
                              px: 1.5,
                            }
                          }}
                        />
                        <Chip 
                          label={mentorship.department}
                          size="small"
                          sx={{ 
                            bgcolor: '#f3e5f5',
                            color: '#7b1fa2',
                            '&:hover': {
                              bgcolor: '#e1bee7',
                            },
                            borderRadius: 1,
                            height: 24,
                            '& .MuiChip-label': {
                              px: 1.5,
                            }
                          }}
                        />
                      </Box>
                      <Box sx={{ mb: 2 }}>
                        <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.primary', fontWeight: 600 }}>
                          Areas of Expertise:
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                          {mentorship.expertise.split(',').map((skill, index) => (
                            <Chip 
                              key={index}
                              label={skill.trim()}
                              size="small"
                              sx={{ 
                                bgcolor: '#e3f2fd',
                                color: '#1976d2',
                                '&:hover': {
                                  bgcolor: '#bbdefb',
                                },
                                borderRadius: 1,
                                height: 24,
                                '& .MuiChip-label': {
                                  px: 1.5,
                                }
                              }}
                            />
                          ))}
                        </Box>
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, height: '100%', justifyContent: 'center' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: 'text.secondary' }}>
                          <AccessTimeIcon sx={{ fontSize: 20 }} />
                          <Typography variant="body2">
                            Posted {formatDistanceToNow(mentorship.postedAt, { addSuffix: true })}
                          </Typography>
                        </Box>
                        <Button
                          variant="contained"
                          fullWidth
                          href={`mailto:${mentorship.contactEmail}`}
                          sx={{
                            bgcolor: '#1a237e',
                            '&:hover': { bgcolor: '#0d1b60' },
                          }}
                        >
                          Contact Mentor
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Post Mentorship Dialog */}
        <Dialog 
          open={openPostMentorship} 
          onClose={() => setOpenPostMentorship(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Offer Mentorship
              <IconButton onClick={() => setOpenPostMentorship(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Title"
                  value={mentorshipForm.title}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, title: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Description"
                  value={mentorshipForm.description}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, description: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Expertise"
                  value={mentorshipForm.expertise}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, expertise: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Experience"
                  value={mentorshipForm.experience}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, experience: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Availability"
                  value={mentorshipForm.availability}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, availability: e.target.value })}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Department"
                  value={mentorshipForm.department}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, department: e.target.value })}
                >
                  <MenuItem value="All">All Departments</MenuItem>
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Mentorship Type"
                  value={mentorshipForm.type}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, type: e.target.value })}
                >
                  <MenuItem value="Career Guidance">Career Guidance</MenuItem>
                  <MenuItem value="Technical Mentoring">Technical Mentoring</MenuItem>
                  <MenuItem value="Leadership Development">Leadership Development</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Expectations"
                  value={mentorshipForm.expectations}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, expectations: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Contact Email"
                  value={mentorshipForm.contactEmail}
                  onChange={(e) => setMentorshipForm({ ...mentorshipForm, contactEmail: e.target.value })}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={() => setOpenPostMentorship(false)}>
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handlePostMentorship}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Post Mentorship
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

export default Mentorship; 