import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Typography,
  Snackbar,
  Alert,
  Tabs,
  Tab,
  Chip
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { format } from 'date-fns';
import { jobService } from '../../services/api';

const JobManagement = () => {
  const [jobs, setJobs] = useState([]);
  const [tabValue, setTabValue] = useState(0);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const data = await jobService.getAllJobs();
      setJobs(data);
    } catch (error) {
      console.error('Error fetching jobs:', error);
      setSnackbar({
        open: true,
        message: 'Error fetching jobs',
        severity: 'error'
      });
    }
  };

  const handleDeleteJob = async (jobId) => {
    try {
      await jobService.deleteJob(jobId);
      setSnackbar({
        open: true,
        message: 'Job deleted successfully',
        severity: 'success'
      });
      fetchJobs();
    } catch (error) {
      console.error('Error deleting job:', error);
      setSnackbar({
        open: true,
        message: 'Error deleting job',
        severity: 'error'
      });
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const filterJobsByStatus = (jobs) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Set to start of day for accurate comparison

    switch (tabValue) {
      case 1: // Active
        return jobs.filter(job => {
          const deadline = job.deadline ? new Date(job.deadline) : null;
          return deadline && deadline >= today;
        });
      case 2: // Deadline Over
        return jobs.filter(job => {
          const deadline = job.deadline ? new Date(job.deadline) : null;
          return deadline && deadline < today;
        });
      default: // All Jobs
        return jobs;
    }
  };

  const filteredJobs = filterJobsByStatus(jobs);

  const getStatusColor = (status) => {
    if (!status) return '#6b7280'; // Default color for undefined status
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const deadline = status ? new Date(status) : null;
    
    if (deadline) {
      return deadline >= today ? '#22c55e' : '#ef4444';
    }
    
    return '#6b7280';
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ color: '#1e40af', fontWeight: 600, mb: 3 }}>
        Job Management
      </Typography>

      <Box sx={{ mb: 4 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange}
          sx={{
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 500,
            },
          }}
        >
          <Tab label="All Jobs" />
          <Tab label="Active" />
          <Tab label="Deadline Over" />
        </Tabs>
      </Box>

      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" sx={{ mb: 1 }}>Jobs</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Manage job postings, track applications, and connect alumni with opportunities.
        </Typography>

        <TableContainer component={Paper} sx={{ borderRadius: 2 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Job Title</TableCell>
                <TableCell>Company</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Applications</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Posted</TableCell>
                <TableCell>Posted by</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredJobs.map((job) => (
                <TableRow key={job.id}>
                  <TableCell>
                    <Box>
                      <Typography variant="subtitle2" sx={{ color: '#3b82f6', fontWeight: 500 }}>
                        {job.title}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {job.location}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>{job.company}</TableCell>
                  <TableCell>
                    <Chip 
                      label={job.type}
                      size="small"
                      sx={{
                        bgcolor: 'rgba(59, 130, 246, 0.1)',
                        color: '#3b82f6',
                        fontWeight: 500
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {job.applications_count || 0} applicants
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={job.deadline ? 
                        (new Date(job.deadline) >= new Date() ? 'Active' : 'Deadline Over')
                        : 'No Deadline'}
                      size="small"
                      sx={{
                        bgcolor: `${getStatusColor(job.deadline)}20`,
                        color: getStatusColor(job.deadline),
                        fontWeight: 500
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    {job.created_at ? format(new Date(job.created_at), 'MMM dd, yyyy') : 'N/A'}
                  </TableCell>
                  <TableCell>
                    {job.first_name && job.last_name ? `${job.first_name} ${job.last_name}` : 'N/A'}
                  </TableCell>
                  <TableCell align="center">
                    <IconButton
                      color="error"
                      onClick={() => handleDeleteJob(job.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default JobManagement; 