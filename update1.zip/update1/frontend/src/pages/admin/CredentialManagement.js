import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  IconButton,
  Chip,
  Tabs,
  Tab,
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon } from '@mui/icons-material';
import { authService } from '../../services/api';

const CredentialManagement = () => {
  const [credentials, setCredentials] = useState([]);
  const [existingCredentials, setExistingCredentials] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [newCredential, setNewCredential] = useState({
    roll_number: '',
    unique_key: ''
  });
  const [editingCredential, setEditingCredential] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    try {
      setLoading(true);
      const [credentialsData, existingData] = await Promise.all([
        authService.getAllCredentials(),
        authService.getExistingCredentials()
      ]);
      setCredentials(credentialsData);
      setExistingCredentials(existingData);
      setError(null);
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleOpenDialog = () => {
    setOpenDialog(true);
    setNewCredential({ roll_number: '', unique_key: '' });
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setNewCredential({ roll_number: '', unique_key: '' });
  };

  const handleOpenEditDialog = (credential) => {
    setEditingCredential(credential);
    setOpenEditDialog(true);
  };

  const handleCloseEditDialog = () => {
    setOpenEditDialog(false);
    setEditingCredential(null);
  };

  const handleCreateCredential = async () => {
    try {
      await authService.createUserCredential(newCredential);
      await fetchAllData();
      handleCloseDialog();
      setError(null);
    } catch (error) {
      console.error('Error creating credential:', error);
      setError(error.response?.data?.message || 'Failed to create credential');
    }
  };

  const handleUpdateCredential = async () => {
    try {
      await authService.updateCredential(editingCredential.id, {
        unique_key: editingCredential.unique_key
      });
      await fetchAllData();
      handleCloseEditDialog();
      setError(null);
    } catch (error) {
      console.error('Error updating credential:', error);
      setError(error.response?.data?.message || 'Failed to update credential');
    }
  };

  const handleDeleteCredential = async (id) => {
    try {
      await authService.deleteCredential(id);
      await fetchAllData();
      setError(null);
    } catch (error) {
      console.error('Error deleting credential:', error);
      setError(error.response?.data?.message || 'Failed to delete credential');
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5" component="h1">
          User Credentials Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleOpenDialog}
        >
          Add Credential
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Tabs value={activeTab} onChange={handleTabChange} sx={{ mb: 3 }}>
        <Tab label="Available Credentials" />
        <Tab label="Existing Users" />
      </Tabs>

      {activeTab === 0 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Roll Number</TableCell>
                <TableCell>Unique Key</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Created At</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {credentials.map((credential) => (
                <TableRow key={credential.id}>
                  <TableCell>{credential.roll_number}</TableCell>
                  <TableCell>{credential.unique_key}</TableCell>
                  <TableCell>
                    <Chip
                      label={credential.status === 'used' ? 'Used' : 'Available'}
                      color={credential.status === 'used' ? 'error' : 'success'}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    {new Date(credential.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell align="right">
                    {credential.status === 'available' && (
                      <IconButton
                        onClick={() => handleOpenEditDialog(credential)}
                        color="primary"
                      >
                        <EditIcon />
                      </IconButton>
                    )}
                    <IconButton
                      onClick={() => handleDeleteCredential(credential.id)}
                      disabled={credential.status === 'used'}
                      color="error"
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 1 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Roll Number</TableCell>
                <TableCell>Unique Key</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {existingCredentials.map((credential, index) => (
                <TableRow key={index}>
                  <TableCell>{credential.roll_number}</TableCell>
                  <TableCell>{credential.unique_key}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>Add New Credential</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Roll Number"
            type="text"
            fullWidth
            value={newCredential.roll_number}
            onChange={(e) => setNewCredential({ ...newCredential, roll_number: e.target.value })}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Unique Key"
            type="text"
            fullWidth
            value={newCredential.unique_key}
            onChange={(e) => setNewCredential({ ...newCredential, unique_key: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleCreateCredential} variant="contained">
            Create
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={openEditDialog} onClose={handleCloseEditDialog}>
        <DialogTitle>Edit Credential</DialogTitle>
        <DialogContent>
          <TextField
            margin="dense"
            label="Roll Number"
            type="text"
            fullWidth
            value={editingCredential?.roll_number || ''}
            disabled
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Unique Key"
            type="text"
            fullWidth
            value={editingCredential?.unique_key || ''}
            onChange={(e) => setEditingCredential({ ...editingCredential, unique_key: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseEditDialog}>Cancel</Button>
          <Button onClick={handleUpdateCredential} variant="contained">
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default CredentialManagement; 