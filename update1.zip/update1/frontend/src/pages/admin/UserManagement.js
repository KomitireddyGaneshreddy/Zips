import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Tabs,
  Tab,
  IconButton,
  Paper,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Avatar,
  Chip,
  Menu,
  MenuItem,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Select,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  Search as SearchIcon,
  FilterList as FilterIcon,
  FileDownload as ExportIcon,
  Add as AddIcon,
  MoreVert as MoreVertIcon,
  Key as KeyIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { authService } from '../../services/api';

const DEPARTMENTS = ['All', 'CSE', 'ECE', 'EEE', 'MECH', 'CIVIL'];
const YEARS = ['All', '2020', '2021', '2022', '2023', '2024'];

const UserManagement = () => {
  const navigate = useNavigate();
  const [selectedTab, setSelectedTab] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openKeyDialog, setOpenKeyDialog] = useState(false);
  const [newUniqueKey, setNewUniqueKey] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('All');
  const [selectedYear, setSelectedYear] = useState('All');

  // Fetch users on component mount
  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await authService.getAllUsers();
      console.log('Fetched users:', data);
      setUsers(data);
    } catch (error) {
      console.error('Error fetching users:', error);
      setError(error.message || 'Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  const handleMenuOpen = (event, user) => {
    setAnchorEl(event.currentTarget);
    setSelectedUser(user);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedUser(null);
  };

  const handleAddUser = () => {
    navigate('/register');
  };

  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    
    try {
      setLoading(true);
      await authService.deleteUser(selectedUser.id);
      setUsers(prevUsers => prevUsers.filter(user => user.id !== selectedUser.id));
      handleMenuClose();
      setError(null);
    } catch (error) {
      console.error('Error deleting user:', error);
      setError(error.response?.data?.message || 'Failed to delete user');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenKeyDialog = () => {
    setNewUniqueKey(selectedUser?.unique_key || '');
    setOpenKeyDialog(true);
    handleMenuClose();
  };

  const handleCloseKeyDialog = () => {
    setOpenKeyDialog(false);
    setNewUniqueKey('');
  };

  const handleUpdateUniqueKey = async () => {
    if (!selectedUser || !newUniqueKey) return;

    try {
      await authService.updateUniqueKey(selectedUser.id, newUniqueKey);
      // Update the user in the local state
      setUsers(users.map(user => 
        user.id === selectedUser.id 
          ? { ...user, unique_key: newUniqueKey }
          : user
      ));
      handleCloseKeyDialog();
    } catch (error) {
      console.error('Error updating unique key:', error);
      setError('Failed to update unique key');
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = (
      user.first_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const matchesRole = selectedTab === 0 || 
      (selectedTab === 1 && user.role === 'alumni') ||
      (selectedTab === 2 && user.role === 'student') ||
      (selectedTab === 3 && user.role === 'employer');

    const matchesDepartment = selectedDepartment === 'All' || 
      user.department?.toUpperCase() === selectedDepartment.toUpperCase();

    const matchesYear = selectedYear === 'All' || 
      (user.year && user.year.split('-')[1] === selectedYear);

    return matchesSearch && matchesRole && matchesDepartment && matchesYear;
  });

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ color: 'primary.main', mb: 3 }}>
        User Management
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Box sx={{ bgcolor: 'background.paper', borderRadius: 1, mb: 3 }}>
        <Box sx={{ p: 3 }}>
          <Typography variant="h5" sx={{ mb: 2 }}>
            Users
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Manage user accounts, view profiles, and monitor activity.
          </Typography>

          <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
            <TextField
              placeholder="Search users..."
              variant="outlined"
              size="small"
              fullWidth
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button
              startIcon={<AddIcon />}
              variant="contained"
              onClick={handleAddUser}
              sx={{ minWidth: 120 }}
            >
              Add User
            </Button>
          </Box>

          <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel>Department</InputLabel>
              <Select
                value={selectedDepartment}
                label="Department"
                onChange={(e) => setSelectedDepartment(e.target.value)}
              >
                {DEPARTMENTS.map((dept) => (
                  <MenuItem key={dept} value={dept}>{dept}</MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel>Graduation Year</InputLabel>
              <Select
                value={selectedYear}
                label="Graduation Year"
                onChange={(e) => setSelectedYear(e.target.value)}
              >
                {YEARS.map((year) => (
                  <MenuItem key={year} value={year}>{year}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>

          <Tabs value={selectedTab} onChange={handleTabChange} sx={{ mb: 2 }}>
            <Tab label="All Users" />
            <Tab label="Alumni" />
            <Tab label="Students" />
            <Tab label="Employers" />
          </Tabs>

          <TableContainer component={Paper} variant="outlined">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Role</TableCell>
                  <TableCell>Unique ID</TableCell>
                  <TableCell>Department</TableCell>
                  <TableCell>Graduation Year</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} align="center" sx={{ py: 3 }}>
                      <CircularProgress />
                    </TableCell>
                  </TableRow>
                ) : filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} align="center" sx={{ py: 3 }}>
                      No users found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                          <Avatar>{user.first_name?.[0] || 'U'}</Avatar>
                          <Box>
                            <Typography variant="subtitle2">
                              {`${user.first_name || ''} ${user.last_name || ''}`}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {user.email}
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={user.role || 'User'}
                          size="small"
                          sx={{
                            bgcolor: 'primary.main',
                            color: 'white',
                            textTransform: 'capitalize'
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <KeyIcon fontSize="small" color="action" />
                          <Typography variant="body2">
                            {user.unique_key ? user.unique_key : 'Not Set'}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>{user.department || 'N/A'}</TableCell>
                      <TableCell>
                        {user.year ? user.year.split('-')[1] || user.year : 'N/A'}
                      </TableCell>
                      <TableCell align="right">
                        <IconButton
                          size="small"
                          onClick={(e) => handleMenuOpen(e, user)}
                        >
                          <MoreVertIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Box>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={() => {
          navigate(`/profile/${selectedUser?.id}`);
          handleMenuClose();
        }}>
          View Profile
        </MenuItem>
        <MenuItem 
          onClick={handleDeleteUser}
          sx={{ color: 'error.main' }}
        >
          Delete User
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default UserManagement; 