import React from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Paper,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Avatar,
  Tab,
  Tabs,
  IconButton,
} from '@mui/material';
import {
  People as PeopleIcon,
  Work as WorkIcon,
  Event as EventIcon,
  Group as GroupIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  MoreHoriz as MoreHorizIcon,
} from '@mui/icons-material';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const AdminDashboard = () => {
  const [tabValue, setTabValue] = React.useState(0);

  // Chart data
  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'User Growth',
        data: [350, 275, 400, 250, 500, 400, 450, 550, 650, 700, 800, 850],
        fill: false,
        borderColor: 'rgb(37, 99, 235)',
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 1000,
        ticks: {
          stepSize: 250,
        },
      },
    },
  };

  // Stats data
  const stats = [
    { title: 'Total Users', value: '2,543', change: '+12.5%', icon: <PeopleIcon /> },
    { title: 'Job Postings', value: '145', change: '+4.3%', icon: <WorkIcon /> },
    { title: 'Events', value: '38', change: '-2.5%', icon: <EventIcon /> },
    { title: 'Mentorships', value: '87', change: '+8.2%', icon: <GroupIcon /> },
  ];

  // Recent activity data
  const recentActivity = [
    { name: 'New Users', action: '15 new users registered', time: 'Last 24 hours', avatar: 'U' },
    { name: 'Job Postings', action: '8 new jobs posted', time: 'Last 24 hours', avatar: 'J' },
    { name: 'Events', action: '3 new events created', time: 'Last 24 hours', avatar: 'E' },
    { name: 'Mentorships', action: '5 new mentorship requests', time: 'Last 24 hours', avatar: 'M' },
  ];

  return (
    <Box sx={{ bgcolor: '#f8fafc', minHeight: '100vh', py: 3 }}>
      <Container maxWidth="xl">
        {/* Header */}
        <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h4" sx={{ fontWeight: 600 }}>
            Dashboard
          </Typography>
          <Tabs value={tabValue} onChange={(e, newValue) => setTabValue(newValue)}>
            <Tab label="Overview" />
            <Tab label="Analytics" />
            <Tab label="Reports" />
          </Tabs>
        </Box>

        {/* Stats Grid */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          {stats.map((stat, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Paper
                sx={{
                  p: 3,
                  display: 'flex',
                  flexDirection: 'column',
                  borderRadius: 2,
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                  <Box sx={{ color: 'primary.main' }}>{stat.icon}</Box>
                  <IconButton size="small">
                    <MoreHorizIcon />
                  </IconButton>
                </Box>
                <Typography variant="h4" sx={{ mb: 1, fontWeight: 600 }}>
                  {stat.value}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Typography variant="body2" color="text.secondary">
                    {stat.title}
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      ml: 1,
                      color: stat.change.startsWith('+') ? 'success.main' : 'error.main',
                      display: 'flex',
                      alignItems: 'center',
                    }}
                  >
                    {stat.change}
                    {stat.change.startsWith('+') ? (
                      <ArrowUpwardIcon sx={{ fontSize: 16 }} />
                    ) : (
                      <ArrowDownwardIcon sx={{ fontSize: 16 }} />
                    )}
                  </Typography>
                </Box>
              </Paper>
            </Grid>
          ))}
        </Grid>

        {/* Main Content */}
        <Grid container spacing={3}>
          {/* Chart */}
          <Grid item xs={12} md={8}>
            <Paper sx={{ p: 3, borderRadius: 2 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                User Growth
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                New user registrations over time
              </Typography>
              <Box sx={{ height: 300 }}>
                <Line data={chartData} options={chartOptions} />
              </Box>
            </Paper>
          </Grid>

          {/* Recent Activity */}
          <Grid item xs={12} md={4}>
            <Paper sx={{ p: 3, borderRadius: 2 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Recent Activity Summary
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Last 24 hours platform activity
              </Typography>
              <List>
                {recentActivity.map((activity, index) => (
                  <ListItem key={index} sx={{ px: 0 }}>
                    <ListItemAvatar>
                      <Avatar sx={{ bgcolor: 'primary.main' }}>{activity.avatar}</Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={activity.name}
                      secondary={
                        <>
                          <Typography component="span" variant="body2" color="text.primary">
                            {activity.action}
                          </Typography>
                          <br />
                          <Typography component="span" variant="caption" color="text.secondary">
                            {activity.time}
                          </Typography>
                        </>
                      }
                    />
                  </ListItem>
                ))}
              </List>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default AdminDashboard; 