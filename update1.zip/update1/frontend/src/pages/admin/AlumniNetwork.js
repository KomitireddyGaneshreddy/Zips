import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  TextField,
  InputAdornment,
  Card,
  CardContent,
  Avatar,
  Grid,
  Chip,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Tabs,
  Tab,
  Select,
  MenuItem,
  Button,
  ToggleButtonGroup,
  ToggleButton
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import GridViewIcon from '@mui/icons-material/GridView';
import ListIcon from '@mui/icons-material/List';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import BusinessIcon from '@mui/icons-material/Business';
import SchoolIcon from '@mui/icons-material/School';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import DeleteIcon from '@mui/icons-material/Delete';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { authService } from '../../services/api';

const AlumniNetwork = () => {
  const [alumni, setAlumni] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [yearFilter, setYearFilter] = useState('All Years');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);

  useEffect(() => {
    fetchAlumni();
  }, []);

  const fetchAlumni = async () => {
    try {
      const data = await authService.getAllUsers();
      // Filter to show only alumni users
      const alumniUsers = data.filter(user => user.role === 'alumni');
      setAlumni(alumniUsers);
    } catch (error) {
      console.error('Error fetching alumni:', error);
    }
  };

  const handleViewModeChange = (event, newMode) => {
    if (newMode !== null) {
      setViewMode(newMode);
    }
  };

  const handleDeleteClick = (user) => {
    setUserToDelete(user);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    try {
      await authService.deleteAccount();
      // Remove the deleted user from the state
      setAlumni(prevAlumni => prevAlumni.filter(a => a.id !== userToDelete.id));
      setDeleteDialogOpen(false);
      setUserToDelete(null);
    } catch (error) {
      console.error('Error deleting user:', error);
      // You might want to show an error message to the admin
    }
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setUserToDelete(null);
  };

  const getGraduationYear = (yearString) => {
    if (!yearString) return null;
    const match = yearString.match(/-(\d{4})/);
    return match ? match[1] : null;
  };

  const filteredAlumni = alumni.filter(alumnus => {
    const matchesSearch = 
      alumnus.first_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alumnus.last_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alumnus.company?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alumnus.location?.toLowerCase().includes(searchQuery.toLowerCase());

    const graduationYear = getGraduationYear(alumnus.year);
    const matchesYear = yearFilter === 'All Years' || graduationYear === yearFilter;
    const matchesDepartment = departmentFilter === 'All' || alumnus.department?.toUpperCase() === departmentFilter;

    return matchesSearch && matchesYear && matchesDepartment;
  });

  // Replace the dynamic departments array with predefined departments
  const departments = [
    'All',
    'CSE',
    'ECE',
    'EEE',
    'MECH',
    'CIVIL'
  ];

  const GridView = () => (
    <Grid container spacing={3}>
      {filteredAlumni.map((alumnus) => (
        <Grid item xs={12} sm={6} md={4} key={alumnus.id}>
          <Card sx={{ height: '100%' }}>
            <Box sx={{ 
              height: 100, 
              bgcolor: '#3b82f6',
              position: 'relative' 
            }} />
            <CardContent sx={{ pt: 7, position: 'relative' }}>
              <Avatar
                sx={{
                  width: 80,
                  height: 80,
                  position: 'absolute',
                  top: -40,
                  left: '50%',
                  transform: 'translateX(-50%)',
                  bgcolor: '#1a237e',
                  fontSize: '1.5rem'
                }}
              >
                {alumnus.first_name?.[0]}{alumnus.last_name?.[0]}
              </Avatar>

              <Typography variant="h6" align="center" sx={{ mb: 0.5, color: '#1e40af' }}>
                {`${alumnus.first_name} ${alumnus.last_name}`}
              </Typography>
              <Typography variant="body2" align="center" color="text.secondary" sx={{ mb: 2 }}>
                {alumnus.title} at {alumnus.company}
              </Typography>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <SchoolIcon sx={{ fontSize: 20, color: 'text.secondary', mr: 1 }} />
                <Typography variant="body2" color="text.secondary">
                  {alumnus.department}
                </Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <LocationOnIcon sx={{ fontSize: 20, color: 'text.secondary', mr: 1 }} />
                <Typography variant="body2" color="text.secondary">
                  {alumnus.location}
                </Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <SchoolIcon sx={{ fontSize: 20, color: 'text.secondary', mr: 1 }} />
                <Typography variant="body2" color="text.secondary">
                  Class of {alumnus.year}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                  • {alumnus.degree}
                </Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <BusinessIcon sx={{ fontSize: 20, color: 'text.secondary', mr: 1 }} />
                <Typography variant="body2" color="text.secondary">
                  {alumnus.company}
                </Typography>
              </Box>

              {alumnus.bio && (
                <>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Bio</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {alumnus.bio}
                  </Typography>
                </>
              )}

              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button
                  variant="outlined"
                  startIcon={<EmailIcon />}
                  sx={{ flex: 1 }}
                  component="a"
                  href={`mailto:${alumnus.email}`}
                >
                  Email
                </Button>
                <Button
                  variant="outlined"
                  color="error"
                  startIcon={<DeleteIcon />}
                  sx={{ flex: 1 }}
                  onClick={() => handleDeleteClick(alumnus)}
                >
                  Delete
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );

  const ListView = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Department</TableCell>
            <TableCell>Location</TableCell>
            <TableCell>Graduation</TableCell>
            <TableCell>Company</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {filteredAlumni.map((alumnus) => (
            <TableRow key={alumnus.id}>
              <TableCell>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Avatar sx={{ bgcolor: '#1a237e' }}>
                    {alumnus.first_name?.[0]}{alumnus.last_name?.[0]}
                  </Avatar>
                  <Box>
                    <Typography variant="subtitle2" sx={{ color: '#3b82f6' }}>
                      {`${alumnus.first_name} ${alumnus.last_name}`}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {alumnus.title}
                    </Typography>
                  </Box>
                </Box>
              </TableCell>
              <TableCell>
                <Typography variant="body2">
                  {alumnus.department}
                </Typography>
              </TableCell>
              <TableCell>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <LocationOnIcon sx={{ fontSize: 20, color: 'text.secondary', mr: 1 }} />
                  {alumnus.location}
                </Box>
              </TableCell>
              <TableCell>
                <Box>
                  <Typography variant="body2">{alumnus.year}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    {alumnus.degree}
                  </Typography>
                </Box>
              </TableCell>
              <TableCell>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <BusinessIcon sx={{ fontSize: 20, color: 'text.secondary', mr: 1 }} />
                  {alumnus.company}
                </Box>
              </TableCell>
              <TableCell>
                <IconButton 
                  size="small" 
                  color="primary"
                  component="a"
                  href={`mailto:${alumnus.email}`}
                >
                  <EmailIcon />
                </IconButton>
                <IconButton 
                  size="small" 
                  color="error"
                  onClick={() => handleDeleteClick(alumnus)}
                >
                  <DeleteIcon />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ color: '#1e40af', fontWeight: 600, mb: 3 }}>
        Alumni Network
      </Typography>

      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" sx={{ mb: 1 }}>Alumni Directory</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Browse and manage alumni records.
        </Typography>

        <Box sx={{ display: 'flex', gap: 2, mb: 3, alignItems: 'center' }}>
          <TextField
            placeholder="Search alumni..."
            variant="outlined"
            size="small"
            fullWidth
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'text.secondary' }} />
                </InputAdornment>
              ),
            }}
            sx={{ maxWidth: 400 }}
          />
          
          <Select
            value={yearFilter}
            onChange={(e) => setYearFilter(e.target.value)}
            size="small"
            sx={{ minWidth: 120 }}
          >
            <MenuItem value="All Years">All Years</MenuItem>
            {[...Array(10)].map((_, i) => {
              const year = new Date().getFullYear() - i;
              return (
                <MenuItem key={year} value={year.toString()}>
                  {year}
                </MenuItem>
              );
            })}
          </Select>

          <Select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            size="small"
            sx={{ minWidth: 200 }}
            displayEmpty
          >
            {departments.map((dept) => (
              <MenuItem key={dept} value={dept}>
                {dept === 'All' ? 'All Departments' : dept}
              </MenuItem>
            ))}
          </Select>

          <Box sx={{ ml: 'auto' }}>
            <ToggleButtonGroup
              value={viewMode}
              exclusive
              onChange={handleViewModeChange}
              size="small"
            >
              <ToggleButton value="grid">
                <GridViewIcon />
              </ToggleButton>
              <ToggleButton value="list">
                <ListIcon />
              </ToggleButton>
            </ToggleButtonGroup>
          </Box>
        </Box>

        {viewMode === 'grid' ? <GridView /> : <ListView />}
      </Box>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete {userToDelete?.first_name} {userToDelete?.last_name}? This action cannot be undone and will remove all their data from the system.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel}>Cancel</Button>
          <Button onClick={handleDeleteConfirm} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AlumniNetwork; 