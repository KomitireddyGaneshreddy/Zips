import React, { useState, useMemo, useEffect } from 'react';
import {
  Box,
  Typography,
  TextField,
  MenuItem,
  Grid,
  Card,
  CardContent,
  Button,
  Avatar,
  Tabs,
  Tab,
  InputAdornment,
  Chip,
  Container,
  Paper,
  CircularProgress,
  Snackbar,
  Alert,
  Badge,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import PersonIcon from '@mui/icons-material/Person';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import GroupIcon from '@mui/icons-material/Group';
import EventIcon from '@mui/icons-material/Event';
import { alpha } from '@mui/material/styles';
import { authService } from '../services/api';

// Add this color array after imports
const AVATAR_COLORS = [
  '#1976d2', // blue
  '#388e3c', // green
  '#d32f2f', // red
  '#7b1fa2', // purple
  '#c2185b', // pink
  '#0288d1', // light blue
  '#f57c00', // orange
  '#455a64', // blue grey
];

// Utility functions for avatar generation
function stringToColor(string) {
  let hash = 0;
  for (let i = 0; i < string.length; i++) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }
  let color = '#';
  for (let i = 0; i < 3; i++) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  return color;
}

function getInitials(name) {
  return name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase();
}

const Network = () => {
  const [value, setValue] = useState(0);
  const [department, setDepartment] = useState('All Departments');
  const [batch, setBatch] = useState('All Batches');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [alumni, setAlumni] = useState([]);
  const [connectedAlumni, setConnectedAlumni] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [sentRequests, setSentRequests] = useState([]);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Fetch discover alumni
  const fetchDiscoverAlumni = async () => {
    try {
      setLoading(true);
      setError(null);
      const filters = {
        department,
        batch,
        search: searchQuery
      };
      const data = await authService.getDiscoverAlumni(filters);
      setAlumni(data);
    } catch (err) {
      setError(err.message || 'Failed to fetch alumni data');
      console.error('Error fetching alumni:', err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch connected alumni
  const fetchConnectedAlumni = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await authService.getConnectedAlumni();
      setConnectedAlumni(data);
    } catch (err) {
      setError(err.message || 'Failed to fetch connected alumni');
      console.error('Error fetching connected alumni:', err);
    } finally {
      setLoading(false);
    }
  };

  // Add fetchPendingRequests function
  const fetchPendingRequests = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await authService.getPendingRequests();
      setPendingRequests(data);
    } catch (err) {
      setError(err.message || 'Failed to fetch pending requests');
      console.error('Error fetching pending requests:', err);
    } finally {
      setLoading(false);
    }
  };

  // Add fetchSentRequests function
  const fetchSentRequests = async () => {
    try {
      setLoading(true);
      setError(null);
      const requests = await authService.getSentRequests();
      setSentRequests(requests);
    } catch (error) {
      console.error('Error fetching sent requests:', error);
      setError('Failed to fetch sent requests. Please try again later.');
      setSnackbar({
        open: true,
        message: 'Failed to fetch sent requests',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  // Fetch data when filters change
  useEffect(() => {
    if (value === 0) {
      fetchDiscoverAlumni();
    } else if (value === 1) {
      fetchConnectedAlumni();
    } else if (value === 2) {
      fetchPendingRequests();
    } else if (value === 3) {
      fetchSentRequests();
    }
  }, [value]);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleConnect = async (alumniId) => {
    try {
      setLoading(true);
      await authService.connectWithAlumni(alumniId);
      
      // Update the alumni list to reflect the new connection status
      setAlumni(prevAlumni => 
        prevAlumni.map(a => 
          a.id === alumniId 
            ? { ...a, connectionStatus: 'pending' }
            : a
        )
      );

      setSnackbar({
        open: true,
        message: 'Connection request sent successfully',
        severity: 'success'
      });
    } catch (err) {
      console.error('Error connecting with alumni:', err);
      setSnackbar({
        open: true,
        message: err.response?.data?.message || 'Error sending connection request',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  // Filter alumni based on search query and filters
  const filteredAlumni = useMemo(() => {
    return alumni.filter(a => {
      const matchesSearch = searchQuery === '' || 
        a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.company.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDepartment = department === 'All Departments' || 
        a.department === department;

      const matchesBatch = batch === 'All Batches' || 
        a.batch === batch;      

      return matchesSearch && matchesDepartment && matchesBatch;
    });
  }, [searchQuery, department, batch, alumni]);

  // Add this function before renderAlumniCard
  const getAvatarColor = (id, name) => {
    // Use either id or name to generate a consistent color index
    const index = typeof id === 'number' 
      ? id % AVATAR_COLORS.length
      : name.length % AVATAR_COLORS.length;
    return AVATAR_COLORS[index];
  };

  // Add handleConnectionRequest function
  const handleConnectionRequest = async (connectionId, action) => {
    try {
      setLoading(true);
      await authService.handleConnectionRequest(connectionId, action);
      
      // Remove the request from the pending list
      setPendingRequests(prev => prev.filter(r => r.connectionId !== connectionId));
      
      // Refresh connected alumni if request was accepted
      if (action === 'accept') {
        fetchConnectedAlumni();
      }

      setSnackbar({
        open: true,
        message: `Connection request ${action}ed successfully`,
        severity: 'success'
      });
    } catch (err) {
      console.error('Error handling connection request:', err);
      setSnackbar({
        open: true,
        message: err.response?.data?.message || `Error ${action}ing connection request`,
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  // Add handleRevokeRequest function
  const handleRevokeRequest = async (connectionId) => {
    try {
      setLoading(true);
      await authService.revokeConnectionRequest(connectionId);
      
      // Remove the revoked request from the list
      setSentRequests(prev => prev.filter(request => request.connectionId !== connectionId));
      
      setSnackbar({
        open: true,
        message: 'Connection request revoked successfully',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error revoking request:', error);
      setSnackbar({
        open: true,
        message: error.response?.data?.message || 'Error revoking connection request',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  // Update renderAlumniCard to handle pending requests
  const renderAlumniCard = (alumni, isPendingRequest = false) => {
    const avatarColor = getAvatarColor(alumni.id, alumni.name);
    return (
      <Grid item xs={12} key={alumni.id}>
        <Card 
          elevation={0}
          sx={{ 
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
            transition: 'transform 0.2s ease, box-shadow 0.2s ease',
            maxWidth: '700px',
            mx: 'auto',
            '&:hover': {
              transform: 'translateY(-2px)',
              boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
            },
          }}
        >
          <CardContent sx={{ p: 2 }}>
            <Grid container spacing={2} alignItems="center">
              <Grid item>
                <Avatar 
                  sx={{ 
                    width: 45, 
                    height: 45,
                    bgcolor: avatarColor,
                    fontSize: '1.1rem',
                    fontWeight: 500,
                  }}
                >
                  {alumni.name[0]}
                </Avatar>
              </Grid>
              <Grid item xs>
                <Typography variant="subtitle1" sx={{ fontWeight: 600, fontSize: '0.9rem' }}>
                  {alumni.name}
                </Typography>
                <Typography 
                  sx={{ 
                    color: 'text.secondary',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 0.5,
                    mb: 0.5,
                    fontSize: '0.8rem'
                  }}
                >
                  <WorkIcon sx={{ fontSize: 14 }} />
                  {alumni.role} at {alumni.company}
                </Typography>
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 0.5 }}>
                  <Chip 
                    icon={<SchoolIcon sx={{ fontSize: '0.9rem' }} />}
                    label={alumni.department}
                    size="small"
                    sx={{ 
                      bgcolor: alpha(avatarColor, 0.1),
                      height: '22px',
                      '& .MuiChip-label': {
                        fontSize: '0.75rem',
                        px: 1
                      }
                    }}
                  />
                  <Chip 
                    icon={<PersonIcon sx={{ fontSize: '0.9rem' }} />}
                    label={`Class of ${alumni.batch}`}
                    size="small"
                    sx={{ 
                      bgcolor: alpha(avatarColor, 0.1),
                      height: '22px',
                      '& .MuiChip-label': {
                        fontSize: '0.75rem',
                        px: 1
                      }
                    }}
                  />
                </Box>
                <Box>
                  <Typography 
                    variant="caption" 
                    color="text.secondary"
                    sx={{ display: 'block', mb: 0.5 }}
                  >
                    Skills:
                  </Typography>
                  {alumni.skills.map((skill, index) => (
                    <Chip
                      key={index}
                      label={skill}
                      size="small"
                      sx={{ 
                        mr: 0.5,
                        mb: 0.5,
                        bgcolor: 'transparent',
                        border: '1px solid',
                        borderColor: 'divider',
                        height: '20px',
                        '& .MuiChip-label': {
                          fontSize: '0.7rem',
                          px: 1
                        }
                      }}
                    />
                  ))}
                </Box>
              </Grid>
              <Grid item>
                {isPendingRequest ? (
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Button 
                      variant="contained" 
                      size="small"
                      onClick={() => handleConnectionRequest(alumni.connectionId, 'accept')}
                      sx={{ 
                        bgcolor: 'success.main',
                        fontSize: '0.8rem',
                        py: 0.5,
                        minWidth: '80px',
                        '&:hover': {
                          bgcolor: 'success.dark',
                        },
                      }}
                    >
                      Accept
                    </Button>
                    <Button 
                      variant="outlined" 
                      size="small"
                      onClick={() => handleConnectionRequest(alumni.connectionId, 'reject')}
                      sx={{ 
                        borderColor: 'error.main',
                        color: 'error.main',
                        fontSize: '0.8rem',
                        py: 0.5,
                        minWidth: '80px',
                        '&:hover': {
                          bgcolor: 'error.light',
                          borderColor: 'error.main',
                        },
                      }}
                    >
                      Reject
                    </Button>
                  </Box>
                ) : (
                  <Button 
                    variant="contained" 
                    size="small"
                    onClick={() => handleConnect(alumni.id)}
                    disabled={alumni.connectionStatus === 'pending'}
                    sx={{ 
                      bgcolor: alumni.connectionStatus === 'accepted' ? 'success.main' : avatarColor,
                      fontSize: '0.8rem',
                      py: 0.5,
                      minWidth: '80px',
                      '&:hover': {
                        bgcolor: alumni.connectionStatus === 'accepted'
                          ? 'success.dark'
                          : alpha(avatarColor, 0.9),
                      },
                    }}
                  >
                    {alumni.connectionStatus === 'accepted' ? 'Connected' : 
                     alumni.connectionStatus === 'pending' ? 'Pending' : 'Connect'}
                  </Button>
                )}
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>
    );
  };

  // Update renderSentRequests to include revoke button
  const renderSentRequests = () => {
    if (loading) {
      return (
        <Box sx={{ textAlign: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      );
    }

    if (error) {
      return (
        <Alert severity="error" sx={{ width: '100%' }}>
          {error}
        </Alert>
      );
    }

    if (!sentRequests.length) {
      return (
        <Paper 
          elevation={0}
          sx={{ 
            textAlign: 'center', 
            py: 8,
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <PersonIcon 
            sx={{ 
              fontSize: 64,
              color: 'text.secondary',
              mb: 2,
            }}
          />
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No sent requests
          </Typography>
          <Typography color="text.secondary" sx={{ mb: 3 }}>
            You haven't sent any connection requests yet
          </Typography>
          <Button
            variant="contained"
            onClick={() => setValue(0)}
            startIcon={<SearchIcon />}
          >
            Discover Alumni
          </Button>
        </Paper>
      );
    }

    return (
      <Grid container spacing={3}>
        {sentRequests.map((request) => (
          <Grid item xs={12} key={request.connectionId}>
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                transition: 'transform 0.2s ease, box-shadow 0.2s ease',
                '&:hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                },
              }}
            >
              <CardContent>
                <Grid container spacing={2} alignItems="center">
                  <Grid item>
                    <Avatar
                      sx={{
                        bgcolor: stringToColor(request.user.name),
                        width: 56,
                        height: 56
                      }}
                    >
                      {getInitials(request.user.name)}
                    </Avatar>
                  </Grid>
                  <Grid item xs>
                    <Typography variant="h6" component="div">
                      {request.user.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {request.user.role} at {request.user.company}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {request.user.department} • {request.user.batch}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
                      Sent on: {new Date(request.sentAt).toLocaleDateString()}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Chip
                        label="Pending"
                        color="warning"
                        size="small"
                      />
                      <Button
                        variant="outlined"
                        color="error"
                        size="small"
                        onClick={() => handleRevokeRequest(request.connectionId)}
                        sx={{ 
                          borderColor: 'error.main',
                          color: 'error.main',
                          '&:hover': {
                            bgcolor: 'error.light',
                            borderColor: 'error.main',
                          },
                        }}
                      >
                        Revoke
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    );
  };

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Page Header */}
        <Box sx={{ mb: 4, textAlign: 'center' }}>
          <Typography 
            variant="h4" 
            sx={{ 
              fontWeight: 600,
              color: '#1a237e',
              mb: 1,
            }}
          >
            Alumni Network
          </Typography>
          <Typography 
            variant="subtitle1" 
            color="text.secondary"
            sx={{ maxWidth: 600, mx: 'auto' }}
          >
            Connect with fellow alumni, share experiences, and grow your professional network
          </Typography>
        </Box>

        {/* Network Stats */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3, 
                textAlign: 'center',
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: 2,
                transition: 'transform 0.2s ease',
                '&:hover': {
                  transform: 'translateY(-4px)',
                },
              }}
            >
              <GroupIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
              <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>5,000+</Typography>
              <Typography color="text.secondary">Alumni Members</Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3, 
                textAlign: 'center',
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: 2,
                transition: 'transform 0.2s ease',
                '&:hover': {
                  transform: 'translateY(-4px)',
                },
              }}
            >
              <SchoolIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
              <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>16+</Typography>
              <Typography color="text.secondary">Batches</Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0}
              sx={{ 
                p: 3, 
                textAlign: 'center',
                border: '1px solid',
                borderColor: 'divider',
                borderRadius: 2,
                transition: 'transform 0.2s ease',
                '&:hover': {
                  transform: 'translateY(-4px)',
                },
              }}
            >
              <EventIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
              <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>1+</Typography>
              <Typography color="text.secondary">Alumni Meetups</Typography>
            </Paper>
          </Grid>
        </Grid>

        {/* Tabs */}
        <Paper 
          elevation={0}
          sx={{ 
            mb: 4,
            borderRadius: 2,
            overflow: 'hidden',
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <Tabs 
            value={value} 
            onChange={handleChange}
            sx={{ 
              bgcolor: 'white',
              borderBottom: '1px solid',
              borderColor: 'divider',
              '& .MuiTab-root': {
                minHeight: 64,
                fontSize: '1rem',
              },
            }}
          >
            <Tab 
              label="Discover Alumni" 
              icon={<SearchIcon />}
              iconPosition="start"
            />
            <Tab 
              label="Connected Alumni" 
              icon={<GroupIcon />}
              iconPosition="start"
            />
            <Tab 
              label={
                <Badge badgeContent={pendingRequests.length} color="error">
                  Pending Requests
                </Badge>
              }
              icon={<PersonIcon />}
              iconPosition="start"
            />
            <Tab 
              label={
                <Badge badgeContent={sentRequests.length} color="primary">
                  Sent Requests
                </Badge>
              }
              icon={<PersonIcon />}
              iconPosition="start"
            />
          </Tabs>
        </Paper>

        {value === 0 && (
          <>
            {/* Search and Filters */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 3,
                mb: 4,
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search alumni by name, role, or company..."
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon color="action" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'white',
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={6} md={3}>
                  <TextField
                    select
                    fullWidth
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    label="Department"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'white',
                      },
                    }}
                  >
                    <MenuItem value="All Departments">All Departments</MenuItem>
                    <MenuItem value="CSE">CSE</MenuItem>
                    <MenuItem value="ECE">ECE</MenuItem>
                    <MenuItem value="MECH">MECH</MenuItem>
                  </TextField>
                </Grid>
                <Grid item xs={6} md={3}>
                  <TextField
                    select
                    fullWidth
                    value={batch}
                    onChange={(e) => setBatch(e.target.value)}
                    label="Batch"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        bgcolor: 'white',
                      },
                    }}
                  >
                    <MenuItem value="All Batches">All Batches</MenuItem>
                    <MenuItem value="2023">2023</MenuItem>
                    <MenuItem value="2022">2022</MenuItem>
                    <MenuItem value="2021">2021</MenuItem>
                  </TextField>
                </Grid>
              </Grid>
            </Paper>

            {loading ? (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <CircularProgress />
              </Box>
            ) : error ? (
              <Paper 
                elevation={0}
                sx={{ 
                  textAlign: 'center', 
                  py: 6,
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                }}
              >
                <Typography color="error" gutterBottom>
                  {error}
                </Typography>
                <Button
                  variant="contained"
                  onClick={fetchDiscoverAlumni}
                  sx={{ mt: 2 }}
                >
                  Retry
                </Button>
              </Paper>
            ) : (
              <>
                <Typography 
                  variant="h6" 
                  sx={{ 
                    mb: 3,
                    fontWeight: 600,
                    color: '#1a237e',
                  }}
                >
                  Discover Alumni
                </Typography>

                <Grid container spacing={2}>
                  {alumni.length > 0 ? (
                    alumni.map(alumnus => renderAlumniCard(alumnus))
                  ) : (
                    <Grid item xs={12}>
                      <Paper 
                        elevation={0}
                        sx={{ 
                          textAlign: 'center', 
                          py: 6,
                          borderRadius: 2,
                          border: '1px solid',
                          borderColor: 'divider',
                        }}
                      >
                        <SearchIcon 
                          sx={{ 
                            fontSize: 48,
                            color: 'text.secondary',
                            mb: 2,
                          }}
                        />
                        <Typography variant="h6" color="text.secondary" gutterBottom>
                          No matching alumni found
                        </Typography>
                        <Typography color="text.secondary" sx={{ mb: 2 }}>
                          Try adjusting your search or filters
                        </Typography>
                        {(searchQuery || department !== 'All Departments' || batch !== 'All Batches') && (
                          <Button
                            variant="outlined"
                            onClick={() => {
                              setSearchQuery('');
                              setDepartment('All Departments');
                              setBatch('All Batches');
                            }}
                            startIcon={<SearchIcon />}
                          >
                            Clear all filters
                          </Button>
                        )}
                      </Paper>
                    </Grid>
                  )}
                </Grid>
              </>
            )}
          </>
        )}

        {value === 1 && (
          <>
            {loading ? (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <CircularProgress />
              </Box>
            ) : error ? (
              <Paper 
                elevation={0}
                sx={{ 
                  textAlign: 'center', 
                  py: 6,
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                }}
              >
                <Typography color="error" gutterBottom>
                  {error}
                </Typography>
                <Button
                  variant="contained"
                  onClick={fetchConnectedAlumni}
                  sx={{ mt: 2 }}
                >
                  Retry
                </Button>
              </Paper>
            ) : (
              <>
                {connectedAlumni.length > 0 ? (
                  <>
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        mb: 3,
                        fontWeight: 600,
                        color: '#1a237e',
                      }}
                    >
                      Your Connections ({connectedAlumni.length})
                    </Typography>
                    <Grid container spacing={2}>
                      {connectedAlumni.map(alumnus => renderAlumniCard(alumnus))}
                    </Grid>
                  </>
                ) : (
                  <Paper 
                    elevation={0}
                    sx={{ 
                      textAlign: 'center', 
                      py: 8,
                      borderRadius: 2,
                      border: '1px solid',
                      borderColor: 'divider',
                    }}
                  >
                    <GroupIcon 
                      sx={{ 
                        fontSize: 64,
                        color: 'text.secondary',
                        mb: 2,
                      }}
                    />
                    <Typography variant="h6" color="text.secondary" gutterBottom>
                      No connections yet
                    </Typography>
                    <Typography color="text.secondary" sx={{ mb: 3 }}>
                      Start connecting with other alumni to build your network
                    </Typography>
                    <Button
                      variant="contained"
                      onClick={() => setValue(0)}
                      startIcon={<SearchIcon />}
                    >
                      Discover Alumni
                    </Button>
                  </Paper>
                )}
              </>
            )}
          </>
        )}

        {/* Add new tab content for Pending Requests */}
        {value === 2 && (
          <>
            {loading ? (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <CircularProgress />
              </Box>
            ) : error ? (
              <Paper 
                elevation={0}
                sx={{ 
                  textAlign: 'center', 
                  py: 6,
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                }}
              >
                <Typography color="error" gutterBottom>
                  {error}
                </Typography>
                <Button
                  variant="contained"
                  onClick={fetchPendingRequests}
                  sx={{ mt: 2 }}
                >
                  Retry
                </Button>
              </Paper>
            ) : (
              <>
                {pendingRequests.length > 0 ? (
                  <>
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        mb: 3,
                        fontWeight: 600,
                        color: '#1a237e',
                      }}
                    >
                      Pending Connection Requests ({pendingRequests.length})
                    </Typography>
                    <Grid container spacing={2}>
                      {pendingRequests.map(request => renderAlumniCard(request, true))}
                    </Grid>
                  </>
                ) : (
                  <Paper 
                    elevation={0}
                    sx={{ 
                      textAlign: 'center', 
                      py: 8,
                      borderRadius: 2,
                      border: '1px solid',
                      borderColor: 'divider',
                    }}
                  >
                    <PersonIcon 
                      sx={{ 
                        fontSize: 64,
                        color: 'text.secondary',
                        mb: 2,
                      }}
                    />
                    <Typography variant="h6" color="text.secondary" gutterBottom>
                      No pending requests
                    </Typography>
                    <Typography color="text.secondary" sx={{ mb: 3 }}>
                      You don't have any pending connection requests at the moment
                    </Typography>
                  </Paper>
                )}
              </>
            )}
          </>
        )}

        {value === 3 && renderSentRequests()}
      </Container>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Network; 