import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  Grid,
  Card,
  CardContent,
  Avatar,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Snackbar,
  Alert,
  CircularProgress,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import ShareIcon from '@mui/icons-material/Share';
import WorkIcon from '@mui/icons-material/Work';
import SchoolIcon from '@mui/icons-material/School';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import EmailIcon from '@mui/icons-material/Email';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import CloseIcon from '@mui/icons-material/Close';
import { useAuth } from '../context/AuthContext';
import { authService } from '../services/api';
import { jobService, eventService, mentorshipService } from '../services/api';

const Profile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [editForm, setEditForm] = useState(null);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [openShareDialog, setOpenShareDialog] = useState(false);
  const [showSnackbar, setShowSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState(null);
  const [error, setError] = useState(null);
  const [postedJobs, setPostedJobs] = useState([]);
  const [postedEvents, setPostedEvents] = useState([]);
  const [postedMentorships, setPostedMentorships] = useState([]);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        setLoading(true);
        
        // Fetch profile data
        const profileData = await authService.getProfile();
        console.log('Raw profile data:', profileData);

        // Transform profile data
        const transformedData = {
          id: profileData.id,
          name: `${profileData.first_name} ${profileData.last_name}`,
          avatar: '#1a237e',
          email: profileData.email,
          department: profileData.department || 'CSE',
          batch: profileData.batch || '2020',
          designation: profileData.experience?.[0]?.role || 'Software Engineer',
          company: profileData.experience?.[0]?.company || 'Not specified',
          location: profileData.current_location || 'Not specified',
          bio: profileData.bio || 'Experienced software engineer passionate about building scalable applications and solving complex problems.',
          skills: profileData.skills?.map(skill => skill.name) || ['React', 'Node.js', 'Python', 'System Design', 'Cloud Computing'],
          education: profileData.education || [{
            degree: 'B.Tech in Computer Science',
            institution: 'JNTUA College of Engineering',
            year: '2016-2020',
            grade: '8.5 CGPA'
          }],
          experience: profileData.experience || [{
            role: 'Software Engineer',
            company: 'Not specified',
            duration: 'Present',
            description: 'No description available'
          }],
          socialLinks: {
            linkedin: profileData.social_links?.linkedin || 'linkedin.com/in/username',
            github: profileData.social_links?.github || 'https://github.com/username'
          }
        };

        setProfile(transformedData);
        setEditForm(transformedData);

        // Fetch user's posts
        const [jobs, events, mentorships] = await Promise.all([
          jobService.getAllJobs(),
          eventService.getAllEvents(),
          mentorshipService.getAllMentorships()
        ]);

        console.log('Profile ID:', profileData.id, 'Type:', typeof profileData.id);
        
        console.log('All Jobs:', jobs);
        console.log('Sample job posted_by:', jobs[0]?.posted_by, 'Type:', typeof jobs[0]?.posted_by);
        
        console.log('All Events:', events);
        console.log('Sample event created_by:', events[0]?.created_by, 'Type:', typeof events[0]?.created_by);
        
        console.log('All Mentorships:', mentorships);
        console.log('Sample mentorship mentor_id:', mentorships[0]?.mentor_id, 'Type:', typeof mentorships[0]?.mentor_id);

        // Filter posts using profile ID instead of user context
        const userId = String(profileData.id);
        const userJobs = jobs.filter(job => String(job.posted_by) === userId);
        const userEvents = events.filter(event => String(event.created_by) === userId);
        const userMentorships = mentorships.filter(mentorship => String(mentorship.mentor_id) === userId);

        console.log('Profile ID for comparison:', userId);
        console.log('User\'s Posted Jobs:', userJobs);
        console.log('User\'s Posted Events:', userEvents);
        console.log('User\'s Posted Mentorships:', userMentorships);

        setPostedJobs(userJobs);
        setPostedEvents(userEvents);
        setPostedMentorships(userMentorships);

      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Failed to load profile data');
        setSnackbar({
          open: true,
          message: 'Error loading profile data',
          severity: 'error'
        });
      } finally {
        setLoading(false);
      }
    };

    fetchAllData();
  }, []);

  const handleEditFormChange = (field, value) => {
    setEditForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleEducationChange = (index, field, value) => {
    setEditForm(prev => {
      const newEducation = [...prev.education];
      newEducation[index] = {
        ...newEducation[index],
        [field]: value
      };
      return {
        ...prev,
        education: newEducation
      };
    });
  };

  const handleExperienceChange = (index, field, value) => {
    setEditForm(prev => {
      const newExperience = [...prev.experience];
      newExperience[index] = {
        ...newExperience[index],
        [field]: value
      };
      return {
        ...prev,
        experience: newExperience
      };
    });
  };

  const handleSocialLinksChange = (platform, value) => {
    setEditForm(prev => ({
      ...prev,
      socialLinks: {
        ...prev.socialLinks,
        [platform]: value
      }
    }));
  };

  const handleSkillsChange = (skills) => {
    setEditForm(prev => ({
      ...prev,
      skills: skills
    }));
  };

  const handleEditProfile = async () => {
    try {
      // Transform the edit form data back to backend format
      const [firstName, ...lastNameParts] = editForm.name.split(' ');
      const lastName = lastNameParts.join(' ');

      const backendData = {
        first_name: firstName,
        last_name: lastName,
        email: editForm.email,
        department: editForm.department,
        batch: editForm.batch,
        current_location: editForm.location,
        bio: editForm.bio,
        current_company: editForm.company,
        designation: editForm.designation || 'Not specified',
        current_phone: editForm.current_phone || '',
        previous_phone: editForm.previous_phone || '',
        surname: editForm.surname || ''
      };

      await authService.updateProfile(backendData);
      setProfile(editForm);
      setOpenEditDialog(false);
      setSnackbar({
        open: true,
        message: 'Profile updated successfully!',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      setSnackbar({
        open: true,
        message: error.response?.data?.message || 'Error updating profile',
        severity: 'error'
      });
    }
  };

  const handleShareProfile = () => {
    navigator.clipboard.writeText(`Check out my JNTUA Alumni profile: ${window.location.href}`);
    setOpenShareDialog(false);
    setSnackbarMessage('Profile link copied to clipboard!');
    setShowSnackbar(true);
  };

  const handleDeleteJob = async (jobId) => {
    try {
      await jobService.deleteJob(jobId);
      
      // Remove the job from the state
      setPostedJobs(prev => prev.filter(job => job.id !== jobId));
      
      console.log('Job deleted successfully:', jobId);
      
      setSnackbar({
        open: true,
        message: 'Job deleted successfully',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error deleting job:', error);
      setSnackbar({
        open: true,
        message: error.response?.data?.message || 'Failed to delete job',
        severity: 'error'
      });
    }
  };

  const handleDeleteEvent = async (eventId) => {
    try {
      await eventService.deleteEvent(eventId);
      
      // Remove the event from the state
      setPostedEvents(prev => prev.filter(event => event.id !== eventId));
      
      console.log('Event deleted successfully:', eventId);
      
      setSnackbar({
        open: true,
        message: 'Event deleted successfully',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error deleting event:', error);
      setSnackbar({
        open: true,
        message: error.response?.data?.message || 'Failed to delete event',
        severity: 'error'
      });
    }
  };

  const handleDeleteMentorship = async (mentorshipId) => {
    try {
      await mentorshipService.deleteMentorship(mentorshipId);
      
      // Remove the mentorship from the state
      setPostedMentorships(prev => prev.filter(mentorship => mentorship.id !== mentorshipId));
      
      console.log('Mentorship deleted successfully:', mentorshipId);
      
      setSnackbar({
        open: true,
        message: 'Mentorship deleted successfully',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error deleting mentorship:', error);
      setSnackbar({
        open: true,
        message: error.response?.data?.message || 'Failed to delete mentorship',
        severity: 'error'
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  const renderUserPosts = () => {
    return (
      <Box sx={{ mt: 4 }}>
        <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
          Your Posts
        </Typography>
        
        {/* Posted Jobs */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom color="primary">
            Posted Jobs
          </Typography>
          {postedJobs.length === 0 ? (
            <Typography color="text.secondary">You haven't posted any jobs yet</Typography>
          ) : (
            <Grid container spacing={3}>
              {postedJobs.map(job => (
                <Grid item xs={12} key={job.id}>
                  <Card 
                    elevation={0}
                    sx={{ 
                      p: 2,
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 2
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Box>
                        <Typography variant="h6">{job.title}</Typography>
                        <Typography color="text.secondary">{job.company}</Typography>
                        <Typography variant="body2" sx={{ mt: 1 }}>
                          {job.location} • {job.type}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                          Posted on: {new Date(job.created_at).toLocaleDateString()}
                        </Typography>
                      </Box>
                      <Button
                        variant="outlined"
                        color="error"
                        size="small"
                        onClick={() => handleDeleteJob(job.id)}
                      >
                        Delete
                      </Button>
                    </Box>
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>

        {/* Posted Events */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom color="primary">
            Posted Events
          </Typography>
          {postedEvents.length === 0 ? (
            <Typography color="text.secondary">You haven't posted any events yet</Typography>
          ) : (
            <Grid container spacing={3}>
              {postedEvents.map(event => (
                <Grid item xs={12} key={event.id}>
                  <Card 
                    elevation={0}
                    sx={{ 
                      p: 2,
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 2
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Box>
                        <Typography variant="h6">{event.title}</Typography>
                        <Typography color="text.secondary">{event.type}</Typography>
                        <Typography variant="body2" sx={{ mt: 1 }}>
                          {event.location} • {new Date(event.date).toLocaleDateString()}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                          Posted on: {new Date(event.created_at).toLocaleDateString()}
                        </Typography>
                      </Box>
                      <Button
                        variant="outlined"
                        color="error"
                        size="small"
                        onClick={() => handleDeleteEvent(event.id)}
                      >
                        Delete
                      </Button>
                    </Box>
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>

        {/* Posted Mentorships */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom color="primary">
            Posted Mentorships
          </Typography>
          {postedMentorships.length === 0 ? (
            <Typography color="text.secondary">You haven't posted any mentorship opportunities yet</Typography>
          ) : (
            <Grid container spacing={3}>
              {postedMentorships.map(mentorship => (
                <Grid item xs={12} key={mentorship.id}>
                  <Card 
                    elevation={0}
                    sx={{ 
                      p: 2,
                      border: '1px solid',
                      borderColor: 'divider',
                      borderRadius: 2
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Box>
                        <Typography variant="h6">{mentorship.title}</Typography>
                        <Typography color="text.secondary">{mentorship.expertise}</Typography>
                        <Typography variant="body2" sx={{ mt: 1 }}>
                          {mentorship.type} • {mentorship.department}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                          Posted on: {new Date(mentorship.created_at).toLocaleDateString()}
                        </Typography>
                      </Box>
                      <Button
                        variant="outlined"
                        color="error"
                        size="small"
                        onClick={() => handleDeleteMentorship(mentorship.id)}
                      >
                        Delete
                      </Button>
                    </Box>
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Box>
    );
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography>Loading profile...</Typography>
      </Box>
    );
  }

  if (!profile) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography>Error loading profile</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Profile Header */}
        <Card 
          elevation={0}
          sx={{ 
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
            mb: 3,
          }}
        >
          <CardContent sx={{ p: 4 }}>
            <Grid container spacing={3} alignItems="center">
              <Grid item>
                <Avatar 
                  sx={{ 
                    width: 120,
                    height: 120,
                    bgcolor: profile.avatar,
                    fontSize: '3rem'
                  }}
                >
                  {profile.name[0]}
                </Avatar>
              </Grid>
              <Grid item xs>
                <Typography variant="h4" sx={{ fontWeight: 600, mb: 1 }}>
                  {profile.name}
                </Typography>
                <Box sx={{ display: 'flex', gap: 3, color: 'text.secondary', mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <WorkIcon sx={{ fontSize: 20 }} />
                    <Typography>{profile.designation} at {profile.company}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <SchoolIcon sx={{ fontSize: 20 }} />
                    <Typography>{profile.department} • {profile.batch} batch</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <LocationOnIcon sx={{ fontSize: 20 }} />
                    <Typography>{profile.location}</Typography>
                  </Box>
                </Box>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <IconButton 
                    href={profile.socialLinks.linkedin}
                    target="_blank"
                    sx={{ color: '#0077b5' }}
                  >
                    <LinkedInIcon />
                  </IconButton>
                  <IconButton 
                    href={profile.socialLinks.github}
                    target="_blank"
                    sx={{ color: '#333' }}
                  >
                    <GitHubIcon />
                  </IconButton>
                  <IconButton 
                    href={`mailto:${profile.email}`}
                    sx={{ color: '#d32f2f' }}
                  >
                    <EmailIcon />
                  </IconButton>
                </Box>
              </Grid>
              <Grid item>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    variant="outlined"
                    startIcon={<ShareIcon />}
                    onClick={() => setOpenShareDialog(true)}
                    sx={{ borderRadius: 2 }}
                  >
                    Share Profile
                  </Button>
                  <Button
                    variant="contained"
                    startIcon={<EditIcon />}
                    onClick={() => setOpenEditDialog(true)}
                    sx={{
                      bgcolor: '#1a237e',
                      '&:hover': { bgcolor: '#0d1b60' },
                      borderRadius: 2,
                    }}
                  >
                    Edit Profile
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        {/* Profile Content */}
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            {/* About */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  About
                </Typography>
                <Typography color="text.secondary">
                  {profile.bio}
                </Typography>
              </CardContent>
            </Card>

            {/* Experience */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Experience
                </Typography>
                {profile.experience.map((exp, index) => (
                  <Box key={index} sx={{ mb: index !== profile.experience.length - 1 ? 3 : 0 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                      {exp.role}
                    </Typography>
                    <Typography color="text.secondary" gutterBottom>
                      {exp.company} • {exp.duration}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {exp.description}
                    </Typography>
                  </Box>
                ))}
              </CardContent>
            </Card>

            {/* Education */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Education
                </Typography>
                {profile.education.map((edu, index) => (
                  <Box key={index} sx={{ mb: index !== profile.education.length - 1 ? 3 : 0 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                      {edu.degree}
                    </Typography>
                    <Typography color="text.secondary" gutterBottom>
                      {edu.institution} • {edu.year}
                    </Typography>
                    {edu.grade && (
                      <Typography variant="body2" color="text.secondary">
                        Grade: {edu.grade}
                      </Typography>
                    )}
                  </Box>
                ))}
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={4}>
            {/* Skills */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                mb: 3,
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Skills
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                  {profile.skills.map((skill, index) => (
                    <Chip 
                      key={index}
                      label={skill}
                      sx={{ bgcolor: '#f3e5f5', color: '#7b1fa2' }}
                    />
                  ))}
                </Box>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card 
              elevation={0}
              sx={{ 
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Contact Information
                </Typography>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <EmailIcon color="action" />
                    <Typography color="text.secondary">{profile.email}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <LocationOnIcon color="action" />
                    <Typography color="text.secondary">{profile.location}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <LinkedInIcon color="action" />
                    <Typography 
                      color="primary"
                      component="a"
                      href={profile.socialLinks.linkedin}
                      target="_blank"
                      sx={{ textDecoration: 'none' }}
                    >
                      LinkedIn Profile
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <GitHubIcon color="action" />
                    <Typography 
                      color="primary"
                      component="a"
                      href={profile.socialLinks.github}
                      target="_blank"
                      sx={{ textDecoration: 'none' }}
                    >
                      GitHub Profile
                    </Typography>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Edit Profile Dialog */}
        <Dialog 
          open={openEditDialog} 
          onClose={() => setOpenEditDialog(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Edit Profile
              <IconButton onClick={() => setOpenEditDialog(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Full Name"
                  value={editForm.name}
                  onChange={(e) => handleEditFormChange('name', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  value={editForm.email}
                  onChange={(e) => handleEditFormChange('email', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Department"
                  value={editForm.department}
                  onChange={(e) => handleEditFormChange('department', e.target.value)}
                >
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Batch"
                  value={editForm.batch}
                  onChange={(e) => handleEditFormChange('batch', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Bio"
                  value={editForm.bio}
                  onChange={(e) => handleEditFormChange('bio', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Company"
                  value={editForm.company}
                  onChange={(e) => handleEditFormChange('company', e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Location"
                  value={editForm.location}
                  onChange={(e) => handleEditFormChange('location', e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="LinkedIn Profile"
                  value={editForm.socialLinks.linkedin}
                  onChange={(e) => handleSocialLinksChange('linkedin', e.target.value)}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={() => setOpenEditDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handleEditProfile}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Save Changes
            </Button>
          </DialogActions>
        </Dialog>

        {/* Share Profile Dialog */}
        <Dialog 
          open={openShareDialog} 
          onClose={() => setOpenShareDialog(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Share Profile
              <IconButton onClick={() => setOpenShareDialog(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Typography gutterBottom>
              Share your profile with other alumni and professionals.
            </Typography>
            <TextField
              fullWidth
              value={window.location.href}
              InputProps={{
                readOnly: true,
              }}
              sx={{ mt: 2 }}
            />
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={() => setOpenShareDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handleShareProfile}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Copy Link
            </Button>
          </DialogActions>
        </Dialog>

        {/* User's posts section */}
        {renderUserPosts()}

        {/* Snackbar for notifications */}
        <Snackbar
          open={showSnackbar}
          autoHideDuration={4000}
          onClose={() => setShowSnackbar(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setShowSnackbar(false)} 
            severity="success"
            sx={{ width: '100%' }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>

        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={handleCloseSnackbar}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Container>
    </Box>
  );
};

export default Profile; 