"use client"

import React, { useState, useEffect } from "react"
import {
  Box,
  Typography,
  Grid,
  Paper,
  Button,
  Avatar,
  Container,
  Chip,
  Divider,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Alert,
  useMediaQuery,
  useTheme,
} from "@mui/material"
import { Link as RouterLink } from "react-router-dom"
import {
  Work as WorkIcon,
  Event as EventIcon,
  Group as GroupIcon,
  Person as PersonIcon,
  Edit as EditIcon,
  Share as ShareIcon,
  LocationOn as LocationIcon,
  Business as BusinessIcon,
  CalendarToday as CalendarIcon,
  School as SchoolIcon,
  BatchPrediction as BatchPredictionIcon,
} from "@mui/icons-material"
import { useAuth } from "../context/AuthContext"
import { authService } from "../services/api"

const quickActions = [
  { icon: <PersonIcon />, label: "Profile", path: "/profile" },
  { icon: <WorkIcon />, label: "Jobs", path: "/jobs" },
  { icon: <EventIcon />, label: "Events", path: "/events" },
  { icon: <GroupIcon />, label: "Network", path: "/network" },
]

const Home = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [userProfile, setUserProfile] = useState(null)
  const [upcomingEvents, setUpcomingEvents] = useState([])
  const [featuredJobs, setFeaturedJobs] = useState([])
  const [networkStats, setNetworkStats] = useState({
    totalUsers: 0,
    upcomingEvents: 0,
    activeJobs: 0,
    activeMentorships: 0,
    connections: 0,
    pendingConnections: 0,
  })

  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"))
  const isMedium = useMediaQuery(theme.breakpoints.down("md"))

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)

        // Fetch user profile
        const profileResponse = await authService.getProfile()
        console.log("profileResponse")
        console.log(profileResponse)
        setUserProfile(profileResponse)

        // Fetch upcoming events
        const eventsResponse = await authService.getUpcomingEvents()
        console.log("eventsResponse")
        console.log(eventsResponse)
        setUpcomingEvents(eventsResponse)

        // Fetch featured jobs
        const jobsResponse = await authService.getAllJobs()
        console.log("jobsResponse")
        console.log(jobsResponse)
        setFeaturedJobs(jobsResponse.slice(0, 3)) // Show only 3 featured jobs

        // Fetch network statistics
        const statsResponse = await authService.getNetworkStats()
        console.log("statsResponse")
        console.log(statsResponse)
        setNetworkStats(statsResponse)
      } catch (err) {
        setError(err.message || "Failed to fetch data")
        console.error("Error fetching data:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    )
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    )
  }

  return (
    <Box sx={{ bgcolor: "#f5f7fa", minHeight: "100vh", py: 4 }}>
      <Container maxWidth="lg">
        <Grid container spacing={3}>
            {/* Profile Card */}
          <Grid item xs={12} md={4}>
            <Paper
              elevation={1}
              sx={{
                borderRadius: 2,
                overflow: "hidden",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                transition: "transform 0.2s, box-shadow 0.2s",
                "&:hover": {
                  boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
                },
              }}
            >
              <Box
                sx={{ 
                  p: 3,
                  textAlign: "center",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                  <Avatar
                    sx={{
                      width: 100,
                      height: 100,
                      mb: 2,
                    bgcolor: "primary.main",
                    fontSize: "2rem",
                    border: "4px solid",
                    borderColor: "background.paper",
                    boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                  }}
                >
                  {userProfile?.first_name?.[0] || <PersonIcon fontSize="large" />}
                  </Avatar>
                <Typography variant="h5" sx={{ fontWeight: 600, mb: 0.5 }}>
                  {userProfile?.first_name} {userProfile?.last_name}
                </Typography>
                <Typography
                  variant="body1"
                  color="text.secondary"
                  sx={{
                    mb: 2,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 0.5,
                  }}
                >
                  <BusinessIcon fontSize="small" />
                  {userProfile.experience[0]?.role} at {userProfile?.experience[0]?.company || "Complete your profile"}
                </Typography>
                <Typography
                  variant="body1"
                  color="text.secondary"
                  sx={{
                    mb: 2,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 0.5,
                  }}
                >
                  <SchoolIcon fontSize="small" />
                  {userProfile?.education[0]?.degree}
                  </Typography>
                <Typography
                  variant="body1"
                  color="text.secondary"
                  sx={{
                    mb: 2,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 0.5,
                  }}
                >
                  <BatchPredictionIcon fontSize="small" />
                  {userProfile?.education[0]?.year}
                  </Typography>
                <Box sx={{ display: "flex", gap: 1, mb: 2, width: "100%" }}>
                  <Button
                    variant="outlined"
                    startIcon={<EditIcon />}
                    fullWidth
                    component={RouterLink}
                    to="/profile"
                    onClick={(e) => e.stopPropagation()}
                    sx={{
                      borderRadius: 2,
                      py: 1,
                      transition: "all 0.2s",
                      "&:hover": {
                        transform: "translateY(-2px)",
                        boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                      },
                    }}
                  >
                    Edit Profile
                  </Button>
                  <Button
                    variant="contained"
                    startIcon={<ShareIcon />}
                    fullWidth
                    onClick={(e) => {
                      e.stopPropagation()
                      navigator.clipboard.writeText(window.location.origin + "/profile")
                    }}
                    sx={{
                      borderRadius: 2,
                      py: 1,
                      transition: "all 0.2s",
                      "&:hover": {
                        transform: "translateY(-2px)",
                        boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                      },
                    }}
                  >
                    Share
                  </Button>
                </Box>
                    </Box>
              <Divider />
              
              </Paper>
          </Grid>

          {/* Quick Actions Card */}
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={1}
              sx={{ 
                borderRadius: 2,
                height: "100%",
                transition: "transform 0.2s, box-shadow 0.2s",
                "&:hover": {
                  boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
                },
              }}
            >
              <Box sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2.5, pl: 1 }}>
                Quick Actions
              </Typography>
                <Grid container spacing={2}>
                {quickActions.map((action, index) => (
                    <Grid item xs={6} key={index}>
                  <Button
                        component={RouterLink}
                        to={action.path}
                    variant="outlined"
                        fullWidth
                    sx={{
                          height: "90px",
                          borderRadius: 2,
                          flexDirection: "column",
                          gap: 1,
                          textTransform: "none",
                          transition: "all 0.3s",
                          "&:hover": {
                            bgcolor: "primary.light",
                            color: "white",
                            transform: "translateY(-4px)",
                            boxShadow: "0 6px 12px rgba(0,0,0,0.15)",
                            "& .MuiSvgIcon-root": {
                              color: "white",
                              transform: "scale(1.2)",
                            },
                          },
                          "& .MuiSvgIcon-root": {
                            transition: "transform 0.3s",
                            fontSize: "1.8rem",
                      },
                    }}
                  >
                        {action.icon}
                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                          {action.label}
                      </Typography>
                  </Button>
                    </Grid>
                ))}
                </Grid>
              </Box>
            </Paper>
          </Grid>

          {/* Network Stats Card */}
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={1}
              sx={{ 
                borderRadius: 2,
                height: "100%",
                transition: "transform 0.2s, box-shadow 0.2s",
                "&:hover": {
                  boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
                },
              }}
            >
              <Box sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2.5, pl: 1 }}>
                  Network Stats
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        textAlign: "center",
                        bgcolor: "primary.light",
                        color: "white",
                        borderRadius: 2,
                        transition: "all 0.3s",
                        "&:hover": {
                          transform: "translateY(-4px)",
                          boxShadow: "0 6px 12px rgba(0,0,0,0.15)",
                        },
                      }}
                    >
                      <Typography variant="h4" sx={{ fontWeight: 600 }}>
                        {networkStats?.totalUsers || 0}
                      </Typography>
                      <Typography variant="body2" sx={{ mt: 0.5 }}>
                        Total Users
                      </Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6}>
                    <Paper
                    elevation={0}
                    sx={{ 
                        p: 2,
                        textAlign: "center",
                        bgcolor: "secondary.light",
                        color: "white",
                      borderRadius: 2,
                        transition: "all 0.3s",
                        "&:hover": {
                          transform: "translateY(-4px)",
                          boxShadow: "0 6px 12px rgba(0,0,0,0.15)",
                        },
                      }}
                    >
                      <Typography variant="h4" sx={{ fontWeight: 600 }}>
                        {networkStats?.connections || 0}
                      </Typography>
                      <Typography variant="body2" sx={{ mt: 0.5 }}>
                        Your Connections
                      </Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        textAlign: "center",
                        bgcolor: "success.light",
                        color: "white",
                        borderRadius: 2,
                        transition: "all 0.3s",
                        "&:hover": {
                          transform: "translateY(-4px)",
                          boxShadow: "0 6px 12px rgba(0,0,0,0.15)",
                        },
                      }}
                    >
                      <Typography variant="h4" sx={{ fontWeight: 600 }}>
                        {networkStats?.upcomingEvents || 0}
                            </Typography>
                      <Typography variant="body2" sx={{ mt: 0.5 }}>
                        Upcoming Events
                            </Typography>
                    </Paper>
                        </Grid>
                  <Grid item xs={6}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        textAlign: "center",
                        bgcolor: "info.light",
                        color: "white",
                        borderRadius: 2,
                        transition: "all 0.3s",
                        "&:hover": {
                          transform: "translateY(-4px)",
                          boxShadow: "0 6px 12px rgba(0,0,0,0.15)",
                        },
                      }}
                    >
                      <Typography variant="h4" sx={{ fontWeight: 600 }}>
                        {networkStats?.activeJobs || 0}
                      </Typography>
                      <Typography variant="body2" sx={{ mt: 0.5 }}>
                        Active Jobs
                          </Typography>
                    </Paper>
                        </Grid>
                      </Grid>
              </Box>
            </Paper>
          </Grid>

            {/* Featured Jobs */}
          <Grid item xs={12} md={8}>
            <Paper 
              elevation={1}
              sx={{ 
                borderRadius: 2,
                height: "100%",
                transition: "transform 0.2s, box-shadow 0.2s",
                "&:hover": {
                  boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
                },
              }}
            >
              <Box sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2.5, pl: 1 }}>
                  Featured Jobs
                </Typography>
                {featuredJobs.length > 0 ? (
                  <List sx={{ px: 1 }}>
                    {featuredJobs.map((job, index) => (
                      <React.Fragment key={index}>
                        <ListItem
                  component={RouterLink} 
                          to={`/jobs/${job.id}`}
                          disablePadding
                    sx={{ 
                            cursor: "pointer",
                      borderRadius: 2,
                            mb: 1,
                            p: 2,
                            transition: "all 0.2s",
                            "&:hover": {
                              bgcolor: "action.hover",
                              transform: "translateY(-2px)",
                              boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                            },
                          }}
                        >
                          <ListItemText
                            primary={
                              <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 0.5 }}>
                        {job.title}
                      </Typography>
                            }
                            secondary={
                              <Box sx={{ display: "flex", flexDirection: "column", gap: 0.5 }}>
                                <Typography
                                  variant="body2"
                                  color="text.secondary"
                                  sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 0.5,
                                  }}
                                >
                                  <BusinessIcon fontSize="small" />
                        {job.company}
                      </Typography>
                                <Typography
                                  variant="body2"
                                  color="text.secondary"
                                  sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 0.5,
                                  }}
                                >
                                  <LocationIcon fontSize="small" />
                                  {job.location} • {job.type}
                        </Typography>
                      </Box>
                            }
                          />
                        </ListItem>
                        {index < featuredJobs.length - 1 && <Divider sx={{ my: 1 }} />}
                      </React.Fragment>
                    ))}
                  </List>
                ) : (
                  <Box sx={{ p: 3, textAlign: "center" }}>
                    <Typography variant="body1" color="text.secondary">
                      No featured jobs available at the moment
                        </Typography>
                      </Box>
                )}
              </Box>
            </Paper>
          </Grid>

          {/* Upcoming Events */}
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={1}
              sx={{ 
                borderRadius: 2,
                height: "100%",
                transition: "transform 0.2s, box-shadow 0.2s",
                "&:hover": {
                  boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
                },
              }}
            >
              <Box sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2.5, pl: 1 }}>
                  Upcoming Events
              </Typography>
                {upcomingEvents.length > 0 ? (
                  <List sx={{ px: 1 }}>
                    {upcomingEvents.map((event, index) => (
                      <React.Fragment key={index}>
                        <ListItem
                component={RouterLink}
                          to={`/events/${event.id}`}
                          disablePadding
                sx={{ 
                            cursor: "pointer",
                            borderRadius: 2,
                            mb: 1,
                            p: 2,
                            transition: "all 0.2s",
                            "&:hover": {
                              bgcolor: "action.hover",
                              transform: "translateY(-2px)",
                              boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                  },
                }}
              >
                          <ListItemText
                            primary={
                              <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 0.5 }}>
                                {event.title}
                              </Typography>
                            }
                            secondary={
                              <Box sx={{ display: "flex", flexDirection: "column", gap: 0.5 }}>
                                <Typography
                                  variant="body2"
                                  color="text.secondary"
              sx={{ 
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 0.5,
                                  }}
                                >
                                  <CalendarIcon fontSize="small" />
                                  {new Date(event.date).toLocaleDateString()}
              </Typography>
                                <Typography
                                  variant="body2"
                                  color="text.secondary"
                                  sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 0.5,
                                  }}
                                >
                                  <LocationIcon fontSize="small" />
                                  {event.location}
                  </Typography>
                </Box>
                            }
                          />
                        </ListItem>
                        {index < upcomingEvents.length - 1 && <Divider sx={{ my: 1 }} />}
                      </React.Fragment>
                    ))}
                  </List>
                ) : (
                  <Box sx={{ p: 3, textAlign: "center" }}>
                    <Typography variant="body1" color="text.secondary">
                      No upcoming events at the moment
                  </Typography>
                </Box>
                )}
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Box>
  )
}

export default Home

