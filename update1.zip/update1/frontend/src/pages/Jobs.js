import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Card,
  CardContent,
  IconButton,
  InputAdornment,
  Chip,
  MenuItem,
  Avatar,
  Paper,
  FormControlLabel,
  Checkbox,
  DialogContentText,
  Snackbar,
  Alert
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import WorkIcon from '@mui/icons-material/Work';
import BusinessIcon from '@mui/icons-material/Business';
import CloseIcon from '@mui/icons-material/Close';
import FilterListIcon from '@mui/icons-material/FilterList';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { formatDistanceToNow } from 'date-fns';
import { jobService } from '../services/api';
import { useAuth } from '../context/AuthContext';

const Jobs = () => {
  const { user } = useAuth();
  const [openPostJob, setOpenPostJob] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    remote: false,
    fullTime: false,
    partTime: false,
    internship: false,
    experience: 'all',
    department: 'all',
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');

  // Helper function to format batch.
  // If batch contains a dash, it returns only the part after the dash.
  const formatBatch = (batch) => {
    if (!batch) return 'Not specified';
    if (batch.includes('-')) {
      return batch.split('-')[1].trim();
    }
    return batch;
  };

  // Updated Form state
  const [jobForm, setJobForm] = useState({
    title: '',
    company: '',
    location: '',
    type: 'Full-time',
    remote: false,
    department: 'All',
    experience: '',
    description: '',
    requirements: '',
    salary: '',
    applicationLink: '',
    deadline: '',
  });

  const [formErrors, setFormErrors] = useState({
    title: '',
    company: '',
    location: '',
    description: '',
    requirements: '',
    salary: '',
    applicationLink: '',
  });

  // Jobs data from backend
  const [jobsList, setJobsList] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        const jobs = await jobService.getAllJobs();
        console.log('Fetched jobs:', jobs);
        // Transform backend data to match the UI structure
        const transformedJobs = jobs.map(job => ({
          id: job.id,
          title: job.title,
          company: job.company,
          location: job.location,
          type: job.type,
          remote: job.remote === 1, // Convert 0/1 to boolean
          department: job.department,
          experience: job.experience,
          salary: job.salary,
          deadline: job.deadline,
          applicationLink: job.application_link,
          description: job.description,
          requirements: job.requirements,
      postedBy: {
            name: `${job.first_name} ${job.last_name}`,
            role: job.role, // Role from users table
            batch: job.year || 'Not specified', // Use job.year as batch
        avatar: '#1a237e',
            designation: 'Alumni',
          },
          postedAt: new Date(job.created_at),
        }));
        console.log('Transformed jobs:', transformedJobs);
        setJobsList(transformedJobs);
      } catch (error) {
        console.error('Error fetching jobs:', error);
        setError('Failed to load jobs. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  const validateForm = () => {
    const errors = {};
    let isValid = true;

    if (!jobForm.title.trim()) {
      errors.title = 'Job title is required';
      isValid = false;
    }

    if (!jobForm.company.trim()) {
      errors.company = 'Company name is required';
      isValid = false;
    }

    if (!jobForm.location.trim()) {
      errors.location = 'Location is required';
      isValid = false;
    }

    if (!jobForm.description.trim()) {
      errors.description = 'Job description is required';
      isValid = false;
    }

    if (!jobForm.requirements.trim()) {
      errors.requirements = 'Job requirements are required';
      isValid = false;
    }

    if (!jobForm.salary.trim()) {
      errors.salary = 'Salary range is required';
      isValid = false;
    }

    if (!jobForm.applicationLink.trim()) {
      errors.applicationLink = 'Application link is required';
      isValid = false;
    }

    setFormErrors(errors);
    return isValid;
  };

  const handlePostJob = async () => {
    try {
      if (!validateForm()) {
        return;
      }

      const jobData = {
        title: jobForm.title,
        company: jobForm.company,
        location: jobForm.location,
        type: jobForm.type,
        remote: jobForm.remote ? 1 : 0,
        department: jobForm.department,
        experience: jobForm.experience,
        description: jobForm.description,
        requirements: jobForm.requirements,
        salary: jobForm.salary,
        application_link: jobForm.applicationLink,
        deadline: jobForm.deadline,
      };

      console.log('Submitting job data:', jobData);
      const newJob = await jobService.postJob(jobData);
      console.log('Posted new job:', newJob);
      
      // Transform the new job to match UI structure
      const transformedJob = {
        id: newJob.jobId,
        title: jobForm.title,
        company: jobForm.company,
        location: jobForm.location,
        type: jobForm.type,
        remote: newJob.remote === 1,
        department: jobForm.department,
        experience: jobForm.experience,
        salary: jobForm.salary,
        deadline: jobForm.deadline,
        applicationLink: jobForm.applicationLink,
        description: jobForm.description,
        requirements: jobForm.requirements,
      postedBy: {
          name: `${user.first_name} ${user.last_name}`,
          role: user.role,
          batch: user.year || user.batch || 'Not specified',
        avatar: '#1a237e',
          designation: user.designation || 'Alumni',
      },
      postedAt: new Date(),
    };
    
      setJobsList([transformedJob, ...jobsList]);
    setOpenPostJob(false);
    setJobForm({
      title: '',
      company: '',
      location: '',
      type: 'Full-time',
      remote: false,
        department: 'All',
        experience: '',
      description: '',
      requirements: '',
        salary: '',
      applicationLink: '',
      deadline: '',
    });
      setFormErrors({});
      setSuccessMessage('Job posted successfully!');
      setSnackbarSeverity('success');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error posting job:', error);
      if (error.response?.data?.message) {
        setError(error.response.data.message);
      } else {
        setError('Failed to post job. Please try again later.');
      }
      setSuccessMessage('Failed to post job. Please try again.');
      setSnackbarSeverity('error');
      setOpenSnackbar(true);
    }
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  const filteredJobs = jobsList.filter(job => {
    const matchesSearch = 
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRemote = !filters.remote || job.remote;
    const matchesType = 
      (!filters.fullTime && !filters.partTime && !filters.internship) ||
      (filters.fullTime && job.type === 'Full-time') ||
      (filters.partTime && job.type === 'Part-time') ||
      (filters.internship && job.type === 'Internship');
    
    const matchesExperience = filters.experience === 'all' || job.experience.includes(filters.experience);
    const matchesDepartment = filters.department === 'all' || job.department === filters.department;

    return matchesSearch && matchesRemote && matchesType && matchesExperience && matchesDepartment;
  });

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography>Loading jobs...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  // Keep the exact same JSX structure as before
  return (
    <Box sx={{ bgcolor: '#f5f7fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="lg">
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 600, color: '#1a237e', mb: 1 }}>
              Job Board
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Find and post job opportunities within the JNTUA alumni network
            </Typography>
          </Box>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setOpenPostJob(true)}
            sx={{
              bgcolor: '#1a237e',
              '&:hover': { bgcolor: '#0d1b60' },
              px: 3,
              py: 1.5,
              borderRadius: 2,
            }}
          >
            Post a Job
          </Button>
        </Box>

        {/* Search and Filters */}
        <Paper 
          elevation={0}
          sx={{ 
            p: 3,
            mb: 4,
            borderRadius: 2,
            border: '1px solid',
            borderColor: 'divider',
          }}
        >
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search jobs by title, company, or location..."
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon color="action" />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    bgcolor: 'white',
                  },
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2" sx={{ mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
                <FilterListIcon /> Filters
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.remote}
                      onChange={(e) => setFilters({ ...filters, remote: e.target.checked })}
                    />
                  }
                  label="Remote"
                />
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.fullTime}
                      onChange={(e) => setFilters({ ...filters, fullTime: e.target.checked })}
                    />
                  }
                  label="Full-time"
                />
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.partTime}
                      onChange={(e) => setFilters({ ...filters, partTime: e.target.checked })}
                    />
                  }
                  label="Part-time"
                />
                <FormControlLabel
                  control={
                    <Checkbox 
                      checked={filters.internship}
                      onChange={(e) => setFilters({ ...filters, internship: e.target.checked })}
                    />
                  }
                  label="Internship"
                />
                <TextField
                  select
                  size="small"
                  value={filters.experience}
                  onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
                  sx={{ minWidth: 150 }}
                >
                  <MenuItem value="all">All Experience</MenuItem>
                  <MenuItem value="0-1 year">0-1 year</MenuItem>
                  <MenuItem value="1-3 years">1-3 years</MenuItem>
                  <MenuItem value="3-5 years">3-5 years</MenuItem>
                  <MenuItem value="5+ years">5+ years</MenuItem>
                </TextField>
                <TextField
                  select
                  size="small"
                  value={filters.department}
                  onChange={(e) => setFilters({ ...filters, department: e.target.value })}
                  sx={{ minWidth: 150 }}
                >
                  <MenuItem value="all">All Departments</MenuItem>
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Box>
            </Grid>
          </Grid>
        </Paper>

        {/* Jobs List */}
        <Grid container spacing={3}>
          {filteredJobs.map((job) => (
            <Grid item xs={12} key={job.id}>
              <Card 
                elevation={0}
                sx={{ 
                  borderRadius: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': {
                    borderColor: 'primary.main',
                    boxShadow: 1,
                  },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={8}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                        <Avatar 
                          sx={{ 
                            width: 48,
                            height: 48,
                            bgcolor: job.postedBy.avatar,
                            fontSize: '1.5rem'
                          }}
                        >
                          {job.postedBy.name[0]}
                        </Avatar>
                        <Box>
                          <Typography variant="h6" sx={{ fontWeight: 600 }}>
                            {job.title}
                          </Typography>
                          <Typography color="text.secondary">
                            {job.company} • {job.postedBy.designation} • {job.postedBy.batch} batch
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Posted by: {job.postedBy.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Role: {job.postedBy.role} • Batch: {formatBatch(job.postedBy.batch)}
                          </Typography>
                        </Box>
                      </Box>
                      <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <LocationOnIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            {job.location}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <WorkIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            {job.type}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <BusinessIcon color="action" />
                          <Typography variant="body2" color="text.secondary">
                            {job.department}
                          </Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        {job.description}
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        <Chip 
                          label={job.experience}
                          size="small"
                          sx={{ bgcolor: '#e3f2fd', color: '#1976d2' }}
                        />
                        <Chip 
                          label={job.remote ? "Remote" : "Work from Office"}
                          size="small"
                          sx={{ 
                            bgcolor: job.remote ? '#e8f5e9' : '#fff3e0',
                            color: job.remote ? '#2e7d32' : '#f57c00'
                          }}
                        />
                        {job.salary && (
                          <Chip 
                            label={job.salary}
                            size="small"
                            sx={{ bgcolor: '#fff3e0', color: '#f57c00' }}
                          />
                        )}
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, height: '100%', justifyContent: 'center' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: 'text.secondary' }}>
                          <AccessTimeIcon sx={{ fontSize: 20 }} />
                          <Typography variant="body2">
                            Posted {formatDistanceToNow(job.postedAt, { addSuffix: true })}
                          </Typography>
                        </Box>
                        {job.deadline && (
                          <Typography variant="body2" color="error">
                            Deadline: {new Date(job.deadline).toLocaleDateString()}
                          </Typography>
                        )}
                        <Button
                          variant="contained"
                          fullWidth
                          href={job.applicationLink}
                          target="_blank"
                          sx={{
                            bgcolor: '#1a237e',
                            '&:hover': { bgcolor: '#0d1b60' },
                          }}
                        >
                          Apply Now
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Post Job Dialog */}
        <Dialog 
          open={openPostJob} 
          onClose={() => setOpenPostJob(false)}
          maxWidth="md"
          fullWidth
        >
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              Post a Job
              <IconButton onClick={() => setOpenPostJob(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Job Title"
                  value={jobForm.title}
                  onChange={(e) => setJobForm({ ...jobForm, title: e.target.value })}
                  error={!!formErrors.title}
                  helperText={formErrors.title}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Company"
                  value={jobForm.company}
                  onChange={(e) => setJobForm({ ...jobForm, company: e.target.value })}
                  error={!!formErrors.company}
                  helperText={formErrors.company}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Location"
                  value={jobForm.location}
                  onChange={(e) => setJobForm({ ...jobForm, location: e.target.value })}
                  error={!!formErrors.location}
                  helperText={formErrors.location}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Job Type"
                  value={jobForm.type}
                  onChange={(e) => setJobForm({ ...jobForm, type: e.target.value })}
                >
                  <MenuItem value="Full-time">Full-time</MenuItem>
                  <MenuItem value="Part-time">Part-time</MenuItem>
                  <MenuItem value="Contract">Contract</MenuItem>
                  <MenuItem value="Internship">Internship</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Department"
                  value={jobForm.department}
                  onChange={(e) => setJobForm({ ...jobForm, department: e.target.value })}
                >
                  <MenuItem value="All">All Departments</MenuItem>
                  <MenuItem value="CSE">CSE</MenuItem>
                  <MenuItem value="ECE">ECE</MenuItem>
                  <MenuItem value="MECH">MECH</MenuItem>
                  <MenuItem value="CIVIL">CIVIL</MenuItem>
                  <MenuItem value="EEE">EEE</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select
                  fullWidth
                  label="Experience Required"
                  value={jobForm.experience}
                  onChange={(e) => setJobForm({ ...jobForm, experience: e.target.value })}
                >
                  <MenuItem value="0-1 year">0-1 year</MenuItem>
                  <MenuItem value="1-3 years">1-3 years</MenuItem>
                  <MenuItem value="3-5 years">3-5 years</MenuItem>
                  <MenuItem value="5+ years">5+ years</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Salary Range"
                  value={jobForm.salary}
                  onChange={(e) => setJobForm({ ...jobForm, salary: e.target.value })}
                  error={!!formErrors.salary}
                  helperText={formErrors.salary}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Job Description"
                  value={jobForm.description}
                  onChange={(e) => setJobForm({ ...jobForm, description: e.target.value })}
                  error={!!formErrors.description}
                  helperText={formErrors.description}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Requirements"
                  value={jobForm.requirements}
                  onChange={(e) => setJobForm({ ...jobForm, requirements: e.target.value })}
                  error={!!formErrors.requirements}
                  helperText={formErrors.requirements}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Application Link"
                  value={jobForm.applicationLink}
                  onChange={(e) => setJobForm({ ...jobForm, applicationLink: e.target.value })}
                  error={!!formErrors.applicationLink}
                  helperText={formErrors.applicationLink}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  type="date"
                  label="Application Deadline"
                  value={jobForm.deadline}
                  onChange={(e) => setJobForm({ ...jobForm, deadline: e.target.value })}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={jobForm.remote}
                      onChange={(e) => setJobForm({ ...jobForm, remote: e.target.checked })}
                    />
                  }
                  label="Remote Position"
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={() => setOpenPostJob(false)}>
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handlePostJob}
              sx={{
                bgcolor: '#1a237e',
                '&:hover': { bgcolor: '#0d1b60' },
              }}
            >
              Post Job
            </Button>
          </DialogActions>
        </Dialog>

        {/* Add Snackbar at the end of the Container */}
        <Snackbar 
          open={openSnackbar} 
          autoHideDuration={6000} 
          onClose={handleCloseSnackbar}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert 
            onClose={handleCloseSnackbar} 
            severity={snackbarSeverity}
            sx={{ width: '100%' }}
          >
            {successMessage}
          </Alert>
        </Snackbar>
      </Container>
    </Box>
  );
};

export default Jobs; 
