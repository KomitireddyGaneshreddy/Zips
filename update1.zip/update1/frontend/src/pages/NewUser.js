import React, { useState } from 'react';
import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Grid,
  Alert,
  Snackbar,
  Stepper,
  Step,
  StepLabel,
  MenuItem,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { School } from '@mui/icons-material';
import { authService } from '../services/api';
import { useAuth } from '../context/AuthContext';

const steps = ['Personal Information', 'Contact Details', 'Password Setup'];

const NewUser = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [activeStep, setActiveStep] = useState(0);
  const [showSnackbar, setShowSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    surname: '',
    firstName: '',
    lastName:'',
    rollNumber: '',
    dateOfBirth: '',
    previousPhone: '',
    currentPhone: '',
    uniqueKey: '',
    newPassword: '',
    confirmPassword: '',
    role:'',
    email: '',
    department: 'CSE'
  });

  const [errors, setErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    switch (step) {
      case 0: // Personal Information
        if (!formData.surname) newErrors.surname = 'Surname is required';
        if (!formData.firstName) newErrors.firstName = 'First Name is required';
        if (!formData.lastName) newErrors.lastName = 'Last Name is required';
        if (!formData.rollNumber) newErrors.rollNumber = 'Roll Number is required';
        if (!formData.dateOfBirth) newErrors.dateOfBirth = 'Date of Birth is required';
        if (!formData.email) newErrors.email = 'Email is required';
        if (!formData.department) newErrors.department = 'Department is required';
        break;
      case 1: // Contact Details
        if (!formData.previousPhone) newErrors.previousPhone = 'Previous Phone Number is required';
        if (!formData.currentPhone) newErrors.currentPhone = 'Current Phone Number is required';
        break;
      case 2: // Password Setup
        if (!formData.uniqueKey) newErrors.uniqueKey = 'Unique Key is required';
        if (!formData.newPassword) newErrors.newPassword = 'New Password is required';
        if (!formData.role) newErrors.role = 'Student or Alumni';
        if (!formData.confirmPassword) newErrors.confirmPassword = 'Confirm Password is required';
        if (formData.newPassword !== formData.confirmPassword) {
          newErrors.confirmPassword = 'Passwords do not match';
        }
        break;
        default:
            break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateStep(activeStep)) {
      setLoading(true);
      try {
        // Validate role value
        const validRoles = ['student', 'alumni', 'admin'];
        if (!validRoles.includes(formData.role.toLowerCase())) {
          throw new Error('Invalid role selected');
        }

        // Transform form data to match backend expectations
        const registrationData = {
          roll_number: formData.rollNumber,
          first_name: formData.firstName,
          surname: formData.surname,
          last_name: formData.lastName,
          date_of_birth: formData.dateOfBirth,
          current_phone: formData.currentPhone,
          previous_phone: formData.previousPhone,
          unique_key: formData.uniqueKey,
          password: formData.newPassword,
          role: formData.role.toLowerCase(),
          email: formData.email,
          department: formData.department
        };

        console.log('Sending registration data:', registrationData);

        // Register the user
        await authService.register(registrationData);

        // After successful registration, log the user in
        const loginResponse = await authService.login({
          email: formData.email,
          password: formData.newPassword
        });

        // Store user data and token
        login(loginResponse);
        
        setSnackbarMessage('Registration successful!');
        setSnackbarSeverity('success');
        setShowSnackbar(true);
        
        // Navigate to dashboard after successful registration
        navigate('/dashboard');
      } catch (error) {
        console.error('Registration error:', error);
        let errorMessage = 'Registration failed. ';
        
        if (error.response?.status === 400) {
          if (error.response.data.message === 'Invalid roll number or unique key') {
            errorMessage = 'The roll number and unique key do not match. Please check your credentials or contact the admin for assistance.';
          } else if (error.response.data.message === 'User with this email or roll number already exists') {
            errorMessage = 'A user with this email or roll number already exists.';
          } else {
            errorMessage += error.response.data.message || 'Please check your input and try again.';
          }
        } else {
          errorMessage += 'Please try again later.';
        }
        
        setSnackbarMessage(errorMessage);
        setSnackbarSeverity('error');
        setShowSnackbar(true);
      } finally {
        setLoading(false);
      }
    }
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Surname"
                name="surname"
                value={formData.surname}
                onChange={handleInputChange}
                error={!!errors.surname}
                helperText={errors.surname}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="First Name"
                name="firstName"
                value={formData.firstName}
                onChange={handleInputChange}
                error={!!errors.firstName}
                helperText={errors.firstName}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Last Name"
                name="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                error={!!errors.lastName}
                helperText={errors.lastName}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Roll Number"
                name="rollNumber"
                value={formData.rollNumber}
                onChange={handleInputChange}
                error={!!errors.rollNumber}
                helperText={errors.rollNumber}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Date of Birth"
                name="dateOfBirth"
                type="date"
                value={formData.dateOfBirth}
                onChange={handleInputChange}
                error={!!errors.dateOfBirth}
                helperText={errors.dateOfBirth}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                error={!!errors.email}
                helperText={errors.email}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                select
                label="Department"
                name="department"
                value={formData.department}
                onChange={handleInputChange}
                error={!!errors.department}
                helperText={errors.department}
              >
                <MenuItem value="CSE">CSE</MenuItem>
                <MenuItem value="ECE">ECE</MenuItem>
                <MenuItem value="EEE">EEE</MenuItem>
                <MenuItem value="MECH">MECH</MenuItem>
                <MenuItem value="CIVIL">CIVIL</MenuItem>
              </TextField>
            </Grid>
          </Grid>
        );
      case 1:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Previous Phone Number"
                name="previousPhone"
                value={formData.previousPhone}
                onChange={handleInputChange}
                error={!!errors.previousPhone}
                helperText={errors.previousPhone}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Current Phone Number"
                name="currentPhone"
                value={formData.currentPhone}
                onChange={handleInputChange}
                error={!!errors.currentPhone}
                helperText={errors.currentPhone}
              />
            </Grid>
          </Grid>
        );
      case 2:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="Unique Key"
                name="uniqueKey"
                value={formData.uniqueKey}
                onChange={handleInputChange}
                error={!!errors.uniqueKey}
                helperText={errors.uniqueKey}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="New Password"
                name="newPassword"
                type="password"
                value={formData.newPassword}
                onChange={handleInputChange}
                error={!!errors.newPassword}
                helperText={errors.newPassword}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                label="Confirm Password"
                name="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                error={!!errors.confirmPassword}
                helperText={errors.confirmPassword}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                select
                label="Role"
                name="role"
                value={formData.role}
                onChange={handleInputChange}
                error={!!errors.role}
                helperText={errors.role}
              >
                <MenuItem value="student">Student</MenuItem>
                <MenuItem value="alumni">Alumni</MenuItem>
                <MenuItem value="admin">Admin</MenuItem>
              </TextField>
            </Grid>
          </Grid>
        );
      default:
        return null;
    }
  };

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="md">
        <Paper elevation={0} sx={{ p: 4, borderRadius: 2, border: '1px solid', borderColor: 'divider' }}>
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <School sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
            <Typography variant="h4" sx={{ fontWeight: 600, color: 'primary.main' }}>
              Tell us About You
            </Typography>
            <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>
              Please fill in your details to create your account
            </Typography>
          </Box>

          <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>

          <form onSubmit={handleSubmit}>
            {renderStepContent(activeStep)}
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
              {activeStep !== 0 && (
                <Button onClick={handleBack}>
                  Back
                </Button>
              )}
              <Box sx={{ flex: '1 1 auto' }} />
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  type="submit"
                  disabled={loading}
                >
                  {loading ? 'Registering...' : 'Register'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                >
                  Next
                </Button>
              )}
            </Box>
          </form>
        </Paper>
      </Container>

      <Snackbar
        open={showSnackbar}
        autoHideDuration={6000}
        onClose={() => setShowSnackbar(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={() => setShowSnackbar(false)}
          severity={snackbarSeverity}
          sx={{ width: '100%' }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default NewUser; 