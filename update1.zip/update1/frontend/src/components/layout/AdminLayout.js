import React from 'react';
import { Box, Drawer, List, ListItem, ListItemIcon, ListItemText, Typography, IconButton } from '@mui/material';
import {
  Dashboard as DashboardIcon,
  People as UserIcon,
  Work as JobIcon,
  Event as EventIcon,
  Group as MentorshipIcon,
  Hub as NetworkIcon,
  Settings as SettingsIcon,
  Logout as LogoutIcon,
  Close as CloseIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const drawerWidth = 280;

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/adminDashboard', color: '#3b82f6' },
  { text: 'User Management', icon: <UserIcon />, path: '/admin/users' },
  { text: 'Job Management', icon: <JobIcon />, path: '/admin/jobs' },
  { text: 'Event Management', icon: <EventIcon />, path: '/admin/events' },
  { text: 'Mentorship', icon: <MentorshipIcon />, path: '/admin/mentorship', color: '#3b82f6' },
  { text: 'Alumni Network', icon: <NetworkIcon />, path: '/admin/network' },
  { text: 'Settings', icon: <SettingsIcon />, path: '/admin/settings' },
];

const AdminLayout = ({ children }) => {
  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <Box sx={{ display: 'flex' }}>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
            borderRight: '1px solid rgba(0, 0, 0, 0.12)',
          },
        }}
      >
        <Box sx={{ p: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant="h6" sx={{ fontWeight: 600, color: '#1a237e', display: 'flex', alignItems: 'center', gap: 1 }}>
            <NetworkIcon /> Alumni Admin
          </Typography>
          <IconButton size="small">
            <CloseIcon />
          </IconButton>
        </Box>

        <List sx={{ mt: 2 }}>
          {menuItems.map((item) => (
            <ListItem
              button
              key={item.text}
              onClick={() => navigate(item.path)}
              sx={{
                py: 1.5,
                px: 2,
                '&:hover': {
                  backgroundColor: 'rgba(59, 130, 246, 0.08)',
                },
              }}
            >
              <ListItemIcon sx={{ color: item.color || 'inherit', minWidth: 40 }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText 
                primary={item.text} 
                sx={{
                  '& .MuiTypography-root': {
                    fontWeight: 500,
                  },
                }}
              />
            </ListItem>
          ))}
        </List>

        <Box sx={{ mt: 'auto', mb: 2 }}>
          <ListItem
            button
            onClick={handleLogout}
            sx={{
              py: 1.5,
              px: 2,
              color: '#3b82f6',
              '&:hover': {
                backgroundColor: 'rgba(59, 130, 246, 0.08)',
              },
            }}
          >
            <ListItemIcon sx={{ color: 'inherit', minWidth: 40 }}>
              <LogoutIcon />
            </ListItemIcon>
            <ListItemText 
              primary="Log out" 
              sx={{
                '& .MuiTypography-root': {
                  fontWeight: 500,
                  color: '#3b82f6',
                },
              }}
            />
          </ListItem>
        </Box>
      </Drawer>

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          bgcolor: '#f8fafc',
          minHeight: '100vh',
        }}
      >
        {children}
      </Box>
    </Box>
  );
};

export default AdminLayout; 