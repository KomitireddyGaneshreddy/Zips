import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const AdminRoute = ({ children }) => {
  const { user } = useAuth();

  // Check if user is logged in and has admin role
  if (!user || user.role !== 'admin') {
    // Redirect to home if not admin
    return <Navigate to="/home" replace />;
  }

  return children;
};

export default AdminRoute; 