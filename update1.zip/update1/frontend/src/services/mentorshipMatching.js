// Mentorship matching algorithm service
const calculateCompatibilityScore = (mentor, mentee) => {
  let score = 0;
  
  // Field/Topic match (highest weight)
  if (mentor.field === mentee.preferredField) {
    score += 40;
  } else if (mentor.field.includes(mentee.preferredField) || mentee.preferredField.includes(mentor.field)) {
    score += 20;
  }

  // Experience level match
  const experienceGap = Math.abs(mentor.yearsOfExperience - mentee.yearsOfExperience);
  if (experienceGap <= 2) {
    score += 10;
  } else if (experienceGap <= 5) {
    score += 5;
  }

  // Skills overlap
  const commonSkills = mentor.skills.filter(skill => mentee.interestedSkills.includes(skill));
  score += commonSkills.length * 5;

  // Department match
  if (mentor.department === mentee.department) {
    score += 15;
  }

  // Availability match
  const availabilityOverlap = mentor.availability.filter(slot => 
    mentee.availability.includes(slot)
  ).length;
  score += availabilityOverlap * 3;

  // Goals alignment
  const goalMatch = mentor.areasOfExpertise.some(area => 
    mentee.learningGoals.includes(area)
  );
  if (goalMatch) {
    score += 20;
  }

  return score;
};

const findOptimalMatches = (mentors, mentees) => {
  const matches = [];
  const availableMentors = [...mentors];
  const availableMentees = [...mentees];

  // Calculate compatibility scores for all possible pairs
  const compatibilityMatrix = availableMentees.map(mentee => 
    availableMentors.map(mentor => ({
      mentor,
      mentee,
      score: calculateCompatibilityScore(mentor, mentee)
    }))
  ).flat();

  // Sort pairs by compatibility score
  compatibilityMatrix.sort((a, b) => b.score - a.score);

  // Assign mentees to mentors based on highest compatibility and availability
  for (const match of compatibilityMatrix) {
    const { mentor, mentee, score } = match;
    
    // Check if mentor and mentee are still available
    if (availableMentors.includes(mentor) && availableMentees.includes(mentee)) {
      // Check if mentor hasn't reached their maximum mentees
      const mentorCurrentMentees = matches.filter(m => m.mentor.id === mentor.id).length;
      
      if (mentorCurrentMentees < mentor.maxMentees && score >= 50) { // Minimum compatibility threshold
        matches.push({
          mentor,
          mentee,
          compatibilityScore: score,
          matchDate: new Date()
        });

        // Remove matched mentee from available pool
        const menteeIndex = availableMentees.indexOf(mentee);
        if (menteeIndex > -1) {
          availableMentees.splice(menteeIndex, 1);
        }

        // Remove mentor if they've reached max mentees
        if (mentorCurrentMentees + 1 >= mentor.maxMentees) {
          const mentorIndex = availableMentors.indexOf(mentor);
          if (mentorIndex > -1) {
            availableMentors.splice(mentorIndex, 1);
          }
        }
      }
    }
  }

  return matches;
};

const suggestMentorsForMentee = (mentee, mentors, limit = 5) => {
  const suggestions = mentors.map(mentor => ({
    mentor,
    score: calculateCompatibilityScore(mentor, mentee)
  }));

  suggestions.sort((a, b) => b.score - a.score);
  return suggestions.slice(0, limit);
};

export {
  calculateCompatibilityScore,
  findOptimalMatches,
  suggestMentorsForMentee
}; 