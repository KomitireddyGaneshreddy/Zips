import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5001/api';

// Create axios instance with default config
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests if it exists
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Helper function to handle API responses
const handleResponse = async (response) => {
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Something went wrong');
  }
  return response.json();
};

// Auth services
export const authService = {
  login: async (credentials) => {
    try {
      const response = await api.post('/auth/login', credentials);
      const { token, user } = response.data;
      
      // Store the token
      localStorage.setItem('token', token);
      
      // Return user data with role
      return {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.name,
      };
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Login failed');
    }
  },

  register: async (userData) => {
    const response = await api.post('/auth/register', userData);
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    return response.data;
  },

  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },

  changePassword: async (passwordData) => {
    const response = await api.put('/users/change-password', passwordData);
    return response.data;
  },

  deleteAccount: async () => {
    const response = await api.delete('/users/account');
    return response.data;
  },

  // Profile methods
  getProfile: async () => {
    const response = await api.get('/users/profile');
    return response.data;
  },

  updateProfile: async (profileData) => {
    const response = await api.put('/users/profile', profileData);
    return response.data;
  },

  // Event methods
  getUpcomingEvents: async () => {
    const response = await api.get('/events/upcoming');
    return response.data;
  },

  getAllEvents: async () => {
    const response = await api.get('/events');
    return response.data;
  },

  getEventById: async (id) => {
    const response = await api.get(`/events/${id}`);
    return response.data;
  },

  createEvent: async (eventData) => {
    const response = await api.post('/events', eventData);
    return response.data;
  },

  updateEvent: async (id, eventData) => {
    const response = await api.put(`/events/${id}`, eventData);
    return response.data;
  },

  deleteEvent: async (id) => {
    const response = await api.delete(`/events/${id}`);
    return response.data;
  },

  // New methods for home page data
  getAllJobs: async () => {
    const response = await api.get('/jobs');
    return response.data;
  },

  getNetworkStats: async () => {
    const response = await api.get('/users/network-stats');
    return response.data;
  },

  getDiscoverAlumni: async (filters) => {
    const params = new URLSearchParams(filters);
    const response = await api.get(`/users/discover?${params}`);
    return response.data;
  },

  getConnectedAlumni: async () => {
    const response = await api.get('/users/connected');
    return response.data;
  },

  connectWithAlumni: async (alumniId) => {
    const response = await api.post('/users/connect', { connectedUserId: alumniId });
    return response.data;
  },

  getPendingRequests: async () => {
    const response = await api.get('/users/pending-requests');
    return response.data;
  },

  handleConnectionRequest: async (connectionId, action) => {
    const response = await api.post('/users/handle-connection', { connectionId, action });
    return response.data;
  },

  getSentRequests: async () => {
    try {
      const response = await api.get('/users/sent-requests');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  revokeConnectionRequest: async (connectionId) => {
    try {
      const response = await api.post('/users/revoke-connection', { connectionId });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getAllUsers: async () => {
    try {
      const response = await api.get('/users');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  deleteUser: async (userId) => {
    try {
      const response = await api.delete(`/users/${userId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  updateUniqueKey: async (userId, uniqueKey) => {
    try {
      const response = await api.put(`/users/${userId}/unique-key`, { unique_key: uniqueKey });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Credential methods
  getAllCredentials: async () => {
    try {
      const response = await api.get('/users/credentials');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getExistingCredentials: async () => {
    try {
      const response = await api.get('/users/existing-credentials');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  createUserCredential: async (credentialData) => {
    try {
      const response = await api.post('/users/credentials', credentialData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  deleteCredential: async (id) => {
    try {
      const response = await api.delete(`/users/credentials/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  updateCredential: async (id, credentialData) => {
    try {
      const response = await api.put(`/users/credentials/${id}`, credentialData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  verifyUserCredential: async (credentialData) => {
    try {
      const response = await api.post('/users/credentials/verify', credentialData);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

// Job services
export const jobService = {
  getAllJobs: async () => {
    const response = await api.get('/jobs');
    return response.data;
  },

  postJob: async (jobData) => {
    const response = await api.post('/jobs', jobData);
    return response.data;
  },

  getJobById: async (jobId) => {
    const response = await api.get(`/jobs/${jobId}`);
    return response.data;
  },

  updateJob: async (jobId, jobData) => {
    const response = await api.put(`/jobs/${jobId}`, jobData);
    return response.data;
  },

  deleteJob: async (jobId) => {
    const response = await api.delete(`/jobs/${jobId}`);
    return response.data;
  },

  // New method to check if user can delete a job
  canDeleteJob: (job) => {
    const user = JSON.parse(localStorage.getItem('user'));
    return user && job.posted_by === user.id;
  }
};

// Event services
export const eventService = {
  getAllEvents: async () => {
    const response = await api.get('/events');
    return response.data;
  },

  getEventById: async (id) => {
    const response = await api.get(`/events/${id}`);
    return response.data;
  },

  postEvent: async (eventData) => {
    const response = await api.post('/events', eventData);
    return response.data;
  },

  updateEvent: async (id, eventData) => {
    const response = await api.put(`/events/${id}`, eventData);
    return response.data;
  },

  deleteEvent: async (id) => {
    const response = await api.delete(`/events/${id}`);
    return response.data;
  },

  // New method to check if user can delete an event
  canDeleteEvent: (event) => {
    const user = JSON.parse(localStorage.getItem('user'));
    return user && event.created_by === user.id;
  }
};

// Mentorship Service
export const mentorshipService = {
  getAllMentorships: async () => {
    const response = await api.get('/mentorship');
    return response.data;
  },

  getMentorshipById: async (id) => {
    const response = await api.get(`/mentorship/${id}`);
    return response.data;
  },

  postMentorship: async (mentorshipData) => {
    const response = await api.post('/mentorship', mentorshipData);
    return response.data;
  },

  updateMentorship: async (id, mentorshipData) => {
    const response = await api.put(`/mentorship/${id}`, mentorshipData);
    return response.data;
  },

  deleteMentorship: async (id) => {
    const response = await api.delete(`/mentorship/${id}`);
    return response.data;
  },

  // New method to check if user can delete a mentorship
  canDeleteMentorship: (mentorship) => {
    const user = JSON.parse(localStorage.getItem('user'));
    return user && mentorship.mentor_id === user.id;
  }
};

export default api; 