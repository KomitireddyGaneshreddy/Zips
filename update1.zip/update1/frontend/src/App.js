import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import ThemeWrapper from './components/ThemeWrapper';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/layout/Layout';
import AdminLayout from './components/layout/AdminLayout';
import { useAuth } from './context/AuthContext';

// Pages
import Login from './pages/Login';
import NewUser from './pages/NewUser';
import Home from './pages/Home';
import Jobs from './pages/Jobs';
import Events from './pages/Events';
import Profile from './pages/Profile';
import Network from './pages/Network';
import Settings from './pages/Settings';
import Mentorship from './pages/Mentorship';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminEventManagement from './pages/admin/EventManagement';
import AdminJobManagement from './pages/admin/JobManagement';
import AlumniNetwork from './pages/admin/AlumniNetwork';
import UserManagement from './pages/admin/UserManagement';
import CredentialManagement from './pages/admin/CredentialManagement';

// Wrapper component to choose layout based on user role
const LayoutWrapper = ({ children }) => {
  const { user } = useAuth();
  
  if (user?.role === 'admin') {
    return <AdminLayout>{children}</AdminLayout>;
  }
  
  return <Layout>{children}</Layout>;
};

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <ThemeWrapper>
          <Router>
            <Routes>
              {/* Public routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<NewUser />} />
              <Route path="/new-user" element={<NewUser />} />
              
              {/* Admin routes */}
              <Route
                path="/admin/users"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <UserManagement />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/events"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <AdminEventManagement />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/jobs"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <AdminJobManagement />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/network"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <AlumniNetwork />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/credentials"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <CredentialManagement />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              
              {/* Protected routes */}
              <Route
                path="/adminDashboard"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <AdminDashboard />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/home"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <Home />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/jobs"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <Jobs />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/events"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <Events />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <Profile />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/network"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <Network />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/settings"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <Settings />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/mentorship"
                element={
                  <ProtectedRoute>
                    <LayoutWrapper>
                      <Mentorship />
                    </LayoutWrapper>
                  </ProtectedRoute>
                }
              />
              
              {/* Redirect from root to login */}
              <Route path="/" element={<Navigate to="/login" />} />
              
              {/* Catch-all redirect to home for authenticated users or login for non-authenticated */}
              <Route
                path="*"
                element={
                  <ProtectedRoute>
                    <Navigate to="/home" />
                  </ProtectedRoute>
                }
              />
            </Routes>
          </Router>
        </ThemeWrapper>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
