const db = require('../config/db.config');
const bcrypt = require('bcryptjs');

class User {
  static async create(userData) {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const [result] = await db.execute(
      'INSERT INTO users (roll_number, email, password, first_name, last_name, date_of_birth, role) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [userData.roll_number, userData.email, hashedPassword, userData.first_name, userData.last_name, userData.date_of_birth, userData.role || 'alumni']
    );
    return result.insertId;
  }

  static async findByEmail(email) {
    const [rows] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
  }

  static async findByRollNumber(roll_number) {
    const [rows] = await db.execute('SELECT * FROM users WHERE roll_number = ?', [roll_number]);
    return rows[0];
  }

  static async updateProfile(userId, profileData) {
    const [result] = await db.execute(
      'INSERT INTO user_profiles (user_id, bio, current_location, current_company, designation) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE bio=?, current_location=?, current_company=?, designation=?',
      [userId, profileData.bio, profileData.current_location, profileData.current_company, profileData.designation,
       profileData.bio, profileData.current_location, profileData.current_company, profileData.designation]
    );
    return result;
  }

  static async getProfile(userId) {
    const [rows] = await db.execute(
      `SELECT u.*, up.* FROM users u 
       LEFT JOIN user_profiles up ON u.id = up.user_id 
       WHERE u.id = ?`,
      [userId]
    );
    return rows[0];
  }
}

module.exports = User; 