const db = require('../config/db.config');

class Event {
  static async create(eventData) {
    const [result] = await db.execute(
      'INSERT INTO events (title, description, date, time, organizer_id) VALUES (?, ?, ?, ?, ?)',
      [eventData.title, eventData.description, eventData.date, eventData.time, eventData.organizer_id]
    );
    return result.insertId;
  }

  static async findAll() {
    const [rows] = await db.execute(
      `SELECT e.*, u.first_name, u.last_name 
       FROM events e 
       LEFT JOIN users u ON e.organizer_id = u.id 
       ORDER BY e.date ASC, e.time ASC`
    );
    return rows;
  }

  static async findById(id) {
    const [rows] = await db.execute(
      `SELECT e.*, u.first_name, u.last_name 
       FROM events e 
       LEFT JOIN users u ON e.organizer_id = u.id 
       WHERE e.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async update(id, eventData) {
    const [result] = await db.execute(
      'UPDATE events SET title = ?, description = ?, date = ?, time = ? WHERE id = ?',
      [eventData.title, eventData.description, eventData.date, eventData.time, id]
    );
    return result.affectedRows > 0;
  }

  static async delete(id) {
    const [result] = await db.execute('DELETE FROM events WHERE id = ?', [id]);
    return result.affectedRows > 0;
  }

  static async getUpcoming() {
    const [rows] = await db.execute(
      `SELECT e.*, u.first_name, u.last_name 
       FROM events e 
       LEFT JOIN users u ON e.organizer_id = u.id 
       WHERE e.date >= CURDATE() 
       ORDER BY e.date ASC, e.time ASC 
       LIMIT 5`
    );
    return rows;
  }
}

module.exports = Event; 