-- Create database
DROP DATABASE IF EXISTS jntua_alumni;
CREATE DATABASE jntua_alumni;
USE jntua_alumni;

-- Create users table
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    roll_number VARCHAR(10) NOT NULL UNIQUE,
    surname VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    email VARCHAR(100) UNIQUE,
    previous_phone VARCHAR(15),
    current_phone VARCHAR(15),
    password VARCHAR(255) NOT NULL,
    department VARCHAR(50) NOT NULL DEFAULT 'CSE',
    role ENUM('alumni', 'admin') DEFAULT 'alumni',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create user_profiles table
CREATE TABLE user_profiles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    bio TEXT,
    current_location VARCHAR(100),
    current_company VARCHAR(100),
    designation VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Skills table
CREATE TABLE skills (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) UNIQUE NOT NULL
);

-- User Skills table (Many-to-Many relationship)
CREATE TABLE user_skills (
    user_id BIGINT,
    skill_id BIGINT,
    PRIMARY KEY (user_id, skill_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

-- Education table
CREATE TABLE education (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    degree VARCHAR(100) NOT NULL,
    institution VARCHAR(100) NOT NULL,
    year VARCHAR(20) NOT NULL,
    grade VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Experience table
CREATE TABLE experience (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    role VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    duration VARCHAR(50) NOT NULL,
    description TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Social Links table
CREATE TABLE social_links (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    platform VARCHAR(50) NOT NULL,
    url VARCHAR(255) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Jobs table
CREATE TABLE jobs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    posted_by BIGINT,
    title VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    type ENUM('Full-time', 'Part-time', 'Internship') NOT NULL,
    remote BOOLEAN DEFAULT FALSE,
    department VARCHAR(50) NOT NULL,
    experience VARCHAR(50) NOT NULL,
    salary VARCHAR(50),
    description TEXT NOT NULL,
    requirements TEXT,
    application_link VARCHAR(255),
    deadline DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Events table
CREATE TABLE events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    created_by BIGINT,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    location VARCHAR(255) NOT NULL,
    type ENUM('In-Person', 'Virtual') NOT NULL,
    registration_link VARCHAR(255),
    max_attendees INT,
    department VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Mentorship table
CREATE TABLE mentorship (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    mentor_id BIGINT,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    expertise VARCHAR(255) NOT NULL,
    experience VARCHAR(50) NOT NULL,
    availability TEXT NOT NULL,
    department VARCHAR(50) NOT NULL,
    type ENUM('Career Guidance', 'Technical Mentoring', 'Leadership Development') NOT NULL,
    expectations TEXT,
    contact_email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mentor_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Connections table (for networking)
CREATE TABLE connections (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    connected_user_id BIGINT,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (connected_user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_connection (user_id, connected_user_id)
);

-- Create user_credentials table
CREATE TABLE IF NOT EXISTS user_credentials (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  roll_number VARCHAR(20) NOT NULL UNIQUE,
  unique_key VARCHAR(50) NOT NULL UNIQUE,
  status ENUM('available', 'used') DEFAULT 'available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT,
  FOREIGN KEY (created_by) REFERENCES users(id)
); 