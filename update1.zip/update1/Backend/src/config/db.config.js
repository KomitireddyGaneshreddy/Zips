const mysql = require('mysql2');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'jntua_alumni',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Convert pool to use promises
const promisePool = pool.promise();

// Initialize database tables
// const initDatabase = async () => {
//   try {
//     // Create database if it doesn't exist
//     await promisePool.execute(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || 'jntua_alumni'}`);
//     await promisePool.execute(`USE ${process.env.DB_NAME || 'jntua_alumni'}`);

//     // Disable foreign key checks temporarily
//     await promisePool.execute('SET FOREIGN_KEY_CHECKS = 0');

//     // Drop all tables
//     await promisePool.execute('DROP TABLE IF EXISTS event_registrations');
//     await promisePool.execute('DROP TABLE IF EXISTS events');
//     await promisePool.execute('DROP TABLE IF EXISTS job_applications');
//     await promisePool.execute('DROP TABLE IF EXISTS jobs');
//     await promisePool.execute('DROP TABLE IF EXISTS mentorship_applications');
//     await promisePool.execute('DROP TABLE IF EXISTS mentorship_programs');
//     await promisePool.execute('DROP TABLE IF EXISTS social_links');
//     await promisePool.execute('DROP TABLE IF EXISTS skills');
//     await promisePool.execute('DROP TABLE IF EXISTS experience');
//     await promisePool.execute('DROP TABLE IF EXISTS education');
//     await promisePool.execute('DROP TABLE IF EXISTS users');

//     // Re-enable foreign key checks
//     await promisePool.execute('SET FOREIGN_KEY_CHECKS = 1');

//     // Create users table first (no foreign key dependencies)
//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS users (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         roll_number VARCHAR(20) UNIQUE,
//         first_name VARCHAR(50) NOT NULL,
//         last_name VARCHAR(50) NOT NULL,
//         surname VARCHAR(20),
//         date_of_birth DATE,
//         email VARCHAR(100) UNIQUE NOT NULL,
//         password VARCHAR(255) NOT NULL,
//         current_phone VARCHAR(20),
//         previous_phone VARCHAR(20),
//         profile_picture VARCHAR(255),
//         bio TEXT,
//         graduation_year INT,
//         department VARCHAR(100),
//         unique_key VARCHAR(50) NOT NULL DEFAULT 'ABC123',
//         role ENUM('admin', 'alumni', 'student') NOT NULL DEFAULT 'student',
//         is_verified BOOLEAN DEFAULT FALSE,
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     // Create events table (depends on users)
//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS events (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         title VARCHAR(255) NOT NULL,
//         description TEXT,
//         event_date DATETIME NOT NULL,
//         end_date DATETIME,
//         location VARCHAR(255),
//         venue_details TEXT,
//         max_participants INT,
//         registration_deadline DATETIME,
//         event_type ENUM('webinar', 'workshop', 'meetup', 'conference', 'other') NOT NULL,
//         organizer_id INT NOT NULL,
//         status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
//         is_featured BOOLEAN DEFAULT FALSE,
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (organizer_id) REFERENCES users(id) ON DELETE CASCADE
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     // Create event_registrations table (depends on both users and events)
//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS event_registrations (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         event_id INT NOT NULL,
//         user_id INT NOT NULL,
//         status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
//         registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         attendance_status ENUM('attended', 'not_attended', 'pending') DEFAULT 'pending',
//         feedback TEXT,
//         rating INT CHECK (rating >= 1 AND rating <= 5),
//         FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
//         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
//         UNIQUE KEY unique_registration (event_id, user_id)
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     // Create other tables in order of dependencies
//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS education (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         user_id INT NOT NULL,
//         institution VARCHAR(255) NOT NULL,
//         degree VARCHAR(100) NOT NULL,
//         field_of_study VARCHAR(100) NOT NULL,
//         start_date DATE,
//         end_date DATE,
//         grade VARCHAR(20),
//         activities TEXT,
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS experience (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         user_id INT NOT NULL,
//         company VARCHAR(255) NOT NULL,
//         position VARCHAR(100) NOT NULL,
//         location VARCHAR(100),
//         start_date DATE NOT NULL,
//         end_date DATE,
//         is_current BOOLEAN DEFAULT FALSE,
//         description TEXT,
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS skills (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         user_id INT NOT NULL,
//         skill_name VARCHAR(100) NOT NULL,
//         proficiency_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
//         UNIQUE KEY unique_user_skill (user_id, skill_name)
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS jobs (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         title VARCHAR(255) NOT NULL,
//         company VARCHAR(255) NOT NULL,
//         location VARCHAR(255),
//         job_type ENUM('full-time', 'part-time', 'contract', 'internship') NOT NULL,
//         description TEXT NOT NULL,
//         requirements TEXT,
//         salary_range VARCHAR(100),
//         posted_by INT NOT NULL,
//         application_deadline DATE,
//         experience_required VARCHAR(50),
//         status ENUM('open', 'closed', 'draft') DEFAULT 'open',
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (posted_by) REFERENCES users(id) ON DELETE CASCADE
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS job_applications (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         job_id INT NOT NULL,
//         applicant_id INT NOT NULL,
//         resume_url VARCHAR(255),
//         cover_letter TEXT,
//         status ENUM('pending', 'reviewed', 'shortlisted', 'rejected', 'accepted') DEFAULT 'pending',
//         applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
//         FOREIGN KEY (applicant_id) REFERENCES users(id) ON DELETE CASCADE,
//         UNIQUE KEY unique_application (job_id, applicant_id)
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS mentorship_programs (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         mentor_id INT NOT NULL,
//         title VARCHAR(255) NOT NULL,
//         description TEXT,
//         expertise_areas TEXT NOT NULL,
//         max_mentees INT,
//         duration_months INT,
//         status ENUM('active', 'inactive', 'completed') DEFAULT 'active',
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (mentor_id) REFERENCES users(id) ON DELETE CASCADE
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS mentorship_applications (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         program_id INT NOT NULL,
//         mentee_id INT NOT NULL,
//         motivation TEXT NOT NULL,
//         status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
//         applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (program_id) REFERENCES mentorship_programs(id) ON DELETE CASCADE,
//         FOREIGN KEY (mentee_id) REFERENCES users(id) ON DELETE CASCADE,
//         UNIQUE KEY unique_mentorship (program_id, mentee_id)
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     await promisePool.execute(`
//       CREATE TABLE IF NOT EXISTS social_links (
//         id INT AUTO_INCREMENT PRIMARY KEY,
//         user_id INT NOT NULL,
//         platform ENUM('linkedin', 'twitter', 'github', 'portfolio', 'other') NOT NULL,
//         url VARCHAR(255) NOT NULL,
//         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
//         updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
//         UNIQUE KEY unique_platform (user_id, platform)
//       ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
//     `);

//     console.log('Database tables initialized successfully');
//   } catch (error) {
//     console.error('Error initializing database:', error);
//     throw error;
//   }
// };

// Initialize database on startup
//initDatabase().catch(console.error);

module.exports = promisePool; 