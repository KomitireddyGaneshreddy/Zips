const express = require('express');
const router = express.Router();
const jobController = require('../controllers/job.controller');
const { verifyToken } = require('../middleware/auth');

// Public routes
router.get('/', jobController.getAllJobs);
router.get('/:id', jobController.getJobById);

// Protected routes (require authentication)
router.use(verifyToken);

// Job posting management
router.post('/', jobController.createJob);
router.put('/:id', jobController.updateJob);
router.delete('/:id', jobController.deleteJob);

// Job application management
router.post('/:id/apply', jobController.applyForJob);
router.get('/:id/applications', jobController.getJobApplications);
router.put('/:id/applications/:applicationId', jobController.updateApplicationStatus);

module.exports = router; 