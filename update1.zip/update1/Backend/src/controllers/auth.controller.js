const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db.config');
const userController = require('./user.controller');

exports.register = async (req, res) => {
  let connection;
  try {
    console.log('Registration request received:', req.body);

    const {
      roll_number,
      first_name,
      last_name,
      surname,
      date_of_birth,
      email,
      password,
      current_phone,
      previous_phone,
      role,
      unique_key,
      department
    } = req.body;

    // Validate required fields
    if (!email || !password || !roll_number || !first_name || !last_name || !unique_key) {
      console.log('Missing required fields:', {
        email: !!email,
        password: !!password,
        roll_number: !!roll_number,
        first_name: !!first_name,
        last_name: !!last_name,
        unique_key: !!unique_key
      });
      return res.status(400).json({
        message: 'All required fields must be provided'
      });
    }

    // Get a connection from the pool
    connection = await db.getConnection();

    // Start transaction
    await connection.beginTransaction();

    try {
      // Verify credentials
      console.log('Verifying credentials:', { roll_number, unique_key });
      const [credential] = await connection.execute(
        'SELECT * FROM user_credentials WHERE roll_number = ? AND unique_key = ? AND status = ?',
        [roll_number, unique_key, 'available']
      );
      
      console.log('Found credential:', credential);
      
      if (credential.length === 0) {
        console.log('No matching credential found');
        await connection.rollback();
        return res.status(400).json({
          message: 'Invalid roll number or unique key'
        });
      }

      // Check if user already exists
      const [existingUsers] = await connection.execute(
        'SELECT id FROM users WHERE email = ? OR roll_number = ?',
        [email, roll_number]
      );

      if (existingUsers.length > 0) {
        console.log('User already exists:', existingUsers[0]);
        await connection.rollback();
        return res.status(400).json({
          message: 'User with this email or roll number already exists'
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Insert new user
      const [result] = await connection.execute(
        `INSERT INTO users (
          roll_number, first_name, last_name, surname, date_of_birth,
          email, password, current_phone, previous_phone, role, department
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          roll_number, first_name, last_name, surname, date_of_birth,
          email, hashedPassword, current_phone, previous_phone, role, department || 'CSE'
        ]
      );

      // Mark credential as used
      await connection.execute(
        'UPDATE user_credentials SET status = ? WHERE roll_number = ? AND unique_key = ?',
        ['used', roll_number, unique_key]
      );

      // Commit transaction
      await connection.commit();

      // Generate JWT token
      const token = jwt.sign(
        { id: result.insertId, email, role },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: process.env.JWT_EXPIRES_IN }
      );

      res.status(201).json({
        message: 'User registered successfully',
        token,
        user: {
          id: result.insertId,
          email,
          role
        }
      });
    } catch (error) {
      // Rollback transaction on error
      if (connection) {
        await connection.rollback();
      }
      throw error;
    }
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      message: 'Error registering user',
      error: error.message
    });
  } finally {
    // Release the connection back to the pool
    if (connection) {
      connection.release();
    }
  }
};

exports.login = async (req, res) => {
  try {
    console.log('Login request received:', { email: req.body.email });

    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({
        message: 'Email and password are required'
      });
    }

    // Find user by email
    const [users] = await db.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({
        message: 'Invalid email or password'
      });
    }

    const user = users[0];

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({
        message: 'Invalid email or password'
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    console.log('User logged in successfully:', { id: user.id, email: user.email });
    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        roll_number: user.roll_number,
        first_name: user.first_name,
        last_name: user.last_name,
        surname: user.surname,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      message: 'Error during login',
      error: error.message
    });
  }
}; 