const db = require('../config/db.config');

exports.createEvent = async (req, res) => {
  try {
    const {
      title,
      description,
      date,
      time,
      location,
      type,
      registration_link,
      max_attendees,
      department
    } = req.body;

    console.log('Received event data:', req.body);

    // Validate required fields
    if (!title || !description || !date || !location || !type || !department) {
      return res.status(400).json({
        message: 'Please provide all required fields',
        missingFields: {
          title: !title,
          description: !description,
          date: !date,
          location: !location,
          type: !type,
          department: !department
        }
      });
    }

    // Validate date format
    const eventDate = new Date(date);
    if (isNaN(eventDate.getTime())) {
      return res.status(400).json({
        message: 'Invalid date format. Please use YYYY-MM-DD format'
      });
    }

    // Handle time field
    let eventTime = time;
    if (!time) {
      // Default to 10:00 AM if no time is provided
      eventTime = '10:00:00';
    } else {
      // If time doesn't include seconds, add them
      if (!time.includes(':')) {
        return res.status(400).json({
          message: 'Invalid time format. Please use HH:mm or HH:mm:ss format'
        });
      }

      const timeParts = time.split(':');
      if (timeParts.length === 2) {
        // If only HH:mm format, add seconds
        eventTime = `${time}:00`;
      } else if (timeParts.length === 3) {
        // If HH:mm:ss format, validate
        const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/;
        if (!timeRegex.test(time)) {
          return res.status(400).json({
            message: 'Invalid time format. Please use HH:mm or HH:mm:ss format'
          });
        }
      } else {
        return res.status(400).json({
          message: 'Invalid time format. Please use HH:mm or HH:mm:ss format'
        });
      }
    }

    console.log('Formatted event time:', eventTime);

    const [result] = await db.execute(
      `INSERT INTO events (
        title, description, date, time, location,
        type, registration_link, max_attendees, department, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title,
        description,
        date,
        eventTime,
        location,
        type,
        registration_link || null,
        max_attendees || null,
        department,
        req.user.id
      ]
    );

    res.status(201).json({
      message: 'Event created successfully',
      eventId: result.insertId
    });
  } catch (error) {
    console.error('Create event error:', error);
    res.status(500).json({
      message: 'Error creating event',
      error: error.message
    });
  }
};

exports.getAllEvents = async (req, res) => {
  try {
    const [events] = await db.execute(`
      SELECT 
        e.*,
        u.first_name,
        u.last_name,
        u.role,
        edu.degree,
        edu.year as batch
      FROM events e
      JOIN users u ON e.created_by = u.id
      LEFT JOIN (
        SELECT e1.user_id, e1.degree, e1.year
        FROM education e1
        INNER JOIN (
          SELECT user_id, MAX(year) as max_year
          FROM education
          GROUP BY user_id
        ) e2 ON e1.user_id = e2.user_id AND e1.year = e2.max_year
      ) edu ON u.id = edu.user_id
      ORDER BY e.created_at DESC
    `);
    res.json(events);
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ message: 'Error fetching events' });
  }
};

exports.getUpcomingEvents = async (req, res) => {
  try {
    console.log('Fetching upcoming events...');
    
    // First, let's check what date MySQL thinks it is
    const [currentDate] = await db.execute('SELECT CURDATE() as today');
    console.log('Current MySQL date:', currentDate[0].today);
    
    // Now get the events with date comparison logged
    const [events] = await db.execute(`
      SELECT e.*, u.first_name, u.last_name,
             e.date as event_date,
             CURDATE() as today,
             e.date >= CURDATE() as is_upcoming
      FROM events e
      JOIN users u ON e.created_by = u.id
      ORDER BY e.date ASC, e.time ASC
      LIMIT 5
    `);

    console.log('Query results:', events);
    
    // Filter upcoming events in JS as well to verify
    const upcomingEvents = events.filter(event => {
      const eventDate = new Date(event.date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const isUpcoming = eventDate >= today;
      console.log(`Event ${event.title}: date=${event.date}, isUpcoming=${isUpcoming}`);
      return isUpcoming;
    });

    console.log('Upcoming events after filtering:', upcomingEvents);
    res.json(upcomingEvents);
  } catch (error) {
    console.error('Get upcoming events error:', error);
    res.status(500).json({
      message: 'Error retrieving upcoming events',
      error: error.message
    });
  }
};

exports.getEventById = async (req, res) => {
  try {
    const { id } = req.params;

    const [event] = await db.execute(`
      SELECT 
        e.*,
        u.first_name,
        u.last_name,
        u.role,
        edu.degree,
        edu.year as batch
      FROM events e
      JOIN users u ON e.created_by = u.id
      LEFT JOIN (
        SELECT e1.user_id, e1.degree, e1.year
        FROM education e1
        INNER JOIN (
          SELECT user_id, MAX(year) as max_year
          FROM education
          GROUP BY user_id
        ) e2 ON e1.user_id = e2.user_id AND e1.year = e2.max_year
      ) edu ON u.id = edu.user_id
      WHERE e.id = ?
    `, [id]);

    if (event.length === 0) {
      return res.status(404).json({
        message: 'Event not found'
      });
    }

    res.json(event[0]);
  } catch (error) {
    console.error('Error fetching event:', error);
    res.status(500).json({ message: 'Error fetching event' });
  }
};

exports.updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      date,
      time,
      location,
      type,
      registration_link,
      max_attendees,
      department
    } = req.body;

    // Check if event exists and user is the creator
    const [events] = await db.execute(
      'SELECT created_by FROM events WHERE id = ?',
      [id]
    );

    if (events.length === 0) {
      return res.status(404).json({
        message: 'Event not found'
      });
    }

    if (events[0].created_by !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to update this event'
      });
    }

    await db.execute(
      `UPDATE events SET
        title = ?,
        description = ?,
        date = ?,
        time = ?,
        location = ?,
        type = ?,
        registration_link = ?,
        max_attendees = ?,
        department = ?
      WHERE id = ?`,
      [
        title,
        description,
        date,
        time,
        location,
        type,
        registration_link,
        max_attendees,
        department,
        id
      ]
    );

    res.json({
      message: 'Event updated successfully'
    });
  } catch (error) {
    console.error('Error updating event:', error);
    res.status(500).json({ message: 'Error updating event' });
  }
};

exports.deleteEvent = async (req, res) => {
  try {
    const eventId = req.params.id;
    const userId = req.user.id;
    const userRole = req.user.role;

    // First check if the event exists
    const [event] = await db.execute(
      'SELECT * FROM events WHERE id = ?',
      [eventId]
    );

    if (event.length === 0) {
      return res.status(404).json({
        message: 'Event not found'
      });
    }

    // If user is not an admin, check if they own the event
    if (userRole !== 'admin' && event[0].created_by !== userId) {
      return res.status(403).json({
        message: 'You are not authorized to delete this event'
      });
    }

    // Delete the event
    await db.execute('DELETE FROM events WHERE id = ?', [eventId]);

    res.json({
      message: 'Event deleted successfully'
    });
  } catch (error) {
    console.error('Delete event error:', error);
    res.status(500).json({
      message: 'Error deleting event',
      error: error.message
    });
  }
};

exports.registerForEvent = async (req, res) => {
  try {
    const { id: eventId } = req.params;
    const userId = req.user.id;

    // Check if event exists and registration is still open
    const [events] = await db.execute(`
      SELECT id, max_participants, registration_deadline,
        (SELECT COUNT(*) FROM event_registrations WHERE event_id = events.id) as current_participants
      FROM events 
      WHERE id = ? AND registration_deadline >= CURDATE()
    `, [eventId]);

    if (events.length === 0) {
      return res.status(404).json({
        message: 'Event not found or registration closed'
      });
    }

    const event = events[0];

    // Check if event is full
    if (event.current_participants >= event.max_participants) {
      return res.status(400).json({
        message: 'Event is full'
      });
    }

    // Check if already registered
    const [existingRegistrations] = await db.execute(
      'SELECT id FROM event_registrations WHERE event_id = ? AND participant_id = ?',
      [eventId, userId]
    );

    if (existingRegistrations.length > 0) {
      return res.status(400).json({
        message: 'You are already registered for this event'
      });
    }

    // Create registration
    const [result] = await db.execute(
      'INSERT INTO event_registrations (event_id, participant_id) VALUES (?, ?)',
      [eventId, userId]
    );

    res.status(201).json({
      message: 'Successfully registered for the event',
      registrationId: result.insertId
    });
  } catch (error) {
    console.error('Event registration error:', error);
    res.status(500).json({
      message: 'Error registering for event'
    });
  }
};

exports.getEventParticipants = async (req, res) => {
  try {
    const { id: eventId } = req.params;

    // Check if event exists and user is the organizer
    const [events] = await db.execute(
      'SELECT created_by FROM events WHERE id = ?',
      [eventId]
    );

    if (events.length === 0) {
      return res.status(404).json({
        message: 'Event not found'
      });
    }

    if (events[0].created_by !== req.user.id) {
      return res.status(403).json({
        message: 'Not authorized to view participants'
      });
    }

    const [participants] = await db.execute(`
      SELECT 
        u.id,
        u.roll_number,
        u.first_name,
        u.last_name,
        u.email,
        er.created_at as registration_date
      FROM event_registrations er
      JOIN users u ON er.participant_id = u.id
      WHERE er.event_id = ?
      ORDER BY er.created_at ASC
    `, [eventId]);

    res.json(participants);
  } catch (error) {
    console.error('Get event participants error:', error);
    res.status(500).json({
      message: 'Error retrieving event participants'
    });
  }
};

exports.cancelRegistration = async (req, res) => {
  try {
    const { id: eventId } = req.params;
    const userId = req.user.id;

    const [result] = await db.execute(
      'DELETE FROM event_registrations WHERE event_id = ? AND participant_id = ?',
      [eventId, userId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: 'Registration not found'
      });
    }

    res.json({
      message: 'Registration cancelled successfully'
    });
  } catch (error) {
    console.error('Cancel registration error:', error);
    res.status(500).json({
      message: 'Error cancelling registration'
    });
  }
}; 