# JNTUA Alumni Network

A modern web application for connecting JNTUA College of Engineering Pulivendula alumni, built with React and Material-UI.

## Features

- **Professional Networking**: Connect with fellow alumni and build your professional network
- **Job Board**: Browse and post job opportunities within the alumni community
- **Events**: Discover and organize alumni events and reunions
- **Mentorship Program**: Connect with experienced alumni for guidance and mentorship
- **Advanced Matching Algorithm**: Smart mentor-mentee matching based on multiple compatibility factors
- **Analytics Dashboard**: Comprehensive insights for administrators

## Tech Stack

- React.js
- Material-UI
- React Query
- React Router
- Axios
- Recharts (for analytics)
- Date-fns

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/jntua-alumni-network.git
   cd jntua-alumni-network
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root directory and add your environment variables:
   ```
   REACT_APP_API_BASE_URL=http://localhost:5000/api
   ```

4. Start the development server:
   ```bash
   npm start
   ```

The application will be available at `http://localhost:3000`.

## Project Structure

```
src/
├── components/        # Reusable UI components
│   ├── common/       # Shared components
│   ├── layout/       # Layout components
│   ├── profile/      # Profile related components
│   ├── network/      # Networking components
│   ├── jobs/         # Job board components
│   ├── events/       # Event components
│   ├── mentorship/   # Mentorship components
│   └── admin/        # Admin dashboard components
├── pages/            # Page components
├── services/         # API and other services
├── context/          # React context providers
├── hooks/            # Custom React hooks
├── utils/            # Utility functions
└── assets/           # Static assets
```

## Features in Detail

### Professional Networking
- User profiles with education and professional experience
- Connection requests and networking
- Alumni search with filters
- Direct messaging between connected users

### Job Board
- Post and browse job opportunities
- Advanced job search with filters
- Easy application process
- Job recommendations based on profile

### Events
- Create and manage alumni events
- Event registration and attendance tracking
- Virtual and in-person event support
- Event recommendations

### Mentorship Program
- Smart mentor-mentee matching algorithm
- Structured mentorship programs
- Progress tracking
- Resource sharing

### Admin Dashboard
- User analytics
- Engagement metrics
- Event statistics
- Mentorship program insights

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- JNTUA College of Engineering Pulivendula
- All contributors and alumni who helped shape this platform 